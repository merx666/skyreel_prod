import os
import sqlite3
import django
import re
import subprocess
import tempfile

# Konfiguracja Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hyperreal_help.settings')
django.setup()

from medical_facilities.models import (
    MedicalFacility, FacilityRating, FacilityImage,
    Voivodeship, AddictionType, FacilityType, TherapyType, AgeGroup
)
from django.contrib.auth.models import User

# Ścieżka do pliku SQL
SQL_FILE = 'staryhelp_baza/stary_help_baza.sql'

# Funkcja do parsowania pliku SQL i importu danych
def import_data():
    print("Rozpoczynam import danych...")
    
    # Sprawdź czy plik SQL istnieje
    if not os.path.exists(SQL_FILE):
        print(f"Plik SQL nie istnieje: {SQL_FILE}")
        return
    
    # Utwórz tymczasową bazę SQLite
    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
    temp_db_path = temp_db.name
    temp_db.close()
    
    # Połącz z tymczasową bazą SQLite
    conn = sqlite3.connect(temp_db_path)
    cursor = conn.cursor()
    
    # Utwórz tabele w tymczasowej bazie
    print("Tworzę tabele w tymczasowej bazie...")
    
    # Tabela dla placówek
    cursor.execute('''
    CREATE TABLE placowki (
        id INTEGER PRIMARY KEY,
        title TEXT,
        address TEXT,
        city TEXT,
        postal_code TEXT,
        phone TEXT,
        email TEXT,
        website TEXT,
        voivodeship TEXT,
        created INTEGER,
        changed INTEGER
    )
    ''')
    
    # Tabela dla typów placówek
    cursor.execute('''
    CREATE TABLE placowki_typy (
        placowka_id INTEGER,
        typ TEXT,
        FOREIGN KEY (placowka_id) REFERENCES placowki (id)
    )
    ''')
    
    # Tabela dla typów terapii
    cursor.execute('''
    CREATE TABLE placowki_terapie (
        placowka_id INTEGER,
        terapia TEXT,
        FOREIGN KEY (placowka_id) REFERENCES placowki (id)
    )
    ''')
    
    # Tabela dla grup wiekowych
    cursor.execute('''
    CREATE TABLE placowki_grupy_wiekowe (
        placowka_id INTEGER,
        grupa TEXT,
        FOREIGN KEY (placowka_id) REFERENCES placowki (id)
    )
    ''')
    
    # Tabela dla ocen
    cursor.execute('''
    CREATE TABLE oceny (
        id INTEGER PRIMARY KEY,
        placowka_id INTEGER,
        username TEXT,
        overall_rating INTEGER,
        staff_rating INTEGER,
        facilities_rating INTEGER,
        treatment_rating INTEGER,
        comment TEXT,
        comment_text TEXT,
        created INTEGER,
        changed INTEGER,
        FOREIGN KEY (placowka_id) REFERENCES placowki (id)
    )
    ''')
    
    # Parsuj plik SQL i wyciągnij dane
    print("Parsowanie pliku SQL i wyciąganie danych...")
    
    # Otwórz plik SQL - próbuj różnych kodowań
    encodings = ['latin1', 'latin2', 'iso-8859-1', 'iso-8859-2', 'cp1250', 'utf-8']
    sql_content = None
    
    for encoding in encodings:
        try:
            with open(SQL_FILE, 'r', encoding=encoding) as f:
                sql_content = f.read()
                print(f"Udało się otworzyć plik z kodowaniem: {encoding}")
                break
        except UnicodeDecodeError:
            continue
    
    if sql_content is None:
        print("Nie udało się otworzyć pliku SQL z żadnym z dostępnych kodowań.")
        return
    
    # Wyciągnij dane o placówkach
    print("Wyciągam dane o placówkach...")
    
    # Znajdź wszystkie placówki w pliku SQL - uproszczone wyrażenie
    placowki_pattern = r"INSERT INTO `node`.*?\((\d+),.*?,'([^']*)',.*?,'placowka',.*?(\d+),(\d+).*?\);"
    placowki_matches = re.finditer(placowki_pattern, sql_content, re.DOTALL)
    
    placowki_count = 0
    for match in placowki_matches:
        nid = match.group(1)
        title = match.group(2)
        created = match.group(3)
        changed = match.group(4)
        
        # Znajdź dane adresowe
        address_pattern = r"INSERT INTO `field_data_field_adres` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,'([^']*)'"
        address_match = re.search(address_pattern, sql_content)
        address = address_match.group(1) if address_match else None
        
        # Znajdź miasto
        city_pattern = r"INSERT INTO `field_data_field_miasto` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,'([^']*)'"
        city_match = re.search(city_pattern, sql_content)
        city = city_match.group(1) if city_match else None
        
        # Znajdź kod pocztowy
        postal_pattern = r"INSERT INTO `field_data_field_kod_pocztowy` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,'([^']*)'"
        postal_match = re.search(postal_pattern, sql_content)
        postal_code = postal_match.group(1) if postal_match else None
        
        # Znajdź telefon
        phone_pattern = r"INSERT INTO `field_data_field_telefon` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,'([^']*)'"
        phone_match = re.search(phone_pattern, sql_content)
        phone = phone_match.group(1) if phone_match else None
        
        # Znajdź email
        email_pattern = r"INSERT INTO `field_data_field_email` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,'([^']*)',[^,]*,'([^']*)'"
        email_match = re.search(email_pattern, sql_content)
        email = email_match.group(2) if email_match else None
        
        # Znajdź stronę www
        website_pattern = r"INSERT INTO `field_data_field_www` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,'([^']*)',[^,]*,'([^']*)'"
        website_match = re.search(website_pattern, sql_content)
        website = website_match.group(2) if website_match else None
        
        # Znajdź województwo
        voivodeship_pattern = r"INSERT INTO `field_data_field_wojewodztwo` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,(\d+)"
        voivodeship_match = re.search(voivodeship_pattern, sql_content)
        
        voivodeship = None
        if voivodeship_match:
            tid = voivodeship_match.group(1)
            taxonomy_pattern = r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)',"
            taxonomy_match = re.search(taxonomy_pattern, sql_content)
            voivodeship = taxonomy_match.group(1) if taxonomy_match else None
        
        # Dodaj placówkę do tymczasowej bazy
        cursor.execute('''
        INSERT INTO placowki (id, title, address, city, postal_code, phone, email, website, voivodeship, created, changed)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nid, title, address, city, postal_code, phone, email, website, voivodeship, created, changed))
        
        # Znajdź typy placówek
        facility_types_pattern = r"INSERT INTO `field_data_field_typ_placowki` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,(\d+)"
        facility_types_matches = re.finditer(facility_types_pattern, sql_content)
        
        for ft_match in facility_types_matches:
            tid = ft_match.group(1)
            taxonomy_pattern = r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)',"
            taxonomy_match = re.search(taxonomy_pattern, sql_content)
            
            if taxonomy_match:
                facility_type = taxonomy_match.group(1)
                cursor.execute('''
                INSERT INTO placowki_typy (placowka_id, typ)
                VALUES (?, ?)
                ''', (nid, facility_type))
        
        # Znajdź typy terapii
        therapy_types_pattern = r"INSERT INTO `field_data_field_typ_terapii` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,(\d+)"
        therapy_types_matches = re.finditer(therapy_types_pattern, sql_content)
        
        for tt_match in therapy_types_matches:
            tid = tt_match.group(1)
            taxonomy_pattern = r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)',"
            taxonomy_match = re.search(taxonomy_pattern, sql_content)
            
            if taxonomy_match:
                therapy_type = taxonomy_match.group(1)
                cursor.execute('''
                INSERT INTO placowki_terapie (placowka_id, terapia)
                VALUES (?, ?)
                ''', (nid, therapy_type))
        
        # Znajdź grupy wiekowe
        age_groups_pattern = r"INSERT INTO `field_data_field_grupa_wiekowa` VALUES \([^,]*,\d+,'node','placowka',[^,]*," + nid + ",[^,]*,(\d+)"
        age_groups_matches = re.finditer(age_groups_pattern, sql_content)
        
        for ag_match in age_groups_matches:
            tid = ag_match.group(1)
            taxonomy_pattern = r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)',"
            taxonomy_match = re.search(taxonomy_pattern, sql_content)
            
            if taxonomy_match:
                age_group = taxonomy_match.group(1)
                cursor.execute('''
                INSERT INTO placowki_grupy_wiekowe (placowka_id, grupa)
                VALUES (?, ?)
                ''', (nid, age_group))
        
        placowki_count += 1
    
    # Wyciągnij dane o ocenach
    print("Wyciągam dane o ocenach...")
    
    # Znajdź wszystkie komentarze (oceny) w pliku SQL
    oceny_pattern = r"INSERT INTO `comment` VALUES \((\d+),[^,]*,(\d+),[^,]*,(\d+),[^,]*,'([^']*)',[^,]*,'([^']*)',[^,]*,(\d+),(\d+),[^;]*\);"
    oceny_matches = re.finditer(oceny_pattern, sql_content)
    
    oceny_count = 0
    for match in oceny_matches:
        cid = match.group(1)
        nid = match.group(2)
        uid = match.group(3)
        subject = match.group(4)
        comment_text = match.group(5).replace('\\n', '\n').replace('\\r', '\r')
        created = match.group(6)
        changed = match.group(7)
        
        # Znajdź username
        username_pattern = r"INSERT INTO `users` VALUES \(" + uid + ",[^,]*,'([^']*)',"
        username_match = re.search(username_pattern, sql_content)
        username = username_match.group(1) if username_match else 'Anonymous'
        
        # Znajdź oceny
        overall_rating_pattern = r"INSERT INTO `field_data_field_ocena_ogolna` VALUES \([^,]*,\d+,'comment','comment_node_placowka',[^,]*," + cid + ",[^,]*,(\d+)"
        overall_rating_match = re.search(overall_rating_pattern, sql_content)
        overall_rating = overall_rating_match.group(1) if overall_rating_match else 0
        
        staff_rating_pattern = r"INSERT INTO `field_data_field_ocena_personel` VALUES \([^,]*,\d+,'comment','comment_node_placowka',[^,]*," + cid + ",[^,]*,(\d+)"
        staff_rating_match = re.search(staff_rating_pattern, sql_content)
        staff_rating = staff_rating_match.group(1) if staff_rating_match else None
        
        facilities_rating_pattern = r"INSERT INTO `field_data_field_ocena_warunki` VALUES \([^,]*,\d+,'comment','comment_node_placowka',[^,]*," + cid + ",[^,]*,(\d+)"
        facilities_rating_match = re.search(facilities_rating_pattern, sql_content)
        facilities_rating = facilities_rating_match.group(1) if facilities_rating_match else None
        
        treatment_rating_pattern = r"INSERT INTO `field_data_field_ocena_leczenie` VALUES \([^,]*,\d+,'comment','comment_node_placowka',[^,]*," + cid + ",[^,]*,(\d+)"
        treatment_rating_match = re.search(treatment_rating_pattern, sql_content)
        treatment_rating = treatment_rating_match.group(1) if treatment_rating_match else None
        
        # Dodaj ocenę do tymczasowej bazy
        cursor.execute('''
        INSERT INTO oceny (id, placowka_id, username, overall_rating, staff_rating, facilities_rating, treatment_rating, comment, comment_text, created, changed)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (cid, nid, username, overall_rating, staff_rating, facilities_rating, treatment_rating, subject, comment_text, created, changed))
        
        oceny_count += 1
    
    # Zapisz zmiany w tymczasowej bazie
    conn.commit()
    
    print(f"Znaleziono {placowki_count} placówek i {oceny_count} ocen.")
    
    # Importuj dane do bazy Django
    print("Importuję dane do bazy Django...")
    
    # Importuj placówki
    cursor.execute("SELECT * FROM placowki")
    placowki = cursor.fetchall()
    
    imported_placowki = 0
    for p in placowki:
        nid, title, address, city, postal_code, phone, email, website, voivodeship_name, created, changed = p
        
        # Sprawdź czy placówka już istnieje
        if MedicalFacility.objects.filter(name=title, address=address, city=city).exists():
            continue
        
        # Znajdź lub utwórz województwo
        voivodeship = None
        if voivodeship_name:
            voivodeship, _ = Voivodeship.objects.get_or_create(name=voivodeship_name)
        
        # Utwórz nową placówkę
        facility = MedicalFacility(
            name=title,
            address=address,
            city=city,
            postal_code=postal_code,
            phone=phone,
            email=email,
            website=website,
            voivodeship=voivodeship,
            status='approved',
            created_at=created,
            updated_at=changed
        )
        facility.save()
        
        # Dodaj typy placówek
        cursor.execute("SELECT typ FROM placowki_typy WHERE placowka_id = ?", (nid,))
        for (typ,) in cursor.fetchall():
            ft, _ = FacilityType.objects.get_or_create(name=typ)
            facility.facility_types.add(ft)
        
        # Dodaj typy terapii
        cursor.execute("SELECT terapia FROM placowki_terapie WHERE placowka_id = ?", (nid,))
        for (terapia,) in cursor.fetchall():
            tt, _ = TherapyType.objects.get_or_create(name=terapia)
            facility.therapy_types.add(tt)
        
        # Dodaj grupy wiekowe
        cursor.execute("SELECT grupa FROM placowki_grupy_wiekowe WHERE placowka_id = ?", (nid,))
        for (grupa,) in cursor.fetchall():
            ag, _ = AgeGroup.objects.get_or_create(name=grupa)
            facility.age_groups.add(ag)
        
        imported_placowki += 1
    
    # Importuj oceny
    cursor.execute("SELECT * FROM oceny")
    oceny = cursor.fetchall()
    
    imported_oceny = 0
    for o in oceny:
        _, placowka_id, username, overall_rating, staff_rating, facilities_rating, treatment_rating, comment, comment_text, created, changed = o
        
        # Znajdź placówkę
        cursor.execute("SELECT title FROM placowki WHERE id = ?", (placowka_id,))
        placowka_title = cursor.fetchone()
        
        if not placowka_title:
            continue
        
        facility = MedicalFacility.objects.filter(name=placowka_title[0]).first()
        
        if not facility:
            continue
        
        # Sprawdź czy ocena już istnieje
        if FacilityRating.objects.filter(facility=facility, comment=comment).exists():
            continue
        
        # Utwórz użytkownika jeśli nie istnieje
        user = None
        if username != 'Anonymous':
            user, _ = User.objects.get_or_create(
                username=username,
                defaults={'email': f'{username}@example.com'}
            )
        
        # Utwórz nową ocenę
        rating = FacilityRating(
            facility=facility,
            user=user,
            overall_rating=overall_rating,
            staff_rating=staff_rating,
            facilities_rating=facilities_rating,
            treatment_rating=treatment_rating,
            comment=comment,
            comment_text=comment_text,
            status='approved',
            created_at=created,
            updated_at=changed
        )
        rating.save()
        
        imported_oceny += 1
    
    # Zamknij połączenie z tymczasową bazą
    conn.close()
    
    # Usuń tymczasową bazę
    os.unlink(temp_db_path)
    
    print(f"Zaimportowano {imported_placowki} placówek i {imported_oceny} ocen.")

if __name__ == "__main__":
    import_data()