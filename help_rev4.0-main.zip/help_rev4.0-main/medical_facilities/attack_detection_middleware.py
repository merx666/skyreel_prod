"""
Middleware do detekcji prób ataków (XSS, SQL Injection).
Zgodny z wymaganiami 1.1-1.6, 2.1-2.6, 3.6.
"""
from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache
from django.http import HttpResponseForbidden
from django.shortcuts import render
from .security_utils import InputSanitizer
from .models import SecurityEvent, AuditLog
import logging

logger = logging.getLogger('security')


class AttackDetectionMiddleware(MiddlewareMixin):
    """
    Middleware sprawdzający wszystkie dane wejściowe pod kątem prób ataków.
    Wykrywa XSS i SQL Injection w GET/POST parametrach.
    """
    
    # Ścieżki wykluczone z sprawdzania (admin, static, media)
    EXCLUDED_PATHS = [
        '/static/',
        '/media/',
        '/favicon.ico',
        '/jsi18n/',
    ]
    
    # Maksymalna liczba prób ataku przed zablokowaniem IP
    MAX_ATTACK_ATTEMPTS = 3
    BLOCK_DURATION = 3600  # 1 godzina w sekundach
    
    def process_request(self, request):
        """Sprawdza dane wejściowe przed przetworzeniem requestu."""
        # Pomiń wykluczone ścieżki
        if any(request.path.startswith(excluded) for excluded in self.EXCLUDED_PATHS):
            return None
        
        # Pobierz IP
        ip_address = self.get_client_ip(request)
        
        # Sprawdź czy IP jest zablokowane
        if self.is_ip_blocked(ip_address):
            logger.warning(f"Blocked IP attempted access: {ip_address} on {request.path}")
            return HttpResponseForbidden(
                "Your IP has been temporarily blocked due to suspicious activity. "
                "Please contact the administrator if you believe this is an error."
            )
        
        # Sprawdź parametry GET
        attack_detected = False
        attack_type = None
        attack_data = None
        
        for key, value in request.GET.items():
            if isinstance(value, str):
                if InputSanitizer.detect_xss_attempt(value):
                    attack_detected = True
                    attack_type = 'XSS_DETECTED'
                    attack_data = {'parameter': key, 'value': value[:100], 'method': 'GET'}
                    break
                elif InputSanitizer.detect_sql_injection_attempt(value):
                    attack_detected = True
                    attack_type = 'SQL_INJECTION'
                    attack_data = {'parameter': key, 'value': value[:100], 'method': 'GET'}
                    break
        
        # Sprawdź parametry POST (tylko jeśli nie wykryto w GET)
        if not attack_detected and request.method == 'POST':
            for key, value in request.POST.items():
                if isinstance(value, str):
                    if InputSanitizer.detect_xss_attempt(value):
                        attack_detected = True
                        attack_type = 'XSS_DETECTED'
                        attack_data = {'parameter': key, 'value': value[:100], 'method': 'POST'}
                        break
                    elif InputSanitizer.detect_sql_injection_attempt(value):
                        attack_detected = True
                        attack_type = 'SQL_INJECTION'
                        attack_data = {'parameter': key, 'value': value[:100], 'method': 'POST'}
                        break
        
        # Jeśli wykryto atak
        if attack_detected:
            self.handle_attack_detected(request, ip_address, attack_type, attack_data)
            
            # Sprawdź liczbę prób ataków
            attempts = self.increment_attack_counter(ip_address)
            
            if attempts >= self.MAX_ATTACK_ATTEMPTS:
                self.block_ip(ip_address)
                logger.critical(
                    f"IP {ip_address} blocked after {attempts} attack attempts. "
                    f"Last attack: {attack_type} on {request.path}"
                )
                return HttpResponseForbidden(
                    "Your IP has been blocked due to multiple attack attempts. "
                    "Contact the administrator if you believe this is an error."
                )
            
            # Zwróć błąd 403 dla pojedynczej próby ataku
            logger.warning(
                f"Attack attempt {attempts}/{self.MAX_ATTACK_ATTEMPTS} from {ip_address}: "
                f"{attack_type} on {request.path}"
            )
            return render(request, 'errors/attack_detected.html', {
                'attack_type': attack_type,
                'attempts_left': self.MAX_ATTACK_ATTEMPTS - attempts,
            }, status=403)
        
        return None
    
    def handle_attack_detected(self, request, ip_address, attack_type, attack_data):
        """Obsługuje wykryty atak - loguje i tworzy SecurityEvent."""
        try:
            # Log do AuditLog
            AuditLog.objects.create(
                user=request.user if request.user.is_authenticated else None,
                ip_address=ip_address,
                action='XSS_ATTEMPT' if attack_type == 'XSS_DETECTED' else 'SQL_INJECTION_ATTEMPT',
                model_name='',
                object_id='',
                request_path=request.path,
                request_method=request.method,
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                status_code=403,
                severity='WARNING',
                notes=f"Attack detected: {attack_type}"
            )
            
            # Utwórz SecurityEvent
            SecurityEvent.objects.create(
                event_type=attack_type,
                ip_address=ip_address,
                user=request.user if request.user.is_authenticated else None,
                description=f"Attack attempt detected: {attack_type} in {attack_data['method']} "
                           f"parameter '{attack_data['parameter']}'",
                request_data={
                    'path': request.path,
                    'method': request.method,
                    'parameter': attack_data['parameter'],
                    'value': attack_data['value'],
                    'user_agent': request.META.get('HTTP_USER_AGENT', ''),
                    'referer': request.META.get('HTTP_REFERER', ''),
                },
                severity='HIGH',
                action_taken='Request blocked, IP tracked'
            )
            
            logger.warning(
                f"Attack detected from {ip_address}: {attack_type} on {request.path} "
                f"in parameter '{attack_data['parameter']}'"
            )
        except Exception as e:
            logger.error(f"Failed to log attack detection: {str(e)}")
    
    def get_client_ip(self, request):
        """Pobiera adres IP klienta."""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR', 'unknown')
        return ip
    
    def increment_attack_counter(self, ip_address):
        """Zwiększa licznik prób ataków dla danego IP."""
        cache_key = f'attack_attempts_{ip_address}'
        attempts = cache.get(cache_key, 0)
        attempts += 1
        cache.set(cache_key, attempts, self.BLOCK_DURATION)
        return attempts
    
    def is_ip_blocked(self, ip_address):
        """Sprawdza czy IP jest zablokowane."""
        cache_key = f'blocked_ip_{ip_address}'
        return cache.get(cache_key, False)
    
    def block_ip(self, ip_address):
        """Blokuje IP na określony czas."""
        cache_key = f'blocked_ip_{ip_address}'
        cache.set(cache_key, True, self.BLOCK_DURATION)
        
        # Wyślij alert email do administratorów
        self.send_admin_alert(ip_address)
    
    def send_admin_alert(self, ip_address):
        """Wysyła alert email do administratorów o zablokowanym IP."""
        try:
            from django.core.mail import mail_admins
            from django.conf import settings
            
            if not settings.DEBUG:  # Tylko w produkcji
                subject = f'[Security Alert] IP Blocked: {ip_address}'
                message = (
                    f'IP address {ip_address} has been automatically blocked due to '
                    f'multiple attack attempts (XSS or SQL Injection).\n\n'
                    f'The IP will be unblocked automatically after 1 hour.\n\n'
                    f'Check the Security Dashboard for more details:\n'
                    f'{settings.SITE_URL}/admin/security-dashboard/\n\n'
                    f'Check Security Events:\n'
                    f'{settings.SITE_URL}/admin/medical_facilities/securityevent/'
                )
                mail_admins(subject, message, fail_silently=True)
                logger.info(f"Admin alert sent for blocked IP: {ip_address}")
        except Exception as e:
            logger.error(f"Failed to send admin alert: {str(e)}")
