"""
Middleware do śledzenia wizyt użytkowników na stronie.
"""
from django.utils import timezone
from django.utils.deprecation import MiddlewareMixin
from .models import PageVisit
import hashlib


class PageVisitMiddleware(MiddlewareMixin):
    """
    Middleware śledzący wizyty użytkowników na stronie.
    Rejestruje unikalne wizyty na podstawie sesji i ścieżki.
    """
    
    # Ścieżki, które nie powinny być śledzone
    EXCLUDED_PATHS = [
        '/admin/',
        '/static/',
        '/media/',
        '/api/',
        '/favicon.ico',
        '/robots.txt',
        '/sitemap.xml',
    ]
    
    def process_request(self, request):
        """Przetwarza request i rejestruje wizytę jeśli potrzeba."""
        # Pomiń jeśli ścieżka jest wykluczona
        path = request.path
        if any(path.startswith(excluded) for excluded in self.EXCLUDED_PATHS):
            return None
        
        # Pomiń jeśli to request AJAX (opcjonalnie)
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return None
        
        # Pobierz informacje o sesji
        try:
            session_key = request.session.session_key
            if not session_key:
                request.session.create()
                session_key = request.session.session_key
        except Exception:
            # Jeśli sesja nie może być utworzona, użyj IP jako identyfikator
            session_key = self.get_client_ip(request) or 'unknown'
        
        # Sprawdź czy to unikalna wizyta (ta sama sesja + ścieżka w ciągu ostatnich 30 minut)
        thirty_minutes_ago = timezone.now() - timezone.timedelta(minutes=30)
        
        # Sprawdź czy już była wizyta z tą samą sesją i ścieżką w ostatnich 30 minutach
        recent_visit = PageVisit.objects.filter(
            session_key=session_key,
            path=path,
            visited_at__gte=thirty_minutes_ago
        ).exists()
        
        is_unique = not recent_visit
        
        # Utwórz rekord wizyty
        try:
            PageVisit.objects.create(
                session_key=session_key,
                ip_address=self.get_client_ip(request),
                user=request.user if request.user.is_authenticated else None,
                path=path,
                referer=request.META.get('HTTP_REFERER', ''),
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                is_unique=is_unique,
            )
        except Exception:
            # Ignoruj błędy podczas rejestracji wizyt (nie przerywaj requestu)
            pass
        
        return None
    
    def get_client_ip(self, request):
        """Pobiera adres IP klienta z request."""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip

