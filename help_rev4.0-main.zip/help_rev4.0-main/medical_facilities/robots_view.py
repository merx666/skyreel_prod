from django.http import HttpResponse
from django.views.decorators.http import require_http_methods

@require_http_methods(["GET"])
def robots_txt(request):
    lines = [
        "User-agent: *",
        "Allow: /",
        "Disallow: /admin/",
        "Disallow: /api/",
        "Disallow: /static/",
        "Disallow: /media/",
        "",
        "Sitemap: https://hyperreal.info/help/sitemap.xml"
    ]
    return HttpResponse("\n".join(lines), content_type="text/plain")

