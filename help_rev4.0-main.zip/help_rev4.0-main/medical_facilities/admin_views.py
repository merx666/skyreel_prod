"""
Widoki dla panelu administratora - statystyki.
"""
from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from django.utils import timezone
from django.db.models import Count
from datetime import timedelta
from .models import PageVisit


@staff_member_required
def statistics_view(request):
    """Widok statystyk wejść unikalnych użytkowników."""
    now = timezone.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_ago = today - timedelta(days=7)
    month_ago = today - timedelta(days=30)
    
    # Statystyki unikalnych użytkowników
    unique_visitors_today = PageVisit.objects.filter(
        visited_at__gte=today,
        is_unique=True
    ).values('session_key').distinct().count()
    
    unique_visitors_week = PageVisit.objects.filter(
        visited_at__gte=week_ago,
        is_unique=True
    ).values('session_key').distinct().count()
    
    unique_visitors_month = PageVisit.objects.filter(
        visited_at__gte=month_ago,
        is_unique=True
    ).values('session_key').distinct().count()
    
    unique_visitors_all = PageVisit.objects.filter(
        is_unique=True
    ).values('session_key').distinct().count()
    
    # Statystyki wszystkich wizyt
    total_visits_today = PageVisit.objects.filter(visited_at__gte=today).count()
    total_visits_week = PageVisit.objects.filter(visited_at__gte=week_ago).count()
    total_visits_month = PageVisit.objects.filter(visited_at__gte=month_ago).count()
    total_visits_all = PageVisit.objects.count()
    
    # Statystyki zalogowanych użytkowników
    logged_users_today = PageVisit.objects.filter(
        visited_at__gte=today,
        user__isnull=False
    ).values('user').distinct().count()
    
    logged_users_week = PageVisit.objects.filter(
        visited_at__gte=week_ago,
        user__isnull=False
    ).values('user').distinct().count()
    
    logged_users_month = PageVisit.objects.filter(
        visited_at__gte=month_ago,
        user__isnull=False
    ).values('user').distinct().count()
    
    logged_users_all = PageVisit.objects.filter(
        user__isnull=False
    ).values('user').distinct().count()
    
    # Najpopularniejsze ścieżki (ostatnie 7 dni)
    popular_paths = PageVisit.objects.filter(
        visited_at__gte=week_ago
    ).values('path').annotate(
        visit_count=Count('id'),
        unique_count=Count('session_key', distinct=True)
    ).order_by('-visit_count')[:10]
    
    # Wizyty w czasie (ostatnie 7 dni, grupowane po dniach)
    visits_by_day = []
    day_names = ['Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota', 'Niedziela']
    max_unique_for_chart = 0
    for i in range(6, -1, -1):  # Od 6 do 0 (ostatnie 7 dni wstecz)
        day_start = today - timedelta(days=i)
        day_end = day_start + timedelta(days=1)
        day_visits = PageVisit.objects.filter(
            visited_at__gte=day_start,
            visited_at__lt=day_end
        ).count()
        day_unique = PageVisit.objects.filter(
            visited_at__gte=day_start,
            visited_at__lt=day_end,
            is_unique=True
        ).values('session_key').distinct().count()
        if day_unique > max_unique_for_chart:
            max_unique_for_chart = day_unique
        visits_by_day.append({
            'date': day_start.strftime('%Y-%m-%d'),
            'day_name': day_names[day_start.weekday()],
            'visits': day_visits,
            'unique': day_unique,
        })
    
    context = {
        'title': 'Statystyki wejść użytkowników',
        'unique_visitors_today': unique_visitors_today,
        'unique_visitors_week': unique_visitors_week,
        'unique_visitors_month': unique_visitors_month,
        'unique_visitors_all': unique_visitors_all,
        'total_visits_today': total_visits_today,
        'total_visits_week': total_visits_week,
        'total_visits_month': total_visits_month,
        'total_visits_all': total_visits_all,
        'logged_users_today': logged_users_today,
        'logged_users_week': logged_users_week,
        'logged_users_month': logged_users_month,
        'logged_users_all': logged_users_all,
        'popular_paths': popular_paths,
        'visits_by_day': visits_by_day,
        'max_unique_for_chart': max_unique_for_chart or 1,
    }
    return render(request, 'admin/statistics.html', context)

