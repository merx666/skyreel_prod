from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify
import uuid


class Voivodeship(models.Model):
    """Model reprezentujący województwa w Polsce."""
    name = models.CharField(max_length=50, unique=True, verbose_name="Nazwa województwa")
    slug = models.SlugField(max_length=50, unique=True, blank=True)
    
    class Meta:
        verbose_name = "Województwo"
        verbose_name_plural = "Województwa"
        ordering = ['name']
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    @property
    def is_currently_open(self):
        """Sprawdza czy placówka jest obecnie otwarta."""
        # Prosta implementacja - zawsze zwraca True
        # W przyszłości można dodać logikę sprawdzania godzin otwarcia
        return True
    
    def __str__(self):
        return self.name


class AddictionType(models.Model):
    """Model reprezentujący typy uzależnień."""
    name = models.CharField(max_length=100, unique=True, verbose_name="Typ uzależnienia")
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    description = models.TextField(blank=True, verbose_name="Opis")
    icon = models.CharField(max_length=50, blank=True, help_text="Klasa ikony Font Awesome")
    
    class Meta:
        verbose_name = "Typ uzależnienia"
        verbose_name_plural = "Typy uzależnień"
        ordering = ['name']
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.name


class FacilityType(models.Model):
    """Model reprezentujący typy placówek medycznych."""
    name = models.CharField(max_length=100, unique=True, verbose_name="Typ placówki")
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    description = models.TextField(blank=True, verbose_name="Opis")
    icon = models.CharField(max_length=50, blank=True, help_text="Klasa ikony Font Awesome")
    
    class Meta:
        verbose_name = "Typ placówki"
        verbose_name_plural = "Typy placówek"
        ordering = ['name']
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.name


class TherapyType(models.Model):
    """Model reprezentujący typy terapii oferowane przez placówki."""
    name = models.CharField(max_length=100, unique=True, verbose_name="Typ terapii")
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    description = models.TextField(blank=True, verbose_name="Opis")
    
    class Meta:
        verbose_name = "Typ terapii"
        verbose_name_plural = "Typy terapii"
        ordering = ['name']
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.name


class AgeGroup(models.Model):
    """Model reprezentujący grupy wiekowe obsługiwane przez placówki."""
    name = models.CharField(max_length=50, unique=True, verbose_name="Grupa wiekowa")
    min_age = models.PositiveIntegerField(null=True, blank=True, verbose_name="Minimalny wiek")
    max_age = models.PositiveIntegerField(null=True, blank=True, verbose_name="Maksymalny wiek")
    
    class Meta:
        verbose_name = "Grupa wiekowa"
        verbose_name_plural = "Grupy wiekowe"
        ordering = ['min_age']
    
    def __str__(self):
        return self.name


class MedicalFacility(models.Model):
    """Model główny reprezentujący placówkę medyczną."""
    
    STATUS_CHOICES = [
        ('pending', 'Oczekuje na zatwierdzenie'),
        ('approved', 'Zatwierdzona'),
        ('rejected', 'Odrzucona'),
        ('suspended', 'Zawieszona'),
    ]
    
    # Podstawowe informacje
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200, verbose_name="Nazwa placówki")
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    description = models.TextField(blank=True, verbose_name="Opis placówki")
    
    # Adres i lokalizacja
    street_address = models.CharField(max_length=200, verbose_name="Ulica i numer")
    city = models.CharField(max_length=100, verbose_name="Miasto")
    postal_code = models.CharField(max_length=10, verbose_name="Kod pocztowy")
    voivodeship = models.ForeignKey(Voivodeship, on_delete=models.CASCADE, verbose_name="Województwo")
    
    # Współrzędne geograficzne
    latitude = models.DecimalField(
        max_digits=10, decimal_places=8, null=True, blank=True,
        verbose_name="Szerokość geograficzna"
    )
    longitude = models.DecimalField(
        max_digits=11, decimal_places=8, null=True, blank=True,
        verbose_name="Długość geograficzna"
    )
    
    # Dane kontaktowe
    phone = models.CharField(max_length=20, blank=True, verbose_name="Telefon")
    email = models.EmailField(blank=True, verbose_name="Email")
    website = models.URLField(blank=True, verbose_name="Strona internetowa")
    
    # Kategorie i typy
    facility_types = models.ManyToManyField(FacilityType, verbose_name="Typy placówki")
    therapy_types = models.ManyToManyField(TherapyType, blank=True, verbose_name="Typy terapii")
    age_groups = models.ManyToManyField(AgeGroup, blank=True, verbose_name="Grupy wiekowe")
    
    # Dodatkowe informacje
    is_public = models.BooleanField(default=True, verbose_name="Placówka publiczna")
    is_private = models.BooleanField(default=False, verbose_name="Placówka prywatna")
    has_emergency_service = models.BooleanField(default=False, verbose_name="Służba ratunkowa")
    accepts_nfz = models.BooleanField(default=True, verbose_name="Przyjmuje NFZ")
    
    # Godziny pracy (opcjonalne)
    opening_hours = models.TextField(blank=True, verbose_name="Godziny otwarcia")
    
    # System moderacji
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="Status")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, 
                                   related_name='created_facilities', verbose_name="Utworzona przez")
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='approved_facilities', verbose_name="Zatwierdzona przez")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Data utworzenia")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Data aktualizacji")
    approved_at = models.DateTimeField(null=True, blank=True, verbose_name="Data zatwierdzenia")
    
    # Notatki moderatora
    moderator_notes = models.TextField(blank=True, verbose_name="Notatki moderatora")
    
    class Meta:
        verbose_name = "Placówka medyczna"
        verbose_name_plural = "Placówki medyczne"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['voivodeship']),
            models.Index(fields=['created_at']),
        ]
    
    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1
            while MedicalFacility.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return reverse('medical_facilities:facility_detail', kwargs={'slug': self.slug})
    
    def get_full_address(self):
        return f"{self.street_address}, {self.postal_code} {self.city}"
    
    def get_average_rating(self):
        """Oblicza średnią ocenę placówki."""
        ratings = self.ratings.filter(status='approved')
        if ratings.exists():
            return ratings.aggregate(models.Avg('overall_rating'))['overall_rating__avg']
        return None
    
    def get_ratings_count(self):
        """Zwraca liczbę zatwierdzonych ocen."""
        return self.ratings.filter(status='approved').count()
    
    def is_approved(self):
        return self.status == 'approved'
    
    def approve(self, approved_by_user):
        """Zatwierdza placówkę."""
        self.status = 'approved'
        self.approved_by = approved_by_user
        self.approved_at = timezone.now()
        self.save()
    
    def reject(self, notes=''):
        """Odrzuca placówkę."""
        self.status = 'rejected'
        if notes:
            self.moderator_notes = notes
        self.save()
    
    def is_currently_open(self):
        """Sprawdza czy placówka jest obecnie otwarta."""
        # Prosta implementacja - zawsze zwraca True
        # W przyszłości można dodać logikę sprawdzania godzin otwarcia
        return True
    
    def __str__(self):
        return f"{self.name} - {self.city}"


class FacilityRating(models.Model):
    """Model reprezentujący ocenę placówki medycznej."""
    
    STATUS_CHOICES = [
        ('pending', 'Oczekuje na zatwierdzenie'),
        ('approved', 'Zatwierdzona'),
        ('rejected', 'Odrzucona'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    facility = models.ForeignKey(MedicalFacility, on_delete=models.CASCADE, related_name='ratings')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='facility_ratings', null=True, blank=True)
    
    # Oceny (1-5)
    overall_rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Ocena ogólna"
    )
    staff_rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Ocena personelu", null=True, blank=True
    )
    facilities_rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Ocena wyposażenia", null=True, blank=True
    )
    treatment_rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Ocena leczenia", null=True, blank=True
    )
    rules_rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Ocena zasad i wymagań", null=True, blank=True
    )
    atmosphere_rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Ocena atmosfery", null=True, blank=True
    )
    
    # Komentarz
    comment = models.TextField(blank=True, verbose_name="Komentarz")
    
    # System moderacji
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="Status")
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='approved_ratings', verbose_name="Zatwierdzona przez")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Data utworzenia")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Data aktualizacji")
    approved_at = models.DateTimeField(null=True, blank=True, verbose_name="Data zatwierdzenia")
    
    # Notatki moderatora
    moderator_notes = models.TextField(blank=True, verbose_name="Notatki moderatora")
    
    class Meta:
        verbose_name = "Ocena placówki"
        verbose_name_plural = "Oceny placówek"
        ordering = ['-created_at']
        # unique_together = ['facility', 'user']  # Wyłączone - brak wymagania logowania
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['facility', 'status']),
            models.Index(fields=['created_at']),
        ]
    
    def approve(self, approved_by_user):
        """Zatwierdza ocenę."""
        self.status = 'approved'
        self.approved_by = approved_by_user
        self.approved_at = timezone.now()
        self.save()
    
    def reject(self, notes=''):
        """Odrzuca ocenę."""
        self.status = 'rejected'
        if notes:
            self.moderator_notes = notes
        self.save()
    
    def __str__(self):
        return f"Ocena {self.overall_rating}/5 dla {self.facility.name} od {self.user.username}"


class FacilityImage(models.Model):
    """Model reprezentujący zdjęcia placówek medycznych."""
    facility = models.ForeignKey(MedicalFacility, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='facility_images/', verbose_name="Zdjęcie")
    caption = models.CharField(max_length=200, blank=True, verbose_name="Opis zdjęcia")
    is_primary = models.BooleanField(default=False, verbose_name="Zdjęcie główne")
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Zdjęcie placówki"
        verbose_name_plural = "Zdjęcia placówek"
        ordering = ['-is_primary', '-created_at']
    
    def __str__(self):
        return f"Zdjęcie {self.facility.name}"


class PageVisit(models.Model):
    """Model reprezentujący wizyty użytkowników na stronie."""
    session_key = models.CharField(max_length=40, db_index=True, verbose_name="Klucz sesji")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="Adres IP")
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Użytkownik")
    path = models.CharField(max_length=255, db_index=True, verbose_name="Ścieżka")
    referer = models.URLField(blank=True, verbose_name="Referer")
    user_agent = models.TextField(blank=True, verbose_name="User Agent")
    visited_at = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="Data wizyty")
    is_unique = models.BooleanField(default=True, verbose_name="Unikalna wizyta")
    
    class Meta:
        verbose_name = "Wizyta"
        verbose_name_plural = "Wizyty"
        ordering = ['-visited_at']
        indexes = [
            models.Index(fields=['session_key', 'visited_at']),
            models.Index(fields=['path', 'visited_at']),
            models.Index(fields=['visited_at']),
        ]
    
    def __str__(self):
        user_info = self.user.username if self.user else f"Session: {self.session_key[:8]}"
        return f"Wizyta: {self.path} - {user_info} - {self.visited_at.strftime('%Y-%m-%d %H:%M')}"


# Security and Audit Models

class AuditLog(models.Model):
    """
    Model logowania audytu - rejestruje wszystkie akcje użytkowników i administratorów.
    Zgodny z wymaganiami 3.1-3.6.
    """
    
    # Podstawowe informacje
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="Czas zdarzenia")
    user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        verbose_name="Użytkownik"
    )
    ip_address = models.GenericIPAddressField(db_index=True, verbose_name="Adres IP")
    
    # Akcja
    ACTION_CHOICES = [
        ('CREATE', 'Utworzenie'),
        ('UPDATE', 'Aktualizacja'),
        ('DELETE', 'Usunięcie'),
        ('VIEW', 'Wyświetlenie'),
        ('APPROVE', 'Zatwierdzenie'),
        ('REJECT', 'Odrzucenie'),
        ('LOGIN', 'Logowanie'),
        ('LOGOUT', 'Wylogowanie'),
        ('LOGIN_FAILED', 'Nieudane logowanie'),
        ('RATE_LIMIT_EXCEEDED', 'Przekroczenie limitu żądań'),
        ('XSS_ATTEMPT', 'Próba ataku XSS'),
        ('SQL_INJECTION_ATTEMPT', 'Próba SQL Injection'),
        ('CSRF_FAILURE', 'Błąd CSRF'),
        ('EXPORT', 'Eksport danych'),
        ('BULK_ACTION', 'Akcja masowa'),
    ]
    action = models.CharField(
        max_length=50,
        choices=ACTION_CHOICES,
        db_index=True,
        verbose_name="Akcja"
    )
    
    # Obiekt
    model_name = models.CharField(max_length=100, verbose_name="Nazwa modelu")
    object_id = models.CharField(max_length=255, verbose_name="ID obiektu")
    object_repr = models.CharField(
        max_length=200,
        blank=True,
        verbose_name="Reprezentacja obiektu"
    )
    
    # Szczegóły
    changes = models.JSONField(
        null=True,
        blank=True,
        verbose_name="Szczegóły zmian",
        help_text="JSON z informacjami o zmianach (przed/po)"
    )
    request_path = models.CharField(max_length=500, verbose_name="Ścieżka żądania")
    request_method = models.CharField(
        max_length=10,
        default='GET',
        verbose_name="Metoda HTTP"
    )
    user_agent = models.TextField(verbose_name="User Agent")
    status_code = models.IntegerField(default=200, verbose_name="Kod statusu HTTP")
    
    # Dodatkowe dane
    SEVERITY_CHOICES = [
        ('INFO', 'Informacja'),
        ('WARNING', 'Ostrzeżenie'),
        ('ERROR', 'Błąd'),
        ('CRITICAL', 'Krytyczny'),
    ]
    severity = models.CharField(
        max_length=20,
        choices=SEVERITY_CHOICES,
        default='INFO',
        verbose_name="Poziom ważności"
    )
    notes = models.TextField(blank=True, verbose_name="Notatki")
    
    class Meta:
        verbose_name = "Log audytu"
        verbose_name_plural = "Logi audytu"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['timestamp', 'action']),
            models.Index(fields=['ip_address', 'timestamp']),
            models.Index(fields=['user', 'timestamp']),
            models.Index(fields=['severity', 'timestamp']),
        ]
    
    def __str__(self):
        user_str = str(self.user) if self.user else 'Anonymous'
        return f"{self.timestamp.strftime('%Y-%m-%d %H:%M:%S')} - {self.action} - {user_str}"
    
    def get_user_display(self):
        """Zwraca czytelną reprezentację użytkownika."""
        if self.user:
            return f"{self.user.username} ({self.user.get_full_name() or self.user.email})"
        return "Użytkownik anonimowy"
    
    def get_severity_badge_class(self):
        """Zwraca klasę CSS dla badge'a poziomu ważności."""
        severity_classes = {
            'INFO': 'badge-info',
            'WARNING': 'badge-warning',
            'ERROR': 'badge-danger',
            'CRITICAL': 'badge-dark',
        }
        return severity_classes.get(self.severity, 'badge-secondary')


class SecurityEvent(models.Model):
    """
    Model dla zdarzeń bezpieczeństwa wymagających uwagi administratora.
    Zgodny z wymaganiami 3.6, 10.7.
    """
    
    timestamp = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        verbose_name="Czas zdarzenia"
    )
    
    EVENT_TYPE_CHOICES = [
        ('BRUTE_FORCE', 'Atak brute-force'),
        ('DDOS_ATTEMPT', 'Próba DDoS'),
        ('XSS_DETECTED', 'Wykryto XSS'),
        ('SQL_INJECTION', 'Wykryto SQL Injection'),
        ('SUSPICIOUS_PATTERN', 'Podejrzany wzorzec'),
        ('RATE_LIMIT_ABUSE', 'Nadużycie rate limit'),
        ('UNAUTHORIZED_ACCESS', 'Nieautoryzowany dostęp'),
        ('DATA_BREACH_ATTEMPT', 'Próba wycieku danych'),
    ]
    event_type = models.CharField(
        max_length=50,
        choices=EVENT_TYPE_CHOICES,
        db_index=True,
        verbose_name="Typ zdarzenia"
    )
    
    ip_address = models.GenericIPAddressField(
        db_index=True,
        verbose_name="Adres IP"
    )
    user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        verbose_name="Użytkownik"
    )
    
    description = models.TextField(verbose_name="Opis zdarzenia")
    request_data = models.JSONField(
        verbose_name="Dane żądania",
        help_text="Szczegóły żądania HTTP (headers, payload, etc.)"
    )
    
    SEVERITY_CHOICES = [
        ('LOW', 'Niski'),
        ('MEDIUM', 'Średni'),
        ('HIGH', 'Wysoki'),
        ('CRITICAL', 'Krytyczny'),
    ]
    severity = models.CharField(
        max_length=20,
        choices=SEVERITY_CHOICES,
        db_index=True,
        verbose_name="Poziom zagrożenia"
    )
    
    # Status rozwiązania
    resolved = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name="Rozwiązane"
    )
    resolved_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Data rozwiązania"
    )
    resolved_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='resolved_security_events',
        verbose_name="Rozwiązane przez"
    )
    resolution_notes = models.TextField(
        blank=True,
        verbose_name="Notatki rozwiązania"
    )
    
    # Akcje podjęte
    action_taken = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Podjęta akcja",
        help_text="np. 'IP zablokowany', 'Użytkownik powiadomiony'"
    )
    
    # Powiązane logi audytu
    related_audit_logs = models.ManyToManyField(
        AuditLog,
        blank=True,
        verbose_name="Powiązane logi audytu"
    )
    
    class Meta:
        verbose_name = "Zdarzenie bezpieczeństwa"
        verbose_name_plural = "Zdarzenia bezpieczeństwa"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['timestamp', 'event_type']),
            models.Index(fields=['ip_address', 'timestamp']),
            models.Index(fields=['resolved', 'severity']),
        ]
    
    def __str__(self):
        return f"{self.timestamp.strftime('%Y-%m-%d %H:%M:%S')} - {self.get_event_type_display()} - {self.ip_address}"
    
    def mark_as_resolved(self, user, notes=""):
        """Oznacza zdarzenie jako rozwiązane."""
        self.resolved = True
        self.resolved_at = timezone.now()
        self.resolved_by = user
        self.resolution_notes = notes
        self.save()
    
    def get_severity_badge_class(self):
        """Zwraca klasę CSS dla badge'a poziomu zagrożenia."""
        severity_classes = {
            'LOW': 'badge-info',
            'MEDIUM': 'badge-warning',
            'HIGH': 'badge-danger',
            'CRITICAL': 'badge-dark',
        }
        return severity_classes.get(self.severity, 'badge-secondary')
    
    def get_time_since_event(self):
        """Zwraca czas od zdarzenia w czytelnej formie."""
        from django.utils.timesince import timesince
        return timesince(self.timestamp)
