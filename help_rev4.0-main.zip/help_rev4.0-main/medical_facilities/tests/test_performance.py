"""
Testy wydajnościowe dla operacji masowych w panelu administratora.
Zgodne z wymaganiami 5.5, 5.6.
"""
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from medical_facilities.models import (
    MedicalFacility, Voivodeship, FacilityType, FacilityRating
)
import time


class BulkOperationsPerformanceTests(TestCase):
    """
    Testy wydajności operacji masowych (1000+ rekordów).
    Zgodne z wymaganiem 5.5.
    """
    
    def setUp(self):
        """Przygotowanie danych testowych."""
        self.admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@test.com',
            password='adminpass123'
        )
        self.client = Client()
        self.client.login(username='admin', password='adminpass123')
        
        # Utwórz województwo i typ placówki
        self.voivodeship = Voivodeship.objects.create(
            name='Mazowieckie',
            slug='mazowieckie'
        )
        self.facility_type = FacilityType.objects.create(
            name='Szpital',
            slug='szpital'
        )
    
    def test_bulk_create_1000_facilities_performance(self):
        """Test: Tworzenie 1000 placówek w rozsądnym czasie."""
        start_time = time.time()
        
        # Utwórz 1000 placówek używając bulk_create
        facilities = []
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city='Warszawa',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeship,
                status='pending',
                created_by=self.admin_user
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Dodaj relacje many-to-many
        for facility in MedicalFacility.objects.all():
            facility.facility_types.add(self.facility_type)
        
        duration = time.time() - start_time
        
        # Operacja powinna zająć mniej niż 5 sekund
        self.assertLess(duration, 5.0, 
                       f"Tworzenie 1000 placówek zajęło {duration:.2f}s (limit: 5s)")
        
        # Sprawdź czy wszystkie placówki zostały utworzone
        self.assertEqual(MedicalFacility.objects.count(), 1000)
    
    def test_bulk_approve_1000_facilities_performance(self):
        """Test: Masowe zatwierdzanie 1000 placówek w rozsądnym czasie."""
        # Utwórz 1000 placówek oczekujących
        facilities = []
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city='Warszawa',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeship,
                status='pending',
                created_by=self.admin_user
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Dodaj relacje many-to-many
        for facility in MedicalFacility.objects.all():
            facility.facility_types.add(self.facility_type)
        
        # Zmierz czas zatwierdzania
        start_time = time.time()
        
        MedicalFacility.objects.filter(status='pending').update(
            status='approved',
            approved_by=self.admin_user,
            approved_at=timezone.now()
        )
        
        duration = time.time() - start_time
        
        # Operacja powinna zająć mniej niż 2 sekundy
        self.assertLess(duration, 2.0,
                       f"Zatwierdzanie 1000 placówek zajęło {duration:.2f}s (limit: 2s)")
        
        # Sprawdź czy wszystkie placówki zostały zatwierdzone
        self.assertEqual(
            MedicalFacility.objects.filter(status='approved').count(),
            1000
        )
    
    def test_bulk_reject_1000_facilities_performance(self):
        """Test: Masowe odrzucanie 1000 placówek w rozsądnym czasie."""
        # Utwórz 1000 placówek oczekujących
        facilities = []
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city='Warszawa',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeship,
                status='pending',
                created_by=self.admin_user
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Dodaj relacje many-to-many
        for facility in MedicalFacility.objects.all():
            facility.facility_types.add(self.facility_type)
        
        # Zmierz czas odrzucania
        start_time = time.time()
        
        MedicalFacility.objects.filter(status='pending').update(
            status='rejected'
        )
        
        duration = time.time() - start_time
        
        # Operacja powinna zająć mniej niż 2 sekundy
        self.assertLess(duration, 2.0,
                       f"Odrzucanie 1000 placówek zajęło {duration:.2f}s (limit: 2s)")
        
        # Sprawdź czy wszystkie placówki zostały odrzucone
        self.assertEqual(
            MedicalFacility.objects.filter(status='rejected').count(),
            1000
        )
    
    def test_bulk_delete_1000_facilities_performance(self):
        """Test: Usuwanie 1000 placówek w rozsądnym czasie."""
        # Utwórz 1000 placówek
        facilities = []
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city='Warszawa',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeship,
                status='rejected',
                created_by=self.admin_user
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Zmierz czas usuwania
        start_time = time.time()
        
        MedicalFacility.objects.filter(status='rejected').delete()
        
        duration = time.time() - start_time
        
        # Operacja powinna zająć mniej niż 3 sekundy
        self.assertLess(duration, 3.0,
                       f"Usuwanie 1000 placówek zajęło {duration:.2f}s (limit: 3s)")
        
        # Sprawdź czy wszystkie placówki zostały usunięte
        self.assertEqual(MedicalFacility.objects.count(), 0)


class QueryPerformanceTests(TestCase):
    """
    Testy wydajności zapytań z filtrami.
    Zgodne z wymaganiem 5.5.
    """
    
    def setUp(self):
        """Przygotowanie danych testowych."""
        self.admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@test.com',
            password='adminpass123'
        )
        
        # Utwórz województwa
        self.voivodeships = []
        for i in range(5):
            voivodeship = Voivodeship.objects.create(
                name=f'Województwo {i}',
                slug=f'wojewodztwo-{i}'
            )
            self.voivodeships.append(voivodeship)
        
        # Utwórz typy placówek
        self.facility_types = []
        for i in range(3):
            facility_type = FacilityType.objects.create(
                name=f'Typ {i}',
                slug=f'typ-{i}'
            )
            self.facility_types.append(facility_type)
        
        # Utwórz 1000 placówek z różnymi statusami i województwami
        facilities = []
        statuses = ['pending', 'approved', 'rejected']
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city=f'Miasto {i % 10}',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeships[i % 5],
                status=statuses[i % 3],
                created_by=self.admin_user
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Dodaj relacje many-to-many
        for facility in MedicalFacility.objects.all():
            facility.facility_types.add(self.facility_types[int(facility.name.split()[1]) % 3])
    
    def test_filter_by_status_performance(self):
        """Test: Filtrowanie po statusie jest szybkie."""
        start_time = time.time()
        
        pending_facilities = MedicalFacility.objects.filter(status='pending')
        count = pending_facilities.count()
        
        duration = time.time() - start_time
        
        # Zapytanie powinno zająć mniej niż 0.1 sekundy
        self.assertLess(duration, 0.1,
                       f"Filtrowanie po statusie zajęło {duration:.4f}s (limit: 0.1s)")
        
        # Sprawdź czy wynik jest poprawny
        self.assertGreater(count, 0)
    
    def test_filter_by_voivodeship_performance(self):
        """Test: Filtrowanie po województwie jest szybkie."""
        start_time = time.time()
        
        facilities = MedicalFacility.objects.filter(
            voivodeship=self.voivodeships[0]
        )
        count = facilities.count()
        
        duration = time.time() - start_time
        
        # Zapytanie powinno zająć mniej niż 0.1 sekundy
        self.assertLess(duration, 0.1,
                       f"Filtrowanie po województwie zajęło {duration:.4f}s (limit: 0.1s)")
        
        # Sprawdź czy wynik jest poprawny
        self.assertGreater(count, 0)
    
    def test_filter_by_multiple_criteria_performance(self):
        """Test: Filtrowanie po wielu kryteriach jest szybkie."""
        start_time = time.time()
        
        facilities = MedicalFacility.objects.filter(
            status='approved',
            voivodeship=self.voivodeships[0],
            facility_types=self.facility_types[0]
        )
        count = facilities.count()
        
        duration = time.time() - start_time
        
        # Zapytanie powinno zająć mniej niż 0.2 sekundy
        self.assertLess(duration, 0.2,
                       f"Filtrowanie po wielu kryteriach zajęło {duration:.4f}s (limit: 0.2s)")
    
    def test_search_by_name_performance(self):
        """Test: Wyszukiwanie po nazwie jest szybkie."""
        start_time = time.time()
        
        facilities = MedicalFacility.objects.filter(
            name__icontains='Placówka 1'
        )
        count = facilities.count()
        
        duration = time.time() - start_time
        
        # Zapytanie powinno zająć mniej niż 0.2 sekundy
        self.assertLess(duration, 0.2,
                       f"Wyszukiwanie po nazwie zajęło {duration:.4f}s (limit: 0.2s)")
        
        # Sprawdź czy wynik jest poprawny
        self.assertGreater(count, 0)
    
    def test_complex_query_with_joins_performance(self):
        """Test: Złożone zapytanie z joinami jest szybkie."""
        start_time = time.time()
        
        facilities = MedicalFacility.objects.select_related(
            'voivodeship', 'created_by'
        ).prefetch_related(
            'facility_types', 'ratings'
        ).filter(
            status='approved',
            voivodeship__name__icontains='Województwo'
        )
        
        # Wymuszenie wykonania zapytania
        list(facilities[:100])
        
        duration = time.time() - start_time
        
        # Zapytanie powinno zająć mniej niż 0.5 sekundy
        self.assertLess(duration, 0.5,
                       f"Złożone zapytanie zajęło {duration:.4f}s (limit: 0.5s)")


class ExportPerformanceTests(TestCase):
    """
    Testy wydajności eksportu CSV.
    Zgodne z wymaganiem 5.5, 5.6.
    """
    
    def setUp(self):
        """Przygotowanie danych testowych."""
        self.admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@test.com',
            password='adminpass123'
        )
        self.client = Client()
        self.client.login(username='admin', password='adminpass123')
        
        # Utwórz województwo i typ placówki
        self.voivodeship = Voivodeship.objects.create(
            name='Mazowieckie',
            slug='mazowieckie'
        )
        self.facility_type = FacilityType.objects.create(
            name='Szpital',
            slug='szpital'
        )
        
        # Utwórz 1000 placówek
        facilities = []
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city='Warszawa',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeship,
                status='approved',
                created_by=self.admin_user,
                phone=f'+48123456{i:03d}',
                email=f'facility{i}@test.com'
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Dodaj relacje many-to-many
        for facility in MedicalFacility.objects.all():
            facility.facility_types.add(self.facility_type)
    
    def test_export_1000_facilities_to_csv_performance(self):
        """Test: Eksport 1000 placówek do CSV w rozsądnym czasie."""
        # Pobierz wszystkie placówki
        queryset = MedicalFacility.objects.all()
        
        start_time = time.time()
        
        # Symuluj eksport CSV (bez faktycznego zapisu do pliku)
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Nagłówki
        writer.writerow([
            'ID', 'Nazwa', 'Miasto', 'Województwo', 'Status',
            'Telefon', 'Email', 'NFZ', 'Ratownictwo',
            'Średnia ocena', 'Liczba ocen', 'Data utworzenia'
        ])
        
        # Dane
        for facility in queryset:
            writer.writerow([
                facility.id,
                facility.name,
                facility.city,
                facility.voivodeship.name if facility.voivodeship else '',
                facility.get_status_display(),
                facility.phone or '',
                facility.email or '',
                'Tak' if facility.accepts_nfz else 'Nie',
                'Tak' if facility.has_emergency_service else 'Nie',
                f"{facility.get_average_rating():.1f}" if facility.get_average_rating() else '-',
                facility.ratings.filter(status='approved').count(),
                facility.created_at.strftime('%Y-%m-%d %H:%M')
            ])
        
        duration = time.time() - start_time
        
        # Eksport powinien zająć mniej niż 3 sekundy
        self.assertLess(duration, 3.0,
                       f"Eksport 1000 placówek do CSV zajął {duration:.2f}s (limit: 3s)")
        
        # Sprawdź czy CSV zawiera dane
        csv_content = output.getvalue()
        self.assertGreater(len(csv_content), 0)
        self.assertIn('Placówka', csv_content)
    
    def test_export_with_ratings_performance(self):
        """Test: Eksport placówek z ocenami jest wydajny."""
        # Dodaj oceny do pierwszych 100 placówek
        facilities = MedicalFacility.objects.all()[:100]
        ratings = []
        
        for facility in facilities:
            for i in range(5):  # 5 ocen na placówkę
                rating = FacilityRating(
                    facility=facility,
                    user=self.admin_user,
                    overall_rating=4,
                    status='approved'
                )
                ratings.append(rating)
        
        FacilityRating.objects.bulk_create(ratings)
        
        # Eksport z optymalizacją zapytań
        start_time = time.time()
        
        queryset = MedicalFacility.objects.select_related(
            'voivodeship'
        ).prefetch_related(
            'ratings'
        ).all()
        
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        writer.writerow(['ID', 'Nazwa', 'Liczba ocen', 'Średnia ocena'])
        
        for facility in queryset:
            approved_ratings = [r for r in facility.ratings.all() if r.status == 'approved']
            avg_rating = sum(r.overall_rating for r in approved_ratings) / len(approved_ratings) if approved_ratings else 0
            
            writer.writerow([
                facility.id,
                facility.name,
                len(approved_ratings),
                f"{avg_rating:.1f}" if avg_rating else '-'
            ])
        
        duration = time.time() - start_time
        
        # Eksport z ocenami powinien zająć mniej niż 5 sekund
        self.assertLess(duration, 5.0,
                       f"Eksport z ocenami zajął {duration:.2f}s (limit: 5s)")


class PaginationPerformanceTests(TestCase):
    """
    Testy wydajności paginacji dużych zbiorów danych.
    """
    
    def setUp(self):
        """Przygotowanie danych testowych."""
        self.admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@test.com',
            password='adminpass123'
        )
        
        # Utwórz województwo i typ placówki
        self.voivodeship = Voivodeship.objects.create(
            name='Mazowieckie',
            slug='mazowieckie'
        )
        self.facility_type = FacilityType.objects.create(
            name='Szpital',
            slug='szpital'
        )
        
        # Utwórz 1000 placówek
        facilities = []
        for i in range(1000):
            facility = MedicalFacility(
                name=f'Placówka {i}',
                city='Warszawa',
                street_address=f'ul. Testowa {i}',
                postal_code='00-001',
                voivodeship=self.voivodeship,
                status='approved',
                created_by=self.admin_user
            )
            facilities.append(facility)
        
        MedicalFacility.objects.bulk_create(facilities)
        
        # Dodaj relacje many-to-many
        for facility in MedicalFacility.objects.all():
            facility.facility_types.add(self.facility_type)
    
    def test_first_page_load_performance(self):
        """Test: Ładowanie pierwszej strony jest szybkie."""
        start_time = time.time()
        
        # Pobierz pierwszą stronę (100 rekordów)
        facilities = MedicalFacility.objects.all()[:100]
        list(facilities)  # Wymuszenie wykonania zapytania
        
        duration = time.time() - start_time
        
        # Powinno zająć mniej niż 0.2 sekundy
        self.assertLess(duration, 0.2,
                       f"Ładowanie pierwszej strony zajęło {duration:.4f}s (limit: 0.2s)")
    
    def test_last_page_load_performance(self):
        """Test: Ładowanie ostatniej strony jest szybkie."""
        start_time = time.time()
        
        # Pobierz ostatnią stronę (100 rekordów)
        total_count = MedicalFacility.objects.count()
        facilities = MedicalFacility.objects.all()[total_count-100:total_count]
        list(facilities)  # Wymuszenie wykonania zapytania
        
        duration = time.time() - start_time
        
        # Powinno zająć mniej niż 0.2 sekundy
        self.assertLess(duration, 0.2,
                       f"Ładowanie ostatniej strony zajęło {duration:.4f}s (limit: 0.2s)")
    
    def test_count_query_performance(self):
        """Test: Zliczanie rekordów jest szybkie."""
        start_time = time.time()
        
        count = MedicalFacility.objects.count()
        
        duration = time.time() - start_time
        
        # Powinno zająć mniej niż 0.05 sekundy
        self.assertLess(duration, 0.05,
                       f"Zliczanie rekordów zajęło {duration:.4f}s (limit: 0.05s)")
        
        self.assertEqual(count, 1000)
