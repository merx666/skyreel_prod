"""
Testy jednostkowe dla klasy InputSanitizer.
Zgodne z wymaganiami 5.1, 5.6.
"""
from django.test import TestCase
from django.core.exceptions import ValidationError
from medical_facilities.security_utils import InputSanitizer


class InputSanitizerSanitizeHtmlTests(TestCase):
    """Testy dla metody sanitize_html()"""
    
    def test_sanitize_html_removes_script_tags(self):
        """Test: Usuwa tagi <script>"""
        text = '<script>alert("XSS")</script>Hello'
        result = InputSanitizer.sanitize_html(text)
        self.assertNotIn('<script>', result)
        self.assertIn('Hello', result)
        # bleach usuwa tagi ale zachowuje zawartość tekstową
    
    def test_sanitize_html_removes_javascript_protocol(self):
        """Test: Usuwa protokół javascript:"""
        text = '<a href="javascript:alert(1)">Click</a>'
        result = InputSanitizer.sanitize_html(text)
        self.assertNotIn('javascript:', result)
    
    def test_sanitize_html_removes_event_handlers(self):
        """Test: Usuwa handlery zdarzeń (onclick, onerror, etc.)"""
        text = '<img src="x" onerror="alert(1)">'
        result = InputSanitizer.sanitize_html(text)
        self.assertNotIn('onerror', result)
        self.assertNotIn('alert', result)
    
    def test_sanitize_html_allows_safe_tags(self):
        """Test: Zachowuje bezpieczne tagi HTML"""
        text = '<p>Hello <strong>world</strong></p>'
        result = InputSanitizer.sanitize_html(text)
        self.assertIn('<p>', result)
        self.assertIn('<strong>', result)
        self.assertIn('Hello', result)
        self.assertIn('world', result)
    
    def test_sanitize_html_removes_iframe(self):
        """Test: Usuwa tagi <iframe>"""
        text = '<iframe src="evil.com"></iframe>Normal text'
        result = InputSanitizer.sanitize_html(text)
        self.assertNotIn('<iframe>', result)
        self.assertNotIn('evil.com', result)
        self.assertIn('Normal text', result)
    
    def test_sanitize_html_with_custom_allowed_tags(self):
        """Test: Używa niestandardowej listy dozwolonych tagów"""
        text = '<p>Paragraph</p><strong>Bold</strong>'
        result = InputSanitizer.sanitize_html(text, allowed_tags=['p'])
        self.assertIn('<p>', result)
        self.assertNotIn('<strong>', result)
        self.assertIn('Bold', result)  # Tekst powinien zostać
    
    def test_sanitize_html_handles_empty_string(self):
        """Test: Obsługuje pusty string"""
        result = InputSanitizer.sanitize_html('')
        self.assertEqual(result, '')
    
    def test_sanitize_html_handles_none(self):
        """Test: Obsługuje None"""
        result = InputSanitizer.sanitize_html(None)
        self.assertIsNone(result)
    
    def test_sanitize_html_removes_embed_tags(self):
        """Test: Usuwa tagi <embed>"""
        text = '<embed src="malicious.swf">Text'
        result = InputSanitizer.sanitize_html(text)
        self.assertNotIn('<embed>', result)
        self.assertIn('Text', result)
    
    def test_sanitize_html_removes_object_tags(self):
        """Test: Usuwa tagi <object>"""
        text = '<object data="malicious.swf"></object>Text'
        result = InputSanitizer.sanitize_html(text)
        self.assertNotIn('<object>', result)
        self.assertIn('Text', result)


class InputSanitizerValidatePhoneTests(TestCase):
    """Testy dla metody validate_phone()"""
    
    def test_validate_phone_accepts_valid_polish_number(self):
        """Test: Akceptuje prawidłowy polski numer"""
        phone = '123456789'
        result = InputSanitizer.validate_phone(phone)
        self.assertEqual(result, '123456789')
    
    def test_validate_phone_accepts_number_with_country_code(self):
        """Test: Akceptuje numer z kodem kraju"""
        phone = '+48123456789'
        result = InputSanitizer.validate_phone(phone)
        self.assertEqual(result, '+48123456789')
    
    def test_validate_phone_accepts_number_with_spaces(self):
        """Test: Akceptuje numer ze spacjami"""
        phone = '+48 123 456 789'
        result = InputSanitizer.validate_phone(phone)
        self.assertIn('123', result)
        self.assertIn('456', result)
    
    def test_validate_phone_accepts_number_with_dashes(self):
        """Test: Akceptuje numer z myślnikami"""
        phone = '123-456-789'
        result = InputSanitizer.validate_phone(phone)
        self.assertIn('123', result)
    
    def test_validate_phone_rejects_too_short_number(self):
        """Test: Odrzuca za krótki numer"""
        phone = '12345'
        with self.assertRaises(ValidationError) as context:
            InputSanitizer.validate_phone(phone)
        self.assertIn('Nieprawidłowy format', str(context.exception))
    
    def test_validate_phone_rejects_too_long_number(self):
        """Test: Odrzuca za długi numer"""
        phone = '1234567890123456'  # 16 cyfr
        with self.assertRaises(ValidationError) as context:
            InputSanitizer.validate_phone(phone)
        self.assertIn('Nieprawidłowy format', str(context.exception))
    
    def test_validate_phone_removes_invalid_characters(self):
        """Test: Usuwa nieprawidłowe znaki"""
        phone = '123-456-789abc'
        result = InputSanitizer.validate_phone(phone)
        self.assertNotIn('abc', result)
    
    def test_validate_phone_handles_empty_string(self):
        """Test: Obsługuje pusty string"""
        result = InputSanitizer.validate_phone('')
        self.assertEqual(result, '')
    
    def test_validate_phone_handles_none(self):
        """Test: Obsługuje None"""
        result = InputSanitizer.validate_phone(None)
        self.assertIsNone(result)
    
    def test_validate_phone_accepts_international_format(self):
        """Test: Akceptuje format międzynarodowy"""
        phone = '+1234567890'
        result = InputSanitizer.validate_phone(phone)
        self.assertIn('+', result)


class InputSanitizerValidatePostalCodeTests(TestCase):
    """Testy dla metody validate_postal_code()"""
    
    def test_validate_postal_code_accepts_valid_format(self):
        """Test: Akceptuje prawidłowy format XX-XXX"""
        postal_code = '00-001'
        result = InputSanitizer.validate_postal_code(postal_code)
        self.assertEqual(result, '00-001')
    
    def test_validate_postal_code_adds_dash_if_missing(self):
        """Test: Dodaje myślnik jeśli go brakuje"""
        postal_code = '00001'
        result = InputSanitizer.validate_postal_code(postal_code)
        self.assertEqual(result, '00-001')
    
    def test_validate_postal_code_accepts_with_spaces(self):
        """Test: Akceptuje kod ze spacjami"""
        postal_code = ' 00-001 '
        result = InputSanitizer.validate_postal_code(postal_code)
        self.assertEqual(result, '00-001')
    
    def test_validate_postal_code_rejects_invalid_format(self):
        """Test: Odrzuca nieprawidłowy format"""
        postal_code = '123'
        with self.assertRaises(ValidationError) as context:
            InputSanitizer.validate_postal_code(postal_code)
        self.assertIn('XX-XXX', str(context.exception))
    
    def test_validate_postal_code_rejects_letters(self):
        """Test: Odrzuca litery"""
        postal_code = 'AB-CDE'
        with self.assertRaises(ValidationError) as context:
            InputSanitizer.validate_postal_code(postal_code)
        self.assertIn('XX-XXX', str(context.exception))
    
    def test_validate_postal_code_rejects_too_long(self):
        """Test: Odrzuca za długi kod"""
        postal_code = '00-0001'
        with self.assertRaises(ValidationError) as context:
            InputSanitizer.validate_postal_code(postal_code)
        self.assertIn('XX-XXX', str(context.exception))
    
    def test_validate_postal_code_handles_empty_string(self):
        """Test: Obsługuje pusty string"""
        result = InputSanitizer.validate_postal_code('')
        self.assertEqual(result, '')
    
    def test_validate_postal_code_handles_none(self):
        """Test: Obsługuje None"""
        result = InputSanitizer.validate_postal_code(None)
        self.assertIsNone(result)


class InputSanitizerDetectXssAttemptTests(TestCase):
    """Testy dla metody detect_xss_attempt()"""
    
    def test_detect_xss_attempt_detects_script_tag(self):
        """Test: Wykrywa tag <script>"""
        text = '<script>alert("XSS")</script>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_javascript_protocol(self):
        """Test: Wykrywa protokół javascript:"""
        text = '<a href="javascript:alert(1)">Click</a>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_onerror(self):
        """Test: Wykrywa atrybut onerror"""
        text = '<img src="x" onerror="alert(1)">'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_onload(self):
        """Test: Wykrywa atrybut onload"""
        text = '<body onload="malicious()">'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_onclick(self):
        """Test: Wykrywa atrybut onclick"""
        text = '<div onclick="steal()">Click</div>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_onmouseover(self):
        """Test: Wykrywa atrybut onmouseover"""
        text = '<span onmouseover="attack()">Hover</span>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_iframe(self):
        """Test: Wykrywa tag <iframe>"""
        text = '<iframe src="evil.com"></iframe>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_eval(self):
        """Test: Wykrywa funkcję eval()"""
        text = 'eval(maliciousCode)'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_vbscript(self):
        """Test: Wykrywa protokół vbscript:"""
        text = '<a href="vbscript:msgbox(1)">Click</a>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_embed(self):
        """Test: Wykrywa tag <embed>"""
        text = '<embed src="malicious.swf">'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_detects_object(self):
        """Test: Wykrywa tag <object>"""
        text = '<object data="malicious.swf"></object>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)
    
    def test_detect_xss_attempt_accepts_safe_text(self):
        """Test: Nie wykrywa XSS w bezpiecznym tekście"""
        text = 'This is a normal text with <p>paragraph</p>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertFalse(result)
    
    def test_detect_xss_attempt_handles_empty_string(self):
        """Test: Obsługuje pusty string"""
        result = InputSanitizer.detect_xss_attempt('')
        self.assertFalse(result)
    
    def test_detect_xss_attempt_handles_none(self):
        """Test: Obsługuje None"""
        result = InputSanitizer.detect_xss_attempt(None)
        self.assertFalse(result)
    
    def test_detect_xss_attempt_case_insensitive(self):
        """Test: Wykrywanie jest case-insensitive"""
        text = '<SCRIPT>alert(1)</SCRIPT>'
        result = InputSanitizer.detect_xss_attempt(text)
        self.assertTrue(result)


class InputSanitizerDetectSqlInjectionAttemptTests(TestCase):
    """Testy dla metody detect_sql_injection_attempt()"""
    
    def test_detect_sql_injection_detects_or_equals(self):
        """Test: Wykrywa wzorzec OR 1=1"""
        text = "' OR 1=1 --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_and_equals(self):
        """Test: Wykrywa wzorzec AND 1=1"""
        text = "admin' AND 1=1 --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_drop_table(self):
        """Test: Wykrywa DROP TABLE"""
        text = "'; DROP TABLE users; --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_delete(self):
        """Test: Wykrywa DELETE"""
        text = "'; DELETE FROM users WHERE 1=1; --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_update(self):
        """Test: Wykrywa UPDATE"""
        text = "'; UPDATE users SET password='hacked'; --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_insert(self):
        """Test: Wykrywa INSERT"""
        text = "'; INSERT INTO users VALUES ('hacker', 'pass'); --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_union_select(self):
        """Test: Wykrywa UNION SELECT"""
        text = "' UNION SELECT * FROM users --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_comment(self):
        """Test: Wykrywa komentarze SQL (--) na końcu"""
        text = "admin' --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_multiline_comment(self):
        """Test: Wykrywa komentarze wieloliniowe /* */"""
        text = "admin' /* comment */ OR 1=1"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_or_string_equals(self):
        """Test: Wykrywa wzorzec ' OR '1'='1"""
        text = "' OR '1'='1"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_accepts_safe_text(self):
        """Test: Nie wykrywa SQL injection w bezpiecznym tekście"""
        text = "This is a normal text about medical facilities"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertFalse(result)
    
    def test_detect_sql_injection_handles_empty_string(self):
        """Test: Obsługuje pusty string"""
        result = InputSanitizer.detect_sql_injection_attempt('')
        self.assertFalse(result)
    
    def test_detect_sql_injection_handles_none(self):
        """Test: Obsługuje None"""
        result = InputSanitizer.detect_sql_injection_attempt(None)
        self.assertFalse(result)
    
    def test_detect_sql_injection_case_insensitive(self):
        """Test: Wykrywanie jest case-insensitive"""
        text = "' or 1=1 --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
    
    def test_detect_sql_injection_detects_alter_table(self):
        """Test: Wykrywa ALTER TABLE"""
        text = "; ALTER TABLE users ADD COLUMN hacked VARCHAR(255); --"
        result = InputSanitizer.detect_sql_injection_attempt(text)
        self.assertTrue(result)
