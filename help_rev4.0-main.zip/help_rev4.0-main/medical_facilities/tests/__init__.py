"""
Testy dla aplikacji medical_facilities.
"""
