from django.urls import path
from . import views

app_name = 'medical_facilities'

urlpatterns = [
    # Strony główne
    path('', views.home, name='home'),
    path('placowki/', views.FacilityListView.as_view(), name='facility_list'),
    path('placowka/<slug:slug>/', views.FacilityDetailView.as_view(), name='facility_detail'),
    
    # Dodawanie placówek i ocen
    path('dodaj-placowke/', views.add_facility, name='add_facility'),
    path('placowka/<slug:slug>/ocen/', views.add_rating, name='add_rating'),
    path('test-oceny/<slug:slug>/', views.TestRatingsView.as_view(), name='test_ratings'),
    
    # Strony informacyjne
    path('kontakt/', views.contact, name='contact'),
    path('polityka-prywatnosci/', views.privacy_policy, name='privacy'),
    path('mapa-placowek/', views.facility_map_view, name='facility_map'),
    path('api/map-data/', views.facility_map_data, name='facility_map_data'),
    path('statystyki/', views.statistics, name='statistics'),
    
    # API endpoints
    path('api/placowki/szukaj/', views.api_facilities_search, name='api_facilities_search'),
    path('api/placowka/<int:facility_id>/wspolrzedne/', views.api_facility_coordinates, name='api_facility_coordinates'),
    
    # Admin dashboard
    path('admin/security-dashboard/', views.security_dashboard, name='security_dashboard'),
]