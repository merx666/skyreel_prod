"""
Narzędzia pomocnicze dla aplikacji medical_facilities.
"""
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderServiceError
from decimal import Decimal
import time


def geocode_address(street_address, city, postal_code=None, country='Polska'):
    """
    Geocoduje adres i zwraca współrzędne geograficzne.
    
    Args:
        street_address: Ulica i numer
        city: Miasto
        postal_code: Kod pocztowy (opcjonalny)
        country: Kraj (domyślnie Polska)
    
    Returns:
        tuple: (latitude, longitude) lub (None, None) w przypadku błędu
    """
    try:
        geolocator = Nominatim(user_agent="HyperrealHelp/1.0")
        
        # Buduj pełny adres
        address_parts = [street_address, city]
        if postal_code:
            address_parts.append(postal_code)
        address_parts.append(country)
        
        full_address = ", ".join(filter(None, address_parts))
        
        # Próbuj z pełnym adresem
        location = geolocator.geocode(full_address, timeout=10, exactly_one=True)
        
        if location and location.latitude and location.longitude:
            return Decimal(str(location.latitude)), Decimal(str(location.longitude))
        
        # Fallback: tylko miasto
        if city:
            city_address = f"{city}, {country}"
            location = geolocator.geocode(city_address, timeout=10, exactly_one=True)
            if location and location.latitude and location.longitude:
                return Decimal(str(location.latitude)), Decimal(str(location.longitude))
        
        return None, None
        
    except (GeocoderTimedOut, GeocoderServiceError) as e:
        # Logowanie błędu można dodać w przyszłości
        return None, None
    except Exception as e:
        return None, None
    finally:
        # Rate limiting dla Nominatim (max 1 request per second)
        time.sleep(1)


def get_client_ip(request):
    """Pobiera adres IP klienta z request."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

