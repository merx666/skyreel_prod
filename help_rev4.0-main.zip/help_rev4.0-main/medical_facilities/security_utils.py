"""
Narzędzia bezpieczeństwa dla walidacji i sanityzacji danych wejściowych.
Zgodne z wymaganiami 1.1-1.6, 4.1-4.6, 9.1-9.6.
"""
import re
import bleach
from django.core.exceptions import ValidationError
from django.utils.html import escape
from django.core.validators import URLValidator, EmailValidator
import logging

logger = logging.getLogger('security')


class InputSanitizer:
    """
    Klasa zawierająca metody do sanityzacji i walidacji danych wejściowych.
    Chroni przed XSS, SQL Injection i innymi atakami.
    """
    
    # Dozwolone tagi HTML dla pól tekstowych
    ALLOWED_TAGS = ['p', 'br', 'strong', 'em', 'ul', 'ol', 'li', 'a']
    ALLOWED_ATTRIBUTES = {
        'a': ['href', 'title'],
    }
    
    # Wzorce wykrywania ataków
    XSS_PATTERNS = [
        r'<script[^>]*>.*?</script>',
        r'javascript:',
        r'onerror\s*=',
        r'onload\s*=',
        r'onclick\s*=',
        r'onmouseover\s*=',
        r'<iframe',
        r'eval\(',
        r'expression\(',
        r'vbscript:',
        r'<embed',
        r'<object',
    ]
    
    SQL_INJECTION_PATTERNS = [
        r"(\bOR\b|\bAND\b)\s+\d+\s*=\s*\d+",
        r";\s*(DROP|DELETE|UPDATE|INSERT|ALTER|CREATE)\s+",
        r"UNION\s+SELECT",
        r"--\s*$",
        r"/\*.*\*/",
        r"'\s*(OR|AND)\s+'",
        r"1\s*=\s*1",
        r"'\s*OR\s*'1'\s*=\s*'1",
    ]
    
    @staticmethod
    def sanitize_html(text, allowed_tags=None, allowed_attributes=None):
        """
        Sanityzuje HTML, usuwając niebezpieczne tagi i atrybuty.
        
        Args:
            text: Tekst do sanityzacji
            allowed_tags: Lista dozwolonych tagów (domyślnie ALLOWED_TAGS)
            allowed_attributes: Słownik dozwolonych atrybutów (domyślnie ALLOWED_ATTRIBUTES)
        
        Returns:
            Zsanityzowany tekst
        """
        if not text:
            return text
        
        if allowed_tags is None:
            allowed_tags = InputSanitizer.ALLOWED_TAGS
        if allowed_attributes is None:
            allowed_attributes = InputSanitizer.ALLOWED_ATTRIBUTES
        
        # Użyj bleach do sanityzacji
        cleaned = bleach.clean(
            text,
            tags=allowed_tags,
            attributes=allowed_attributes,
            strip=True
        )
        
        # Dodatkowe czyszczenie linków
        cleaned = bleach.linkify(
            cleaned,
            callbacks=[lambda attrs, new: attrs if attrs.get((None, 'href'), '').startswith(('http:', 'https:')) else None]
        )
        
        return cleaned
    
    @staticmethod
    def strip_all_html(text):
        """
        Usuwa wszystkie tagi HTML z tekstu.
        
        Args:
            text: Tekst do oczyszczenia
        
        Returns:
            Tekst bez tagów HTML
        """
        if not text:
            return text
        
        return bleach.clean(text, tags=[], strip=True)
    
    @staticmethod
    def sanitize_sql_like(text):
        """
        Escapuje znaki specjalne dla zapytań LIKE w SQL.
        
        Args:
            text: Tekst do escapowania
        
        Returns:
            Tekst z escapowanymi znakami specjalnymi
        """
        if not text:
            return text
        
        return text.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
    
    @staticmethod
    def validate_phone(phone):
        """
        Waliduje i normalizuje numer telefonu.
        Zgodny z wymaganiem 9.1.
        
        Args:
            phone: Numer telefonu do walidacji
        
        Returns:
            Znormalizowany numer telefonu
        
        Raises:
            ValidationError: Jeśli numer jest nieprawidłowy
        """
        if not phone:
            return phone
        
        # Usuń wszystkie znaki oprócz cyfr, +, spacji i myślników
        cleaned = re.sub(r'[^\d+\s\-()]', '', phone)
        
        # Usuń spacje i myślniki dla walidacji
        digits_only = re.sub(r'[\s\-()]', '', cleaned)
        
        # Sprawdź format
        # Akceptuj: +48123456789, 123456789, +48 123 456 789, itp.
        if not re.match(r'^\+?\d{9,15}$', digits_only):
            raise ValidationError(
                'Nieprawidłowy format numeru telefonu. '
                'Numer powinien zawierać 9-15 cyfr, opcjonalnie z prefiksem +.'
            )
        
        return cleaned
    
    @staticmethod
    def validate_postal_code(postal_code):
        """
        Waliduje polski kod pocztowy.
        Zgodny z wymaganiem 9.1.
        
        Args:
            postal_code: Kod pocztowy do walidacji
        
        Returns:
            Znormalizowany kod pocztowy
        
        Raises:
            ValidationError: Jeśli kod jest nieprawidłowy
        """
        if not postal_code:
            return postal_code
        
        # Usuń spacje
        cleaned = postal_code.strip().replace(' ', '')
        
        # Sprawdź format XX-XXX
        if not re.match(r'^\d{2}-?\d{3}$', cleaned):
            raise ValidationError(
                'Kod pocztowy musi być w formacie XX-XXX (np. 00-001)'
            )
        
        # Dodaj myślnik jeśli go nie ma
        if '-' not in cleaned:
            cleaned = f"{cleaned[:2]}-{cleaned[2:]}"
        
        return cleaned
    
    @staticmethod
    def validate_coordinates(latitude, longitude):
        """
        Waliduje współrzędne geograficzne.
        Zgodny z wymaganiem 9.4.
        
        Args:
            latitude: Szerokość geograficzna
            longitude: Długość geograficzna
        
        Raises:
            ValidationError: Jeśli współrzędne są nieprawidłowe
        """
        if latitude is None or longitude is None:
            return
        
        try:
            lat = float(latitude)
            lon = float(longitude)
        except (ValueError, TypeError):
            raise ValidationError('Współrzędne muszą być liczbami.')
        
        if not (-90 <= lat <= 90):
            raise ValidationError(
                f'Szerokość geograficzna musi być między -90 a 90 (podano: {lat})'
            )
        
        if not (-180 <= lon <= 180):
            raise ValidationError(
                f'Długość geograficzna musi być między -180 a 180 (podano: {lon})'
            )
    
    @staticmethod
    def validate_url(url):
        """
        Waliduje URL strony internetowej.
        Zgodny z wymaganiem 9.5.
        
        Args:
            url: URL do walidacji
        
        Raises:
            ValidationError: Jeśli URL jest nieprawidłowy
        """
        if not url:
            return
        
        validator = URLValidator(
            schemes=['http', 'https'],
            message='Wprowadź prawidłowy adres URL (http:// lub https://)'
        )
        
        try:
            validator(url)
        except ValidationError:
            raise ValidationError('Nieprawidłowy format adresu URL.')
    
    @staticmethod
    def validate_email(email):
        """
        Waliduje adres email.
        Zgodny z wymaganiem 9.1.
        
        Args:
            email: Adres email do walidacji
        
        Raises:
            ValidationError: Jeśli email jest nieprawidłowy
        """
        if not email:
            return
        
        validator = EmailValidator(message='Wprowadź prawidłowy adres email.')
        validator(email)
    
    @staticmethod
    def detect_xss_attempt(text):
        """
        Wykrywa próby ataku XSS w tekście.
        Zgodny z wymaganiami 1.1-1.6.
        
        Args:
            text: Tekst do sprawdzenia
        
        Returns:
            True jeśli wykryto próbę XSS, False w przeciwnym razie
        """
        if not text:
            return False
        
        text_lower = text.lower()
        
        for pattern in InputSanitizer.XSS_PATTERNS:
            if re.search(pattern, text_lower, re.IGNORECASE):
                logger.warning(f"XSS attempt detected: pattern '{pattern}' in text")
                return True
        
        return False
    
    @staticmethod
    def detect_sql_injection_attempt(text):
        """
        Wykrywa próby SQL Injection w tekście.
        Zgodny z wymaganiami 2.1-2.6.
        
        Args:
            text: Tekst do sprawdzenia
        
        Returns:
            True jeśli wykryto próbę SQL Injection, False w przeciwnym razie
        """
        if not text:
            return False
        
        text_upper = text.upper()
        
        for pattern in InputSanitizer.SQL_INJECTION_PATTERNS:
            if re.search(pattern, text_upper, re.IGNORECASE):
                logger.warning(f"SQL Injection attempt detected: pattern '{pattern}' in text")
                return True
        
        return False
    
    @staticmethod
    def validate_text_length(text, max_length, field_name="Pole"):
        """
        Waliduje długość tekstu.
        Zgodny z wymaganiem 9.3.
        
        Args:
            text: Tekst do walidacji
            max_length: Maksymalna długość
            field_name: Nazwa pola (dla komunikatu błędu)
        
        Raises:
            ValidationError: Jeśli tekst jest za długi
        """
        if text and len(text) > max_length:
            raise ValidationError(
                f'{field_name} nie może być dłuższe niż {max_length} znaków '
                f'(podano: {len(text)} znaków).'
            )
    
    @staticmethod
    def sanitize_filename(filename):
        """
        Sanityzuje nazwę pliku, usuwając niebezpieczne znaki.
        
        Args:
            filename: Nazwa pliku do sanityzacji
        
        Returns:
            Bezpieczna nazwa pliku
        """
        if not filename:
            return filename
        
        # Usuń ścieżki (../, ..\, etc.)
        filename = filename.replace('..', '')
        
        # Zachowaj tylko bezpieczne znaki
        filename = re.sub(r'[^\w\s\-\.]', '', filename)
        
        # Usuń wielokrotne kropki
        filename = re.sub(r'\.+', '.', filename)
        
        return filename.strip()
    
    @staticmethod
    def validate_no_special_chars_in_numeric(text, field_name="Pole"):
        """
        Sprawdza czy pole numeryczne nie zawiera znaków specjalnych.
        Zgodny z wymaganiem 9.6.
        
        Args:
            text: Tekst do sprawdzenia
            field_name: Nazwa pola (dla komunikatu błędu)
        
        Raises:
            ValidationError: Jeśli znaleziono znaki specjalne
        """
        if not text:
            return
        
        # Dozwolone: cyfry, kropka, przecinek, minus, plus, spacja
        if not re.match(r'^[\d\.\,\-\+\s]+$', str(text)):
            raise ValidationError(
                f'{field_name} może zawierać tylko cyfry i podstawowe znaki matematyczne.'
            )


def create_security_event_from_attack(request, attack_type, description, severity='HIGH'):
    """
    Tworzy zdarzenie bezpieczeństwa po wykryciu ataku.
    
    Args:
        request: Obiekt HttpRequest
        attack_type: Typ ataku (XSS_DETECTED, SQL_INJECTION, etc.)
        description: Opis zdarzenia
        severity: Poziom zagrożenia (LOW, MEDIUM, HIGH, CRITICAL)
    """
    try:
        from .models import SecurityEvent
        from .middleware import PageVisitMiddleware
        
        ip_address = PageVisitMiddleware().get_client_ip(request)
        
        SecurityEvent.objects.create(
            event_type=attack_type,
            ip_address=ip_address,
            user=request.user if request.user.is_authenticated else None,
            description=description,
            request_data={
                'path': request.path,
                'method': request.method,
                'user_agent': request.META.get('HTTP_USER_AGENT', ''),
                'referer': request.META.get('HTTP_REFERER', ''),
            },
            severity=severity,
            action_taken='Logged and monitored'
        )
        
        logger.warning(
            f"Security event created: {attack_type} from IP {ip_address} "
            f"on path {request.path}"
        )
    except Exception as e:
        logger.error(f"Failed to create security event: {str(e)}")
