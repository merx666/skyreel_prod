from django.contrib.sitemaps import Sitemap
from django.urls import reverse
from .models import MedicalFacility


class StaticViewSitemap(Sitemap):
    """Sitemap dla statycznych stron"""
    priority = 1.0
    changefreq = 'monthly'

    def items(self):
        return [
            'medical_facilities:home',
            'medical_facilities:facility_list',
            'medical_facilities:facility_map',
            'medical_facilities:contact',
            'medical_facilities:privacy',
            'medical_facilities:statistics',
        ]

    def location(self, item):
        return reverse(item)


class MedicalFacilitySitemap(Sitemap):
    """Sitemap dla placówek medycznych"""
    changefreq = 'weekly'
    priority = 0.8

    def items(self):
        return MedicalFacility.objects.filter(status='approved')

    def lastmod(self, obj):
        return obj.updated_at

