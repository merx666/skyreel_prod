from django.contrib import admin
from django.contrib import messages
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import (
    Voivodeship, AddictionType, FacilityType, TherapyType, AgeGroup,
    MedicalFacility, FacilityRating, FacilityImage, PageVisit,
    AuditLog, SecurityEvent
)


@admin.register(Voivodeship)
class VoivodeshipAdmin(admin.ModelAdmin):
    list_display = ('name', 'facility_count')
    search_fields = ('name',)
    ordering = ('name',)
    
    def get_facility_count(self, obj):
        try:
            if obj and obj.pk:
                return obj.medicalfacility_set.count()
        except Exception:
            pass
        return 0
    
    def facility_count(self, obj):
        return self.get_facility_count(obj)
    facility_count.short_description = 'Liczba placówek'


@admin.register(AddictionType)
class AddictionTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'description')
    search_fields = ('name', 'description')
    ordering = ('name',)
    prepopulated_fields = {'slug': ('name',)}
    fields = ('name', 'slug', 'description', 'icon')


@admin.register(FacilityType)
class FacilityTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'facility_count')
    search_fields = ('name',)
    ordering = ('name',)
    prepopulated_fields = {'slug': ('name',)}
    
    def get_facility_count(self, obj):
        try:
            if obj and obj.pk:
                return obj.medicalfacility_set.count()
        except Exception:
            pass
        return 0
    
    def facility_count(self, obj):
        return self.get_facility_count(obj)
    facility_count.short_description = 'Liczba placówek'


@admin.register(TherapyType)
class TherapyTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'facility_count')
    search_fields = ('name',)
    ordering = ('name',)
    prepopulated_fields = {'slug': ('name',)}
    
    def get_facility_count(self, obj):
        try:
            if obj and obj.pk:
                return obj.medicalfacility_set.count()
        except Exception:
            pass
        return 0
    
    def facility_count(self, obj):
        return self.get_facility_count(obj)
    facility_count.short_description = 'Liczba placówek'


@admin.register(AgeGroup)
class AgeGroupAdmin(admin.ModelAdmin):
    list_display = ('name', 'min_age', 'max_age', 'facility_count')
    search_fields = ('name',)
    ordering = ('min_age',)
    
    def get_facility_count(self, obj):
        try:
            if obj and obj.pk:
                return obj.medicalfacility_set.count()
        except Exception:
            pass
        return 0
    
    def facility_count(self, obj):
        return self.get_facility_count(obj)
    facility_count.short_description = 'Liczba placówek'


class FacilityImageInline(admin.TabularInline):
    model = FacilityImage
    extra = 1
    fields = ('image', 'caption', 'is_primary')
    readonly_fields = ('created_at',)


class FacilityRatingInline(admin.TabularInline):
    model = FacilityRating
    extra = 0
    fields = ('user', 'overall_rating', 'comment', 'status', 'created_at')
    readonly_fields = ('created_at',)
    can_delete = False


@admin.register(MedicalFacility)
class MedicalFacilityAdmin(admin.ModelAdmin):
    list_display = (
        'name', 'city', 'voivodeship', 'status', 'accepts_nfz',
        'has_emergency_service', 'average_rating', 'ratings_count', 'created_at'
    )
    list_filter = (
        'status', 'accepts_nfz', 'has_emergency_service',
        'voivodeship', 'facility_types', 'created_at'
    )
    search_fields = ('name', 'city', 'street_address', 'description')
    filter_horizontal = ('facility_types', 'therapy_types', 'age_groups')
    readonly_fields = ('slug', 'created_at', 'updated_at', 'average_rating', 'ratings_count')
    # prepopulated_fields = {'slug': ('name',)}  # Removed - slug is readonly
    
    fieldsets = (
        ('Podstawowe informacje', {
            'fields': ('name', 'slug', 'description', 'status', 'moderator_notes')
        }),
        ('Lokalizacja', {
            'fields': ('street_address', 'city', 'postal_code', 'voivodeship', 'latitude', 'longitude')
        }),
        ('Kontakt', {
            'fields': ('phone', 'email', 'website')
        }),
        ('Usługi', {
            'fields': (
                'facility_types', 'therapy_types', 'age_groups',
                'accepts_nfz', 'has_emergency_service'
            )
        }),
        ('Godziny otwarcia', {
            'fields': ('opening_hours',),
            'classes': ('collapse',)
        }),
        ('Metadane', {
            'fields': ('created_by', 'created_at', 'updated_at', 'average_rating', 'ratings_count'),
            'classes': ('collapse',)
        })
    )
    
    inlines = [FacilityImageInline, FacilityRatingInline]
    
    actions = [
        'approve_facilities',
        'reject_facilities',
        'export_to_csv',
        'mark_for_review',
        'export_statistics'
    ]
    
    def approve_facilities(self, request, queryset):
        """Masowe zatwierdzanie placówek z logowaniem do audytu."""
        from .models import AuditLog
        from .middleware import PageVisitMiddleware
        
        count = 0
        for facility in queryset.filter(status='pending'):
            facility.status = 'approved'
            facility.save()
            count += 1
            
            # Log do audytu
            try:
                AuditLog.objects.create(
                    user=request.user,
                    ip_address=PageVisitMiddleware().get_client_ip(request),
                    action='APPROVE',
                    model_name='MedicalFacility',
                    object_id=str(facility.id),
                    object_repr=str(facility),
                    request_path=request.path,
                    request_method='POST',
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    status_code=200,
                    severity='INFO',
                    notes=f'Bulk approval by {request.user.username}'
                )
            except Exception:
                pass
        
        self.message_user(
            request,
            f'Zatwierdzono {count} placówek.',
            messages.SUCCESS
        )
    approve_facilities.short_description = 'Zatwierdź wybrane placówki'
    
    def reject_facilities(self, request, queryset):
        """Masowe odrzucanie placówek z logowaniem do audytu."""
        from .models import AuditLog
        from .middleware import PageVisitMiddleware
        
        count = 0
        for facility in queryset.filter(status='pending'):
            facility.status = 'rejected'
            facility.save()
            count += 1
            
            # Log do audytu
            try:
                AuditLog.objects.create(
                    user=request.user,
                    ip_address=PageVisitMiddleware().get_client_ip(request),
                    action='REJECT',
                    model_name='MedicalFacility',
                    object_id=str(facility.id),
                    object_repr=str(facility),
                    request_path=request.path,
                    request_method='POST',
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    status_code=200,
                    severity='INFO',
                    notes=f'Bulk rejection by {request.user.username}'
                )
            except Exception:
                pass
        
        self.message_user(
            request,
            f'Odrzucono {count} placówek.',
            messages.WARNING
        )
    reject_facilities.short_description = 'Odrzuć wybrane placówki'
    
    def export_to_csv(self, request, queryset):
        """Eksport wybranych placówek do CSV."""
        import csv
        from django.http import HttpResponse
        from django.utils import timezone
        
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = f'attachment; filename="facilities_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
        response.write('\ufeff')  # BOM dla UTF-8
        
        writer = csv.writer(response)
        writer.writerow([
            'ID', 'Nazwa', 'Miasto', 'Województwo', 'Status',
            'Telefon', 'Email', 'NFZ', 'Ratownictwo',
            'Średnia ocena', 'Liczba ocen', 'Data utworzenia'
        ])
        
        for facility in queryset:
            writer.writerow([
                facility.id,
                facility.name,
                facility.city,
                facility.voivodeship.name if facility.voivodeship else '',
                facility.get_status_display(),
                facility.phone or '',
                facility.email or '',
                'Tak' if facility.accepts_nfz else 'Nie',
                'Tak' if facility.has_emergency_service else 'Nie',
                f"{facility.get_average_rating():.1f}" if facility.get_average_rating() else '-',
                facility.ratings.filter(status='approved').count(),
                facility.created_at.strftime('%Y-%m-%d %H:%M')
            ])
        
        self.message_user(request, f'Wyeksportowano {queryset.count()} placówek do CSV.')
        return response
    export_to_csv.short_description = 'Eksportuj do CSV'
    
    def mark_for_review(self, request, queryset):
        """Oznacz placówki do ponownej weryfikacji."""
        updated = queryset.update(status='pending')
        self.message_user(
            request,
            f'Oznaczono {updated} placówek do weryfikacji.',
            messages.INFO
        )
    mark_for_review.short_description = 'Oznacz do weryfikacji'
    
    def export_statistics(self, request, queryset):
        """Eksport statystyk wybranych placówek do JSON."""
        from django.http import JsonResponse
        from django.db.models import Avg, Count
        
        stats = []
        for facility in queryset:
            stats.append({
                'id': facility.id,
                'name': facility.name,
                'city': facility.city,
                'status': facility.status,
                'average_rating': float(facility.get_average_rating() or 0),
                'ratings_count': facility.ratings.filter(status='approved').count(),
                'accepts_nfz': facility.accepts_nfz,
                'has_emergency': facility.has_emergency_service,
                'created_at': facility.created_at.isoformat(),
            })
        
        response = JsonResponse({'facilities': stats, 'count': len(stats)}, json_dumps_params={'indent': 2})
        response['Content-Disposition'] = 'attachment; filename="facilities_stats.json"'
        
        self.message_user(request, f'Wyeksportowano statystyki {len(stats)} placówek.')
        return response
    export_statistics.short_description = 'Eksportuj statystyki (JSON)'
    
    def average_rating(self, obj):
        if obj:
            rating = obj.get_average_rating()
            if rating:
                return f"{rating:.1f}"
            return "-"
        return "-"
    average_rating.short_description = 'Średnia ocena'
    
    def ratings_count(self, obj):
        if obj:
            return obj.ratings.filter(status='approved').count()
        return 0
    ratings_count.short_description = 'Liczba ocen'


@admin.register(FacilityRating)
class FacilityRatingAdmin(admin.ModelAdmin):
    list_display = (
        'facility', 'user', 'overall_rating', 'status', 'created_at'
    )
    list_filter = ('status', 'overall_rating', 'created_at')
    search_fields = ('facility__name', 'user__username', 'comment')
    readonly_fields = ('created_at',)
    
    fieldsets = (
        ('Podstawowe informacje', {
            'fields': ('facility', 'user', 'status')
        }),
        ('Oceny', {
            'fields': ('overall_rating', 'staff_rating', 'facilities_rating', 'treatment_rating')
        }),
        ('Komentarz', {
            'fields': ('comment',)
        }),
        ('Metadane', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        })
    )
    
    actions = ['approve_ratings', 'reject_ratings', 'export_ratings_to_csv']
    
    def approve_ratings(self, request, queryset):
        """Masowe zatwierdzanie ocen z logowaniem."""
        from .models import AuditLog
        from .middleware import PageVisitMiddleware
        
        count = 0
        for rating in queryset.filter(status='pending'):
            rating.status = 'approved'
            rating.save()
            count += 1
            
            # Log do audytu
            try:
                AuditLog.objects.create(
                    user=request.user,
                    ip_address=PageVisitMiddleware().get_client_ip(request),
                    action='APPROVE',
                    model_name='FacilityRating',
                    object_id=str(rating.id),
                    object_repr=f"Rating for {rating.facility.name}",
                    request_path=request.path,
                    request_method='POST',
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    status_code=200,
                    severity='INFO',
                    notes=f'Bulk approval by {request.user.username}'
                )
            except Exception:
                pass
        
        self.message_user(
            request,
            f'Zatwierdzono {count} ocen.',
            messages.SUCCESS
        )
    approve_ratings.short_description = 'Zatwierdź wybrane oceny'
    
    def reject_ratings(self, request, queryset):
        """Masowe odrzucanie ocen z logowaniem."""
        from .models import AuditLog
        from .middleware import PageVisitMiddleware
        
        count = 0
        for rating in queryset.filter(status='pending'):
            rating.status = 'rejected'
            rating.save()
            count += 1
            
            # Log do audytu
            try:
                AuditLog.objects.create(
                    user=request.user,
                    ip_address=PageVisitMiddleware().get_client_ip(request),
                    action='REJECT',
                    model_name='FacilityRating',
                    object_id=str(rating.id),
                    object_repr=f"Rating for {rating.facility.name}",
                    request_path=request.path,
                    request_method='POST',
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    status_code=200,
                    severity='INFO',
                    notes=f'Bulk rejection by {request.user.username}'
                )
            except Exception:
                pass
        
        self.message_user(
            request,
            f'Odrzucono {count} ocen.',
            messages.WARNING
        )
    reject_ratings.short_description = 'Odrzuć wybrane oceny'
    
    def export_ratings_to_csv(self, request, queryset):
        """Eksport wybranych ocen do CSV."""
        import csv
        from django.http import HttpResponse
        from django.utils import timezone
        
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = f'attachment; filename="ratings_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
        response.write('\ufeff')  # BOM dla UTF-8
        
        writer = csv.writer(response)
        writer.writerow([
            'ID', 'Placówka', 'Użytkownik', 'Ocena ogólna',
            'Ocena personelu', 'Ocena wyposażenia', 'Ocena leczenia',
            'Komentarz', 'Status', 'Data utworzenia'
        ])
        
        for rating in queryset:
            writer.writerow([
                rating.id,
                rating.facility.name,
                rating.user.username if rating.user else 'Anonim',
                rating.overall_rating,
                rating.staff_rating or '-',
                rating.facilities_rating or '-',
                rating.treatment_rating or '-',
                rating.comment[:100] if rating.comment else '',
                rating.get_status_display(),
                rating.created_at.strftime('%Y-%m-%d %H:%M')
            ])
        
        self.message_user(request, f'Wyeksportowano {queryset.count()} ocen do CSV.')
        return response
    export_ratings_to_csv.short_description = 'Eksportuj do CSV'


@admin.register(FacilityImage)
class FacilityImageAdmin(admin.ModelAdmin):
    list_display = ('facility', 'caption', 'is_primary', 'uploaded_by', 'created_at')
    list_filter = ('is_primary', 'created_at')
    search_fields = ('facility__name', 'caption')
    readonly_fields = ('created_at',)
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('facility', 'uploaded_by')


@admin.register(PageVisit)
class PageVisitAdmin(admin.ModelAdmin):
    list_display = ('path', 'session_key_short', 'user', 'ip_address', 'visited_at', 'is_unique')
    list_filter = ('is_unique', 'visited_at', 'path')
    search_fields = ('path', 'session_key', 'ip_address', 'user__username')
    readonly_fields = ('session_key', 'ip_address', 'user', 'path', 'referer', 'user_agent', 'visited_at', 'is_unique')
    date_hierarchy = 'visited_at'
    ordering = ('-visited_at',)
    
    def session_key_short(self, obj):
        return obj.session_key[:8] + '...' if obj.session_key else '-'
    session_key_short.short_description = 'Sesja'
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')


# Konfiguracja panelu administratora
admin.site.site_header = 'Hyperreal Help - Panel Administratora'
admin.site.site_title = 'Hyperreal Help Admin'
admin.site.index_title = 'Panel zarządzania placówkami medycznymi'



# Security Models Admin

@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    """
    Panel administracyjny dla logów audytu.
    Zgodny z wymaganiami 3.1-3.6.
    """
    list_display = (
        'timestamp', 'user_display', 'action', 'model_name',
        'ip_address', 'severity_badge', 'status_code'
    )
    list_filter = (
        'action', 'severity', 'status_code', 'timestamp', 'model_name'
    )
    search_fields = (
        'user__username', 'ip_address', 'object_repr',
        'request_path', 'notes'
    )
    readonly_fields = (
        'timestamp', 'user', 'ip_address', 'action', 'model_name',
        'object_id', 'object_repr', 'changes', 'request_path',
        'request_method', 'user_agent', 'status_code', 'severity'
    )
    date_hierarchy = 'timestamp'
    ordering = ('-timestamp',)
    
    fieldsets = (
        ('Informacje podstawowe', {
            'fields': ('timestamp', 'user', 'ip_address', 'severity')
        }),
        ('Akcja', {
            'fields': ('action', 'model_name', 'object_id', 'object_repr')
        }),
        ('Szczegóły żądania', {
            'fields': ('request_path', 'request_method', 'status_code')
        }),
        ('Zmiany', {
            'fields': ('changes',),
            'classes': ('collapse',)
        }),
        ('Dodatkowe informacje', {
            'fields': ('user_agent', 'notes'),
            'classes': ('collapse',)
        })
    )
    
    actions = ['export_to_csv']
    
    def user_display(self, obj):
        """Wyświetla użytkownika z linkiem do profilu."""
        if obj.user:
            url = reverse('admin:auth_user_change', args=[obj.user.id])
            return format_html('<a href="{}">{}</a>', url, obj.user.username)
        return format_html('<span style="color: #999;">Anonymous</span>')
    user_display.short_description = 'Użytkownik'
    
    def severity_badge(self, obj):
        """Wyświetla badge z poziomem ważności."""
        colors = {
            'INFO': '#17a2b8',
            'WARNING': '#ffc107',
            'ERROR': '#dc3545',
            'CRITICAL': '#343a40',
        }
        color = colors.get(obj.severity, '#6c757d')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 8px; '
            'border-radius: 3px; font-size: 11px;">{}</span>',
            color, obj.get_severity_display()
        )
    severity_badge.short_description = 'Ważność'
    
    def export_to_csv(self, request, queryset):
        """Eksportuje wybrane logi do CSV."""
        import csv
        from django.http import HttpResponse
        from django.utils import timezone
        
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = f'attachment; filename="audit_logs_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
        response.write('\ufeff')  # BOM dla UTF-8
        
        writer = csv.writer(response)
        writer.writerow([
            'Timestamp', 'User', 'IP Address', 'Action', 'Model',
            'Object ID', 'Request Path', 'Method', 'Status Code', 'Severity'
        ])
        
        for log in queryset:
            writer.writerow([
                log.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                log.user.username if log.user else 'Anonymous',
                log.ip_address,
                log.get_action_display(),
                log.model_name,
                log.object_id,
                log.request_path,
                log.request_method,
                log.status_code,
                log.get_severity_display(),
            ])
        
        self.message_user(request, f'Wyeksportowano {queryset.count()} logów do CSV.')
        return response
    export_to_csv.short_description = 'Eksportuj wybrane logi do CSV'
    
    def has_add_permission(self, request):
        """Logi audytu nie mogą być dodawane ręcznie."""
        return False
    
    def has_delete_permission(self, request, obj=None):
        """Logi audytu nie mogą być usuwane (tylko przez superusera)."""
        return request.user.is_superuser
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')


@admin.register(SecurityEvent)
class SecurityEventAdmin(admin.ModelAdmin):
    """
    Panel administracyjny dla zdarzeń bezpieczeństwa.
    Zgodny z wymaganiami 3.6, 10.7.
    """
    list_display = (
        'timestamp', 'event_type_display', 'ip_address', 'user_display',
        'severity_badge', 'resolved_status', 'time_since'
    )
    list_filter = (
        'event_type', 'severity', 'resolved', 'timestamp'
    )
    search_fields = (
        'ip_address', 'user__username', 'description', 'action_taken'
    )
    readonly_fields = (
        'timestamp', 'event_type', 'ip_address', 'user', 'description',
        'request_data', 'severity'
    )
    date_hierarchy = 'timestamp'
    ordering = ('-timestamp',)
    filter_horizontal = ('related_audit_logs',)
    
    fieldsets = (
        ('Informacje podstawowe', {
            'fields': ('timestamp', 'event_type', 'severity', 'ip_address', 'user')
        }),
        ('Opis zdarzenia', {
            'fields': ('description', 'action_taken')
        }),
        ('Dane żądania', {
            'fields': ('request_data',),
            'classes': ('collapse',)
        }),
        ('Status rozwiązania', {
            'fields': ('resolved', 'resolved_at', 'resolved_by', 'resolution_notes')
        }),
        ('Powiązane logi', {
            'fields': ('related_audit_logs',),
            'classes': ('collapse',)
        })
    )
    
    actions = ['mark_as_resolved', 'mark_as_unresolved', 'export_to_csv']
    
    def event_type_display(self, obj):
        """Wyświetla typ zdarzenia z ikoną."""
        icons = {
            'BRUTE_FORCE': '🔨',
            'DDOS_ATTEMPT': '💥',
            'XSS_DETECTED': '⚠️',
            'SQL_INJECTION': '💉',
            'SUSPICIOUS_PATTERN': '🔍',
            'RATE_LIMIT_ABUSE': '🚫',
            'UNAUTHORIZED_ACCESS': '🔒',
            'DATA_BREACH_ATTEMPT': '🚨',
        }
        icon = icons.get(obj.event_type, '❓')
        return format_html('{} {}', icon, obj.get_event_type_display())
    event_type_display.short_description = 'Typ zdarzenia'
    
    def user_display(self, obj):
        """Wyświetla użytkownika z linkiem."""
        if obj.user:
            url = reverse('admin:auth_user_change', args=[obj.user.id])
            return format_html('<a href="{}">{}</a>', url, obj.user.username)
        return format_html('<span style="color: #999;">-</span>')
    user_display.short_description = 'Użytkownik'
    
    def severity_badge(self, obj):
        """Wyświetla badge z poziomem zagrożenia."""
        colors = {
            'LOW': '#17a2b8',
            'MEDIUM': '#ffc107',
            'HIGH': '#fd7e14',
            'CRITICAL': '#dc3545',
        }
        color = colors.get(obj.severity, '#6c757d')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 8px; '
            'border-radius: 3px; font-size: 11px; font-weight: bold;">{}</span>',
            color, obj.get_severity_display()
        )
    severity_badge.short_description = 'Zagrożenie'
    
    def resolved_status(self, obj):
        """Wyświetla status rozwiązania."""
        if obj.resolved:
            return format_html(
                '<span style="color: #28a745;">✓ Rozwiązane</span>'
            )
        return format_html(
            '<span style="color: #dc3545;">✗ Nierozwiązane</span>'
        )
    resolved_status.short_description = 'Status'
    
    def time_since(self, obj):
        """Wyświetla czas od zdarzenia."""
        return obj.get_time_since_event()
    time_since.short_description = 'Czas od zdarzenia'
    
    def mark_as_resolved(self, request, queryset):
        """Oznacza wybrane zdarzenia jako rozwiązane."""
        from django.utils import timezone
        count = 0
        for event in queryset.filter(resolved=False):
            event.mark_as_resolved(request.user, "Rozwiązane przez administratora")
            count += 1
        
        self.message_user(
            request,
            f'Oznaczono {count} zdarzeń jako rozwiązane.'
        )
    mark_as_resolved.short_description = 'Oznacz jako rozwiązane'
    
    def mark_as_unresolved(self, request, queryset):
        """Oznacza wybrane zdarzenia jako nierozwiązane."""
        updated = queryset.update(
            resolved=False,
            resolved_at=None,
            resolved_by=None
        )
        self.message_user(
            request,
            f'Oznaczono {updated} zdarzeń jako nierozwiązane.'
        )
    mark_as_unresolved.short_description = 'Oznacz jako nierozwiązane'
    
    def export_to_csv(self, request, queryset):
        """Eksportuje wybrane zdarzenia do CSV."""
        import csv
        from django.http import HttpResponse
        from django.utils import timezone
        
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = f'attachment; filename="security_events_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
        response.write('\ufeff')  # BOM dla UTF-8
        
        writer = csv.writer(response)
        writer.writerow([
            'Timestamp', 'Event Type', 'IP Address', 'User', 'Severity',
            'Description', 'Resolved', 'Action Taken'
        ])
        
        for event in queryset:
            writer.writerow([
                event.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                event.get_event_type_display(),
                event.ip_address,
                event.user.username if event.user else '-',
                event.get_severity_display(),
                event.description,
                'Tak' if event.resolved else 'Nie',
                event.action_taken,
            ])
        
        self.message_user(request, f'Wyeksportowano {queryset.count()} zdarzeń do CSV.')
        return response
    export_to_csv.short_description = 'Eksportuj wybrane zdarzenia do CSV'
    
    def has_add_permission(self, request):
        """Zdarzenia bezpieczeństwa są tworzone automatycznie."""
        return False
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'resolved_by')
