import random
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from medical_facilities.models import (
    MedicalFacility, FacilityRating, FacilityImage,
    Voivodeship, AddictionType, FacilityType, TherapyType, AgeGroup
)

class Command(BaseCommand):
    help = 'Generuje przykładowe dane dla aplikacji'

    def handle(self, *args, **options):
        self.stdout.write('Generowanie przykładowych danych...')
        
        # Tworzenie województw
        voivodeships = [
            'dolnośląskie', 'kujawsko-pomorskie', 'lubelskie', 'lubuskie', 
            'łódzkie', 'małopolskie', 'mazowieckie', 'opolskie', 'podkarpackie',
            'podlaskie', 'pomorskie', 'śląskie', 'świętokrzyskie', 
            'warmińsko-mazurskie', 'wielkopolskie', 'zachodniopomorskie'
        ]
        
        for name in voivodeships:
            Voivodeship.objects.get_or_create(name=name)
        
        # Tworzenie typów uzależnień
        addiction_types = [
            'alkoholizm', 'narkomania', 'hazard', 'uzależnienie od internetu',
            'uzależnienie od seksu', 'uzależnienie od zakupów', 'uzależnienie od jedzenia'
        ]
        
        for name in addiction_types:
            AddictionType.objects.get_or_create(name=name)
        
        # Tworzenie typów placówek
        facility_types = [
            'szpital', 'poradnia', 'ośrodek terapii', 'ośrodek rehabilitacyjny',
            'grupa wsparcia', 'prywatna praktyka', 'oddział dzienny'
        ]
        
        for name in facility_types:
            FacilityType.objects.get_or_create(name=name)
        
        # Tworzenie typów terapii
        therapy_types = [
            'indywidualna', 'grupowa', 'rodzinna', 'małżeńska',
            'psychodynamiczna', 'poznawczo-behawioralna', 'systemowa'
        ]
        
        for name in therapy_types:
            TherapyType.objects.get_or_create(name=name)
        
        # Tworzenie grup wiekowych
        age_groups = [
            'dzieci', 'młodzież', 'dorośli', 'seniorzy'
        ]
        
        for name in age_groups:
            AgeGroup.objects.get_or_create(name=name)
        
        # Tworzenie użytkowników
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@example.com', 'admin')
        
        for i in range(1, 11):
            username = f'user{i}'
            if not User.objects.filter(username=username).exists():
                User.objects.create_user(username, f'{username}@example.com', 'password')
        
        # Tworzenie placówek
        cities = [
            'Warszawa', 'Kraków', 'Łódź', 'Wrocław', 'Poznań', 'Gdańsk', 
            'Szczecin', 'Bydgoszcz', 'Lublin', 'Białystok', 'Katowice', 
            'Gdynia', 'Częstochowa', 'Radom', 'Sosnowiec', 'Toruń', 
            'Kielce', 'Rzeszów', 'Olsztyn', 'Bielsko-Biała'
        ]
        
        facility_names = [
            'Centrum Terapii Uzależnień', 'Ośrodek Leczenia Uzależnień', 
            'Poradnia Leczenia Uzależnień', 'Centrum Zdrowia Psychicznego',
            'Szpital Psychiatryczny', 'Klinika Psychiatrii', 'Centrum Psychoterapii',
            'Ośrodek Rehabilitacji', 'Centrum Pomocy Psychologicznej', 'Poradnia Zdrowia Psychicznego'
        ]
        
        for i in range(50):
            name = f"{random.choice(facility_names)} {random.choice(['', 'nr ' + str(random.randint(1, 10))])}"
            if i > 0:
                name += f" w {random.choice(cities)}"
            
            if MedicalFacility.objects.filter(name=name).exists():
                continue
            
            facility = MedicalFacility.objects.create(
                name=name,
                address=f"ul. {random.choice(['Warszawska', 'Krakowska', 'Długa', 'Krótka', 'Szeroka', 'Wąska'])} {random.randint(1, 100)}",
                city=random.choice(cities),
                postal_code=f"{random.randint(10, 99)}-{random.randint(100, 999)}",
                phone=f"+48 {random.randint(100, 999)} {random.randint(100, 999)} {random.randint(100, 999)}",
                email=f"kontakt@{name.lower().replace(' ', '')}.pl",
                website=f"https://www.{name.lower().replace(' ', '')}.pl",
                description=f"Placówka specjalizująca się w leczeniu uzależnień. Oferujemy profesjonalną pomoc i wsparcie.",
                status='approved',
                voivodeship=Voivodeship.objects.order_by('?').first()
            )
            
            # Dodawanie typów placówek
            for _ in range(random.randint(1, 3)):
                facility.facility_types.add(FacilityType.objects.order_by('?').first())
            
            # Dodawanie typów terapii
            for _ in range(random.randint(1, 4)):
                facility.therapy_types.add(TherapyType.objects.order_by('?').first())
            
            # Dodawanie grup wiekowych
            for _ in range(random.randint(1, 3)):
                facility.age_groups.add(AgeGroup.objects.order_by('?').first())
            
            # Dodawanie typów uzależnień
            for _ in range(random.randint(1, 4)):
                facility.addiction_types.add(AddictionType.objects.order_by('?').first())
        
        # Tworzenie ocen
        users = User.objects.all()
        facilities = MedicalFacility.objects.all()
        
        for facility in facilities:
            # Losowa liczba ocen dla każdej placówki (0-10)
            for _ in range(random.randint(0, 10)):
                user = random.choice(users)
                
                # Sprawdź czy użytkownik już ocenił tę placówkę
                if FacilityRating.objects.filter(facility=facility, user=user).exists():
                    continue
                
                overall = random.randint(1, 5)
                staff = random.randint(1, 5)
                facilities_rating = random.randint(1, 5)
                treatment = random.randint(1, 5)
                
                comments = [
                    "Bardzo dobra placówka, polecam.",
                    "Profesjonalna obsługa i miła atmosfera.",
                    "Skuteczna terapia, pomogła mi wyjść z uzależnienia.",
                    "Kompetentny personel, ale warunki mogłyby być lepsze.",
                    "Długi czas oczekiwania na wizytę, ale warto.",
                    "Świetni terapeuci, bardzo pomocni.",
                    "Nowoczesne podejście do leczenia uzależnień.",
                    "Dobra lokalizacja i przystępne ceny.",
                    "Indywidualne podejście do pacjenta.",
                    "Polecam każdemu, kto zmaga się z uzależnieniem."
                ]
                
                FacilityRating.objects.create(
                    facility=facility,
                    user=user,
                    overall_rating=overall,
                    staff_rating=staff,
                    facilities_rating=facilities_rating,
                    treatment_rating=treatment,
                    comment=f"Ocena placówki {facility.name}",
                    comment_text=random.choice(comments),
                    status='approved',
                    created_at=timezone.now(),
                    updated_at=timezone.now()
                )
        
        self.stdout.write(self.style.SUCCESS('Generowanie przykładowych danych zakończone pomyślnie'))