from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse
from django.contrib import admin
from medical_facilities import models

User = get_user_model()


class Command(BaseCommand):
    help = 'Testuje wszystkie panele admin'

    def handle(self, *args, **options):
        # Utwórz superużytkownika jeśli nie istnieje
        admin_user, created = User.objects.get_or_create(
            username='admin',
            defaults={'is_superuser': True, 'is_staff': True, 'email': 'admin@test.com'}
        )
        if created:
            admin_user.set_password('admin123')
            admin_user.save()
            self.stdout.write(self.style.SUCCESS('✅ Utworzono użytkownika admin'))

        client = Client()
        client.force_login(admin_user)

        # Lista wszystkich modeli
        models_to_test = [
            ('Voivodeship', models.Voivodeship),
            ('AddictionType', models.AddictionType),
            ('FacilityType', models.FacilityType),
            ('TherapyType', models.TherapyType),
            ('AgeGroup', models.AgeGroup),
            ('MedicalFacility', models.MedicalFacility),
            ('FacilityRating', models.FacilityRating),
            ('FacilityImage', models.FacilityImage),
            ('PageVisit', models.PageVisit),
        ]

        self.stdout.write(self.style.SUCCESS('🔍 Testowanie paneli admin...'))
        self.stdout.write('=' * 60)

        errors = []
        success_count = 0

        for model_name, model_class in models_to_test:
            app_label = model_class._meta.app_label
            model_name_lower = model_class._meta.model_name

            # Test changelist
            try:
                url = reverse(f'admin:{app_label}_{model_name_lower}_changelist')
                response = client.get(url)
                if response.status_code == 200:
                    self.stdout.write(self.style.SUCCESS(f'✅ {model_name}: changelist działa'))
                    success_count += 1
                else:
                    errors.append(f'{model_name}: changelist zwraca {response.status_code}')
                    self.stdout.write(self.style.ERROR(f'❌ {model_name}: changelist zwraca {response.status_code}'))
            except Exception as e:
                errors.append(f'{model_name}: {e}')
                self.stdout.write(self.style.ERROR(f'❌ {model_name}: {e}'))

        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS(f'📊 PODSUMOWANIE: {success_count}/{len(models_to_test)} działa'))

        if errors:
            self.stdout.write(self.style.ERROR(f'\n❌ BŁĘDY ({len(errors)}):'))
            for error in errors:
                self.stdout.write(self.style.ERROR(f'   - {error}'))
        else:
            self.stdout.write(self.style.SUCCESS('\n🎉 Wszystkie panele admin działają poprawnie!'))


