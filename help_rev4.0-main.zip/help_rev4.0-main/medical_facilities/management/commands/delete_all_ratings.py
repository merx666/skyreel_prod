from django.core.management.base import BaseCommand
from medical_facilities.models import FacilityRating


class Command(BaseCommand):
    help = 'Usuwa wszystkie oceny użytkowników'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko pokaż ile zostałoby usuniętych, bez faktycznego usuwania',
        )

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        
        self.stdout.write(self.style.SUCCESS('🗑️  Usuwanie ocen użytkowników...\n'))
        
        ratings = FacilityRating.objects.all()
        total_count = ratings.count()
        
        if dry_run:
            self.stdout.write(f'🔍 DRY RUN: Zostałoby usuniętych {total_count} ocen')
            if total_count > 0:
                self.stdout.write('\nPrzykładowe oceny do usunięcia:')
                for rating in ratings[:5]:
                    self.stdout.write(f'  - ID: {rating.id}, Placówka: {rating.facility.name[:50]}..., Ocena: {rating.overall_rating}, Użytkownik: {rating.user.username if rating.user else "Anonimowy"}')
            self.stdout.write(self.style.WARNING('\nUruchom ponownie bez --dry-run aby faktycznie usunąć.'))
        else:
            if total_count > 0:
                deleted_count, _ = FacilityRating.objects.all().delete()
                self.stdout.write(self.style.SUCCESS(f'✅ Usunięto {deleted_count} ocen użytkowników!'))
            else:
                self.stdout.write(self.style.SUCCESS('✅ Brak ocen do usunięcia.'))

