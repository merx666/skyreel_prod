import json
import time
import urllib.parse
import urllib.request
from decimal import Decimal

from django.core.management.base import BaseCommand

from medical_facilities.models import MedicalFacility


class Command(BaseCommand):
    help = "Geocodes missing coordinates (latitude/longitude) for MedicalFacility records using Nominatim (OpenStreetMap)."

    def add_arguments(self, parser):
        parser.add_argument('--limit', type=int, default=50, help='Max number of facilities to geocode in this run (default: 50).')
        parser.add_argument('--approve-only', action='store_true', default=True,
                            help='Only process facilities with status=approved (default: True).')
        parser.add_argument('--dry-run', action='store_true', help='Preview mode: do not save changes.')
        parser.add_argument('--delay', type=float, default=1.0,
                            help='Delay in seconds between requests to respect Nominatim rate limits (default: 1.0).')

    def handle(self, *args, **options):
        limit = options.get('limit', 50)
        approve_only = options.get('approve_only', True)
        dry_run = options.get('dry_run', False)
        delay = options.get('delay', 1.0)

        qs = MedicalFacility.objects.filter(latitude__isnull=True, longitude__isnull=True)
        if approve_only:
            qs = qs.filter(status='approved')
        total_missing = qs.count()
        self.stdout.write(self.style.WARNING(f"Facilities missing coordinates: {total_missing}"))

        qs = qs.order_by('created_at')[:limit]
        processed = 0
        successes = 0
        failures = 0

        for facility in qs:
            processed += 1
            address_parts = [facility.street_address, facility.postal_code, facility.city, 'Polska']
            query = ', '.join([part for part in address_parts if part])

            try:
                url = 'https://nominatim.openstreetmap.org/search?' + urllib.parse.urlencode({
                    'q': query,
                    'format': 'json',
                    'limit': 1
                })
                req = urllib.request.Request(
                    url,
                    headers={'User-Agent': 'HelpApp/1.0 (+https://help.example)'}
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    payload = resp.read().decode('utf-8')
                results = json.loads(payload)

                # Fallback: try city + postal code only
                if not results:
                    fallback_parts = [facility.postal_code, facility.city, 'Polska']
                    fallback_query = ', '.join([part for part in fallback_parts if part])
                    url_fb = 'https://nominatim.openstreetmap.org/search?' + urllib.parse.urlencode({
                        'q': fallback_query,
                        'format': 'json',
                        'limit': 1
                    })
                    req_fb = urllib.request.Request(
                        url_fb,
                        headers={'User-Agent': 'HelpApp/1.0 (+https://help.example)'}
                    )
                    with urllib.request.urlopen(req_fb, timeout=15) as resp_fb:
                        payload_fb = resp_fb.read().decode('utf-8')
                    results = json.loads(payload_fb)

                # Second fallback: city only
                if not results:
                    city_only = facility.city
                    if city_only:
                        url_city = 'https://nominatim.openstreetmap.org/search?' + urllib.parse.urlencode({
                            'q': f"{city_only}, Polska",
                            'format': 'json',
                            'limit': 1
                        })
                        req_city = urllib.request.Request(
                            url_city,
                            headers={'User-Agent': 'HelpApp/1.0 (+https://help.example)'}
                        )
                        with urllib.request.urlopen(req_city, timeout=15) as resp_city:
                            payload_city = resp_city.read().decode('utf-8')
                        results = json.loads(payload_city)

                if results:
                    lat = results[0].get('lat')
                    lon = results[0].get('lon')
                    if lat and lon:
                        if dry_run:
                            self.stdout.write(f"DRY-RUN: {facility.name} ({facility.city}) -> lat={lat}, lon={lon}")
                        else:
                            facility.latitude = Decimal(str(lat))
                            facility.longitude = Decimal(str(lon))
                            facility.save(update_fields=['latitude', 'longitude'])
                        successes += 1
                    else:
                        failures += 1
                        self.stdout.write(self.style.WARNING(f"No coords returned for: {facility.name} ({facility.city})"))
                else:
                    failures += 1
                    self.stdout.write(self.style.WARNING(f"No results for: {facility.name} ({facility.city})"))

            except Exception as e:
                failures += 1
                self.stdout.write(self.style.ERROR(f"Error geocoding {facility.name} ({facility.city}): {e}"))

            # Respect rate limits
            time.sleep(delay)

        self.stdout.write(self.style.SUCCESS(
            f"Geocoding complete. Processed: {processed}, Successes: {successes}, Failures: {failures}"
        ))
        if dry_run:
            self.stdout.write(self.style.WARNING("Dry-run: no changes saved."))