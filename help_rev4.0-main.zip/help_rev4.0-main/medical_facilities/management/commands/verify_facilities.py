from django.core.management.base import BaseCommand
from medical_facilities.models import MedicalFacility
import requests
from urllib.parse import urlparse
import re


class Command(BaseCommand):
    help = 'Weryfikuje czy placówki nadal istnieją i oferują usługi'

    def add_arguments(self, parser):
        parser.add_argument(
            '--limit',
            type=int,
            default=50,
            help='Maksymalna liczba placówek do weryfikacji (domyślnie: 50)',
        )
        parser.add_argument(
            '--check-website',
            action='store_true',
            help='Sprawdź czy strony WWW działają',
        )
        parser.add_argument(
            '--update-status',
            action='store_true',
            help='Zaktualizuj status placówek które nie istnieją',
        )

    def _check_website(self, url):
        """Sprawdza czy strona WWW działa"""
        if not url:
            return None
        
        try:
            # Dodaj http:// jeśli brakuje
            if not url.startswith('http'):
                url = 'http://' + url
            
            response = requests.get(url, timeout=10, allow_redirects=True)
            return response.status_code == 200
        except:
            return False

    def _check_phone_format(self, phone):
        """Sprawdza format telefonu"""
        if not phone:
            return None
        
        # Usuń spacje i znaki specjalne
        clean_phone = re.sub(r'[\s\-\(\)]', '', phone)
        
        # Sprawdź czy ma odpowiednią długość (9-15 cyfr)
        if len(clean_phone) >= 9 and len(clean_phone) <= 15:
            return True
        return False

    def handle(self, *args, **options):
        limit = options['limit']
        check_website = options['check_website']
        update_status = options['update_status']
        
        self.stdout.write(self.style.SUCCESS('🔍 Weryfikacja placówek...\n'))
        
        facilities = MedicalFacility.objects.filter(status='approved')[:limit]
        total = facilities.count()
        
        stats = {
            'total': total,
            'with_website': 0,
            'working_websites': 0,
            'broken_websites': 0,
            'with_phone': 0,
            'valid_phones': 0,
            'invalid_phones': 0,
            'no_contact': 0,
        }
        
        broken_facilities = []
        
        for facility in facilities:
            has_contact = False
            
            # Sprawdź stronę WWW
            if facility.website:
                stats['with_website'] += 1
                has_contact = True
                
                if check_website:
                    is_working = self._check_website(facility.website)
                    if is_working:
                        stats['working_websites'] += 1
                        self.stdout.write(
                            self.style.SUCCESS(
                                f'✓ {facility.name[:50]}... - WWW działa'
                            )
                        )
                    else:
                        stats['broken_websites'] += 1
                        broken_facilities.append((facility, 'broken_website'))
                        self.stdout.write(
                            self.style.WARNING(
                                f'⚠ {facility.name[:50]}... - WWW nie działa: {facility.website}'
                            )
                        )
            
            # Sprawdź telefon
            if facility.phone:
                stats['with_phone'] += 1
                has_contact = True
                
                is_valid = self._check_phone_format(facility.phone)
                if is_valid:
                    stats['valid_phones'] += 1
                else:
                    stats['invalid_phones'] += 1
                    if facility not in [f for f, _ in broken_facilities]:
                        broken_facilities.append((facility, 'invalid_phone'))
            
            if not has_contact:
                stats['no_contact'] += 1
        
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS('📊 PODSUMOWANIE WERYFIKACJI'))
        self.stdout.write('=' * 60)
        self.stdout.write(f'Przetworzono: {stats["total"]}')
        self.stdout.write(f'Ze stroną WWW: {stats["with_website"]}')
        if check_website:
            self.stdout.write(f'  Działające: {stats["working_websites"]}')
            self.stdout.write(f'  Niedziałające: {stats["broken_websites"]}')
        self.stdout.write(f'Z telefonem: {stats["with_phone"]}')
        self.stdout.write(f'  Poprawne: {stats["valid_phones"]}')
        self.stdout.write(f'  Niepoprawne: {stats["invalid_phones"]}')
        self.stdout.write(f'Bez danych kontaktowych: {stats["no_contact"]}')
        
        if broken_facilities:
            self.stdout.write(f'\n⚠ Znaleziono {len(broken_facilities)} placówek z problemami:')
            for facility, problem in broken_facilities[:10]:
                self.stdout.write(f'  - {facility.name[:50]}... ({problem})')
            
            if update_status:
                self.stdout.write(self.style.WARNING('\n🗑️  Zmienianie statusu na "suspended"...'))
                for facility, problem in broken_facilities:
                    if problem == 'broken_website':
                        facility.status = 'suspended'
                        facility.moderator_notes = f'Strona WWW nie działa: {facility.website}'
                        facility.save(update_fields=['status', 'moderator_notes'])
                self.stdout.write(self.style.SUCCESS(f'✅ Zaktualizowano {len(broken_facilities)} placówek'))
            else:
                self.stdout.write(self.style.WARNING('\nUruchom z --update-status aby zmienić status na "suspended"'))

