from django.core.management.base import BaseCommand
from medical_facilities.models import MedicalFacility
from django.db.models import Count, Q


class Command(BaseCommand):
    help = 'Usuwa zduplikowane placówki bez opisów, pozostawiając te z opisami'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko pokaż co zostałoby usunięte, bez faktycznego usuwania',
        )
        parser.add_argument(
            '--force',
            action='store_true',
            help='Usuń wszystkie duplikaty bez opisów, nawet jeśli nie ma wersji z opisem',
        )

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        force = options['force']
        
        self.stdout.write(self.style.SUCCESS('🔍 Szukanie zduplikowanych placówek...\n'))
        
        # Znajdź duplikaty po nazwie i mieście
        duplicates = MedicalFacility.objects.values('name', 'city').annotate(
            count=Count('id')
        ).filter(count__gt=1)
        
        total_duplicates = duplicates.count()
        self.stdout.write(f'Znaleziono {total_duplicates} grup duplikatów\n')
        
        to_delete = []
        stats = {
            'deleted': 0,
            'kept_with_description': 0,
            'kept_without_description': 0,
            'groups_processed': 0,
        }
        
        for dup_group in duplicates:
            name = dup_group['name']
            city = dup_group['city']
            count = dup_group['count']
            
            facilities = MedicalFacility.objects.filter(name=name, city=city).order_by(
                '-description',  # Te z opisem pierwsze
                '-created_at'     # Potem najnowsze
            )
            
            stats['groups_processed'] += 1
            
            # Znajdź placówki z opisem i bez opisu
            with_description = [f for f in facilities if f.description and f.description.strip()]
            without_description = [f for f in facilities if not f.description or not f.description.strip()]
            
            if not with_description and not force:
                # Jeśli nie ma żadnej z opisem, pomiń (chyba że --force)
                self.stdout.write(
                    self.style.WARNING(
                        f'⚠ Pominięto grupę "{name[:50]}..." ({city}): '
                        f'{count} duplikatów, wszystkie bez opisu'
                    )
                )
                continue
            
            # Jeśli są placówki z opisem, usuń wszystkie bez opisu
            if with_description:
                # Zachowaj pierwszą z opisem (najlepszą)
                keep = with_description[0]
                stats['kept_with_description'] += 1
                
                # Usuń wszystkie bez opisu
                for facility in without_description:
                    to_delete.append(facility)
                    stats['deleted'] += 1
                
                # Jeśli jest więcej niż jedna z opisem, usuń pozostałe (zachowaj najlepszą)
                if len(with_description) > 1:
                    for facility in with_description[1:]:
                        to_delete.append(facility)
                        stats['deleted'] += 1
                
                self.stdout.write(
                    self.style.SUCCESS(
                        f'✓ Grupa "{name[:50]}..." ({city}): '
                        f'Zachowano 1 z opisem, do usunięcia {len(without_description) + len(with_description) - 1}'
                    )
                )
            else:
                # Wszystkie bez opisu - jeśli --force, zostaw tylko jedną
                if force:
                    keep = facilities[0]
                    stats['kept_without_description'] += 1
                    
                    for facility in facilities[1:]:
                        to_delete.append(facility)
                        stats['deleted'] += 1
                    
                    self.stdout.write(
                        self.style.WARNING(
                            f'⚠ Grupa "{name[:50]}..." ({city}): '
                            f'Wszystkie bez opisu, zachowano 1 (--force), do usunięcia {count - 1}'
                        )
                    )
        
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS('📊 PODSUMOWANIE'))
        self.stdout.write('=' * 60)
        self.stdout.write(f'Przetworzono grup: {stats["groups_processed"]}')
        self.stdout.write(f'Zachowano z opisem: {stats["kept_with_description"]}')
        self.stdout.write(f'Zachowano bez opisu (--force): {stats["kept_without_description"]}')
        self.stdout.write(f'Do usunięcia: {stats["deleted"]}')
        
        if not to_delete:
            self.stdout.write(self.style.SUCCESS('\n✅ Nie znaleziono duplikatów do usunięcia!'))
            return
        
        if dry_run:
            self.stdout.write(self.style.WARNING(f'\n🔍 DRY RUN: Zostałoby usuniętych {len(to_delete)} placówek:'))
            for facility in to_delete[:20]:  # Pokaż pierwsze 20
                self.stdout.write(f'  - ID: {facility.id}, {facility.name[:50]}... ({facility.city})')
            if len(to_delete) > 20:
                self.stdout.write(f'  ... i {len(to_delete) - 20} więcej')
            self.stdout.write(self.style.WARNING('\nUruchom ponownie bez --dry-run aby faktycznie usunąć.'))
        else:
            self.stdout.write(self.style.WARNING(f'\n🗑️  Usuwanie {len(to_delete)} placówek...'))
            
            # Usuń w partiach dla bezpieczeństwa
            batch_size = 50
            deleted_count = 0
            
            for i in range(0, len(to_delete), batch_size):
                batch = to_delete[i:i + batch_size]
                ids = [f.id for f in batch]
                deleted, _ = MedicalFacility.objects.filter(id__in=ids).delete()
                deleted_count += deleted
                self.stdout.write(f'  Usunięto {deleted_count}/{len(to_delete)}...')
            
            self.stdout.write(self.style.SUCCESS(f'\n✅ Usunięto {deleted_count} zduplikowanych placówek!'))

