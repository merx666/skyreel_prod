import os
import subprocess
import tempfile
import sqlite3
import re
from django.core.management.base import BaseCommand
from django.conf import settings
from django.db import connection
from medical_facilities.models import (
    MedicalFacility, FacilityRating, FacilityImage,
    Voivodeship, AddictionType, FacilityType, TherapyType, AgeGroup
)
from django.contrib.auth.models import User


class Command(BaseCommand):
    help = 'Importuje dane ze starej bazy danych MySQL'

    def add_arguments(self, parser):
        parser.add_argument(
            '--sql-file',
            type=str,
            default='staryhelp_baza/stary_help_baza.sql',
            help='Ścieżka do pliku SQL ze starą bazą danych'
        )
        parser.add_argument(
            '--temp-db-name',
            type=str,
            default='old_hyperreal_help',
            help='Nazwa tymczasowej bazy danych do importu'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko wyświetl dane, które zostaną zaimportowane, bez faktycznego importu'
        )

    def handle(self, *args, **options):
        sql_file = options['sql_file']
        temp_db_name = options['temp_db_name']
        dry_run = options['dry_run']

        if not os.path.exists(sql_file):
            self.stdout.write(self.style.ERROR(f'Plik SQL nie istnieje: {sql_file}'))
            return

        # Rozpakuj plik .gz jeśli to konieczne
        if sql_file.endswith('.gz'):
            self.stdout.write(self.style.WARNING('Rozpakowywanie pliku gzip...'))
            with tempfile.NamedTemporaryFile(delete=False, suffix='.sql') as temp_file:
                temp_sql_path = temp_file.name
            
            try:
                subprocess.run(['gunzip', '-c', sql_file], stdout=open(temp_sql_path, 'wb'), check=True)
                sql_file = temp_sql_path
                self.stdout.write(self.style.SUCCESS('Plik rozpakowany pomyślnie'))
            except subprocess.CalledProcessError as e:
                self.stdout.write(self.style.ERROR(f'Błąd podczas rozpakowywania: {e}'))
                return

        # Utwórz tymczasową bazę danych
        self.stdout.write(self.style.WARNING(f'Tworzenie tymczasowej bazy danych: {temp_db_name}'))
        
        try:
            # Połącz z serwerem MySQL
            db = MySQLdb.connect(
                host='localhost',
                user='root',
                passwd='',
                charset='utf8mb4'
            )
            cursor = db.cursor()
            
            # Usuń bazę jeśli istnieje
            cursor.execute(f"DROP DATABASE IF EXISTS {temp_db_name}")
            
            # Utwórz nową bazę
            cursor.execute(f"CREATE DATABASE {temp_db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            
            db.close()
            
            # Importuj dane do tymczasowej bazy
            self.stdout.write(self.style.WARNING('Importowanie danych do tymczasowej bazy...'))
            import_cmd = f"mysql -u root {temp_db_name} < {sql_file}"
            subprocess.run(import_cmd, shell=True, check=True)
            
            # Połącz z tymczasową bazą
            db = MySQLdb.connect(
                host='localhost',
                user='root',
                passwd='',
                db=temp_db_name,
                charset='utf8mb4'
            )
            cursor = db.cursor(MySQLdb.cursors.DictCursor)
            
            # Importuj dane
            self.import_data(cursor, dry_run)
            
            # Zamknij połączenie
            db.close()
            
            # Usuń tymczasową bazę
            if not dry_run:
                db = MySQLdb.connect(
                    host='localhost',
                    user='root',
                    passwd='',
                    charset='utf8mb4'
                )
                cursor = db.cursor()
                cursor.execute(f"DROP DATABASE IF EXISTS {temp_db_name}")
                db.close()
                self.stdout.write(self.style.SUCCESS('Tymczasowa baza danych usunięta'))
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Błąd: {e}'))
            return
        
        # Usuń tymczasowy plik SQL jeśli był rozpakowany
        if sql_file.endswith('.sql') and sql_file != options['sql_file']:
            os.unlink(sql_file)
        
        self.stdout.write(self.style.SUCCESS('Import zakończony pomyślnie'))

    def import_data(self, cursor, dry_run):
        """Importuje dane z tymczasowej bazy do aktualnej bazy Django"""
        
        # Importuj placówki
        self.import_facilities(cursor, dry_run)
        
        # Importuj oceny
        self.import_ratings(cursor, dry_run)
        
        # Importuj zdjęcia
        self.import_images(cursor, dry_run)

    def import_facilities(self, cursor, dry_run):
        """Importuje placówki medyczne"""
        self.stdout.write(self.style.WARNING('Importowanie placówek...'))
        
        # Pobierz placówki ze starej bazy
        cursor.execute("""
            SELECT * FROM node 
            WHERE type = 'placowka' 
            AND status = 1
        """)
        old_facilities = cursor.fetchall()
        
        # Pobierz dodatkowe dane o placówkach
        facility_data = {}
        for facility in old_facilities:
            nid = facility['nid']
            
            # Pobierz dane z tabeli field_data_field_*
            cursor.execute(f"""
                SELECT * FROM field_data_field_adres 
                WHERE entity_id = {nid} AND bundle = 'placowka'
            """)
            address_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_miasto 
                WHERE entity_id = {nid} AND bundle = 'placowka'
            """)
            city_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_kod_pocztowy 
                WHERE entity_id = {nid} AND bundle = 'placowka'
            """)
            postal_code_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_telefon 
                WHERE entity_id = {nid} AND bundle = 'placowka'
            """)
            phone_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_email 
                WHERE entity_id = {nid} AND bundle = 'placowka'
            """)
            email_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_www 
                WHERE entity_id = {nid} AND bundle = 'placowka'
            """)
            website_data = cursor.fetchone()
            
            # Pobierz dane o województwie
            cursor.execute(f"""
                SELECT t.name FROM field_data_field_wojewodztwo w
                JOIN taxonomy_term_data t ON w.field_wojewodztwo_tid = t.tid
                WHERE w.entity_id = {nid} AND w.bundle = 'placowka'
            """)
            voivodeship_data = cursor.fetchone()
            
            # Pobierz dane o typach placówek
            cursor.execute(f"""
                SELECT t.name FROM field_data_field_typ_placowki tp
                JOIN taxonomy_term_data t ON tp.field_typ_placowki_tid = t.tid
                WHERE tp.entity_id = {nid} AND tp.bundle = 'placowka'
            """)
            facility_types_data = cursor.fetchall()
            
            # Pobierz dane o typach terapii
            cursor.execute(f"""
                SELECT t.name FROM field_data_field_typ_terapii tt
                JOIN taxonomy_term_data t ON tt.field_typ_terapii_tid = t.tid
                WHERE tt.entity_id = {nid} AND tt.bundle = 'placowka'
            """)
            therapy_types_data = cursor.fetchall()
            
            # Pobierz dane o grupach wiekowych
            cursor.execute(f"""
                SELECT t.name FROM field_data_field_grupa_wiekowa gw
                JOIN taxonomy_term_data t ON gw.field_grupa_wiekowa_tid = t.tid
                WHERE gw.entity_id = {nid} AND gw.bundle = 'placowka'
            """)
            age_groups_data = cursor.fetchall()
            
            # Zapisz dane w słowniku
            facility_data[nid] = {
                'title': facility['title'],
                'created': facility['created'],
                'changed': facility['changed'],
                'address': address_data['field_adres_value'] if address_data else None,
                'city': city_data['field_miasto_value'] if city_data else None,
                'postal_code': postal_code_data['field_kod_pocztowy_value'] if postal_code_data else None,
                'phone': phone_data['field_telefon_value'] if phone_data else None,
                'email': email_data['field_email_email'] if email_data else None,
                'website': website_data['field_www_url'] if website_data else None,
                'voivodeship': voivodeship_data['name'] if voivodeship_data else None,
                'facility_types': [ft['name'] for ft in facility_types_data],
                'therapy_types': [tt['name'] for tt in therapy_types_data],
                'age_groups': [ag['name'] for ag in age_groups_data]
            }
        
        # Importuj dane do nowej bazy
        imported_count = 0
        skipped_count = 0
        
        for nid, data in facility_data.items():
            # Sprawdź czy placówka już istnieje (po nazwie i adresie)
            existing = MedicalFacility.objects.filter(
                name=data['title'],
                address=data['address'],
                city=data['city']
            ).first()
            
            if existing:
                skipped_count += 1
                continue
            
            # Znajdź lub utwórz województwo
            voivodeship = None
            if data['voivodeship']:
                voivodeship, _ = Voivodeship.objects.get_or_create(
                    name=data['voivodeship']
                )
            
            # Utwórz nową placówkę
            if not dry_run:
                facility = MedicalFacility(
                    name=data['title'],
                    address=data['address'],
                    city=data['city'],
                    postal_code=data['postal_code'],
                    phone=data['phone'],
                    email=data['email'],
                    website=data['website'],
                    voivodeship=voivodeship,
                    status='approved',
                    created_at=data['created'],
                    updated_at=data['changed']
                )
                facility.save()
                
                # Dodaj typy placówek
                for ft_name in data['facility_types']:
                    ft, _ = FacilityType.objects.get_or_create(name=ft_name)
                    facility.facility_types.add(ft)
                
                # Dodaj typy terapii
                for tt_name in data['therapy_types']:
                    tt, _ = TherapyType.objects.get_or_create(name=tt_name)
                    facility.therapy_types.add(tt)
                
                # Dodaj grupy wiekowe
                for ag_name in data['age_groups']:
                    ag, _ = AgeGroup.objects.get_or_create(name=ag_name)
                    facility.age_groups.add(ag)
                
                imported_count += 1
            else:
                imported_count += 1
        
        self.stdout.write(self.style.SUCCESS(
            f'Placówki: {imported_count} do zaimportowania, {skipped_count} pominiętych'
        ))

    def import_ratings(self, cursor, dry_run):
        """Importuje oceny placówek"""
        self.stdout.write(self.style.WARNING('Importowanie ocen...'))
        
        # Pobierz oceny ze starej bazy
        cursor.execute("""
            SELECT c.*, f.entity_id as facility_id, u.name as username
            FROM comment c
            JOIN field_data_field_ocena_placowki f ON c.cid = f.entity_id AND f.bundle = 'comment_node_placowka'
            JOIN users u ON c.uid = u.uid
            WHERE c.status = 1
        """)
        old_ratings = cursor.fetchall()
        
        imported_count = 0
        skipped_count = 0
        
        for rating in old_ratings:
            # Pobierz dane o ocenie
            cursor.execute(f"""
                SELECT * FROM field_data_field_ocena_ogolna
                WHERE entity_id = {rating['cid']} AND bundle = 'comment_node_placowka'
            """)
            overall_rating_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_ocena_personel
                WHERE entity_id = {rating['cid']} AND bundle = 'comment_node_placowka'
            """)
            staff_rating_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_ocena_warunki
                WHERE entity_id = {rating['cid']} AND bundle = 'comment_node_placowka'
            """)
            facilities_rating_data = cursor.fetchone()
            
            cursor.execute(f"""
                SELECT * FROM field_data_field_ocena_leczenie
                WHERE entity_id = {rating['cid']} AND bundle = 'comment_node_placowka'
            """)
            treatment_rating_data = cursor.fetchone()
            
            # Znajdź placówkę w nowej bazie
            try:
                # Pobierz tytuł placówki
                cursor.execute(f"""
                    SELECT title FROM node WHERE nid = {rating['facility_id']}
                """)
                facility_title = cursor.fetchone()['title']
                
                facility = MedicalFacility.objects.filter(name=facility_title).first()
                
                if not facility:
                    skipped_count += 1
                    continue
                
                # Sprawdź czy ocena już istnieje
                existing = FacilityRating.objects.filter(
                    facility=facility,
                    comment=rating['subject']
                ).first()
                
                if existing:
                    skipped_count += 1
                    continue
                
                # Utwórz użytkownika jeśli nie istnieje
                username = rating['username']
                user = None
                
                if username != 'Anonymous':
                    user, _ = User.objects.get_or_create(
                        username=username,
                        defaults={'email': f'{username}@example.com'}
                    )
                
                # Utwórz nową ocenę
                if not dry_run:
                    new_rating = FacilityRating(
                        facility=facility,
                        user=user,
                        overall_rating=overall_rating_data['field_ocena_ogolna_value'] if overall_rating_data else 0,
                        staff_rating=staff_rating_data['field_ocena_personel_value'] if staff_rating_data else None,
                        facilities_rating=facilities_rating_data['field_ocena_warunki_value'] if facilities_rating_data else None,
                        treatment_rating=treatment_rating_data['field_ocena_leczenie_value'] if treatment_rating_data else None,
                        comment=rating['subject'],
                        comment_text=rating['comment_body_value'],
                        status='approved',
                        created_at=rating['created'],
                        updated_at=rating['changed']
                    )
                    new_rating.save()
                    
                    imported_count += 1
                else:
                    imported_count += 1
                    
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Błąd podczas importu oceny: {e}'))
                skipped_count += 1
        
        self.stdout.write(self.style.SUCCESS(
            f'Oceny: {imported_count} do zaimportowania, {skipped_count} pominiętych'
        ))

    def import_images(self, cursor, dry_run):
        """Importuje zdjęcia placówek"""
        self.stdout.write(self.style.WARNING('Importowanie zdjęć...'))
        
        # Pobierz zdjęcia ze starej bazy
        cursor.execute("""
            SELECT f.*, n.title as facility_name
            FROM file_managed f
            JOIN field_data_field_zdjecie z ON f.fid = z.field_zdjecie_fid
            JOIN node n ON z.entity_id = n.nid
            WHERE n.type = 'placowka' AND n.status = 1
        """)
        old_images = cursor.fetchall()
        
        imported_count = 0
        skipped_count = 0
        
        for image in old_images:
            # Znajdź placówkę w nowej bazie
            facility = MedicalFacility.objects.filter(name=image['facility_name']).first()
            
            if not facility:
                skipped_count += 1
                continue
            
            # Sprawdź czy zdjęcie już istnieje
            existing = FacilityImage.objects.filter(
                facility=facility,
                image=f"facility_images/{image['filename']}"
            ).first()
            
            if existing:
                skipped_count += 1
                continue
            
            # Utwórz nowe zdjęcie
            if not dry_run:
                # Tutaj należałoby skopiować plik zdjęcia do katalogu media/facility_images/
                # W tym przykładzie pomijamy faktyczne kopiowanie plików
                
                new_image = FacilityImage(
                    facility=facility,
                    image=f"facility_images/{image['filename']}",
                    is_primary=(imported_count == 0),  # Pierwsze zdjęcie jako główne
                    created_at=image['timestamp']
                )
                new_image.save()
                
                imported_count += 1
            else:
                imported_count += 1
        
        self.stdout.write(self.style.SUCCESS(
            f'Zdjęcia: {imported_count} do zaimportowania, {skipped_count} pominiętych'
        ))