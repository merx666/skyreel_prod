from django.core.management.base import BaseCommand
from medical_facilities.models import MedicalFacility, Voivodeship, FacilityType
from bs4 import BeautifulSoup
import requests
import re
import time
from urllib.parse import urljoin, urlparse


class Command(BaseCommand):
    help = 'Wyszukuje nowe placówki leczenia uzależnień w internecie i dodaje je do bazy'

    def add_arguments(self, parser):
        parser.add_argument(
            '--limit',
            type=int,
            default=20,
            help='Maksymalna liczba nowych placówek do dodania (domyślnie: 20)',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko pokaż co zostałoby dodane, bez faktycznego dodawania',
        )

    def _get_known_facility_sources(self):
        """Zwraca listę znanych źródeł z placówkami"""
        # Lista znanych stron z bazami placówek
        sources = [
            {
                'name': 'MONAR',
                'base_url': 'https://www.monar.org',
                'search_paths': [
                    '/osrodki',
                    '/poradnie',
                ]
            },
            {
                'name': 'NFZ',
                'base_url': 'https://www.nfz.gov.pl',
                'search_paths': [
                    '/dla-pacjenta/gdzie-sie-leczyc',
                ]
            },
        ]
        return sources
    
    def _search_known_sources(self):
        """Wyszukuje w znanych źródłach"""
        results = []
        sources = self._get_known_facility_sources()
        
        for source in sources:
            try:
                for path in source['search_paths']:
                    url = source['base_url'] + path
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                    response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        
                        # Szukaj linków do placówek
                        for link in soup.find_all('a', href=True):
                            href = link.get('href', '')
                            text = link.get_text(strip=True)
                            
                            # Sprawdź czy link wygląda na placówkę
                            if any(keyword in text.lower() for keyword in [
                                'ośrodek', 'poradnia', 'centrum', 'terapia', 'uzależnienie'
                            ]):
                                full_url = urljoin(url, href)
                                if full_url not in [r['url'] for r in results]:
                                    results.append({
                                        'title': text,
                                        'url': full_url,
                                        'source': source['name']
                                    })
            except Exception as e:
                self.stdout.write(self.style.WARNING(f'Błąd przetwarzania {source["name"]}: {e}'))
        
        return results

    def _extract_facility_data(self, url, title):
        """Wyciąga dane placówki ze strony"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)
            if response.status_code != 200:
                return None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            data = {
                'name': title,
                'website': url,
                'phone': None,
                'email': None,
                'description': None,
            }
            
            # Wyciągnij telefon
            phone_patterns = [
                r'\+?\d{2,3}[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{3}',
                r'\+?\d{9,12}',
            ]
            text = soup.get_text()
            for pattern in phone_patterns:
                match = re.search(pattern, text)
                if match:
                    phone = re.sub(r'[\s\-]', '', match.group(0))
                    if len(phone) >= 9:
                        data['phone'] = phone
                        break
            
            # Wyciągnij email
            email_match = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
            if email_match:
                data['email'] = email_match.group(0)
            
            # Wyciągnij opis (pierwszy długi paragraf)
            paragraphs = soup.find_all('p')
            for p in paragraphs:
                text = p.get_text(strip=True)
                if len(text) > 100 and len(text) < 500:
                    if any(keyword in text.lower() for keyword in [
                        'ośrodek', 'poradnia', 'terapia', 'leczenie', 'uzależnienie'
                    ]):
                        data['description'] = text[:400]
                        break
            
            return data
        except Exception as e:
            self.stdout.write(self.style.WARNING(f'Błąd parsowania {url}: {e}'))
            return None

    def _find_voivodeship_by_city(self, city):
        """Próbuje znaleźć województwo na podstawie miasta"""
        # Prosta mapa miast -> województw (można rozszerzyć)
        city_to_voivodeship = {
            'warszawa': 'mazowieckie',
            'kraków': 'małopolskie',
            'wrocław': 'dolnośląskie',
            'poznań': 'wielkopolskie',
            'gdańsk': 'pomorskie',
            'łódź': 'łódzkie',
            'katowice': 'śląskie',
            'lublin': 'lubelskie',
            'białystok': 'podlaskie',
            'szczecin': 'zachodniopomorskie',
            'bydgoszcz': 'kujawsko-pomorskie',
            'lublin': 'lubelskie',
            'toruń': 'kujawsko-pomorskie',
            'zielona góra': 'lubuskie',
            'opole': 'opolskie',
            'rzeszów': 'podkarpackie',
            'kielce': 'świętokrzyskie',
            'olsztyn': 'warmińsko-mazurskie',
        }
        
        city_lower = city.lower()
        for key, voivodeship_name in city_to_voivodeship.items():
            if key in city_lower:
                try:
                    return Voivodeship.objects.get(name__icontains=voivodeship_name)
                except:
                    pass
        
        return None

    def handle(self, *args, **options):
        limit = options['limit']
        dry_run = options['dry_run']
        
        self.stdout.write(self.style.SUCCESS('🔍 Wyszukiwanie nowych placówek...\n'))
        
        # Wyszukaj w znanych źródłach
        self.stdout.write('Przeszukiwanie znanych źródeł...')
        all_results = self._search_known_sources()
        
        # Dodaj przykładowe placówki z różnych miast (do ręcznej weryfikacji)
        sample_facilities = [
            {
                'title': 'Ośrodek Terapii Uzależnień - Warszawa',
                'url': 'https://www.google.com/search?q=ośrodek+terapii+uzależnień+warszawa',
                'source': 'manual'
            },
            {
                'title': 'Poradnia Terapii Uzależnień - Kraków',
                'url': 'https://www.google.com/search?q=poradnia+terapii+uzależnień+kraków',
                'source': 'manual'
            },
        ]
        
        # Uwaga: Te są tylko przykładowe - w rzeczywistości potrzebne jest
        # ręczne dodawanie lub użycie API (np. Google Places API)
        self.stdout.write(self.style.WARNING(
            '\n⚠️  Uwaga: Automatyczne wyszukiwanie jest ograniczone.\n'
            'Dla pełnej funkcjonalności zalecane jest:\n'
            '1. Użycie Google Places API\n'
            '2. Import z baz NFZ\n'
            '3. Ręczne dodawanie przez formularz\n'
        ))
        
        # Usuń duplikaty
        seen_urls = set()
        unique_results = []
        for result in all_results:
            url = result.get('url', '')
            if url and url not in seen_urls:
                seen_urls.add(url)
                unique_results.append(result)
        
        self.stdout.write(f'\nZnaleziono {len(unique_results)} unikalnych wyników\n')
        
        added = 0
        skipped = 0
        
        for result in unique_results[:limit]:
            title = result.get('title', '')
            url = result.get('url', '')
            
            # Sprawdź czy placówka już istnieje
            if MedicalFacility.objects.filter(website=url).exists() or \
               MedicalFacility.objects.filter(name__icontains=title[:30]).exists():
                skipped += 1
                continue
            
            # Wyciągnij dane ze strony
            self.stdout.write(f'Przetwarzanie: {title[:50]}...')
            data = self._extract_facility_data(url, title)
            
            if not data:
                skipped += 1
                continue
            
            # Próbuj wyciągnąć miasto z URL lub tytułu
            city = None
            url_parts = urlparse(url)
            domain = url_parts.netloc.replace('www.', '')
            if '.' in domain:
                city = domain.split('.')[0]
            
            if not city:
                # Spróbuj z tytułu
                city_match = re.search(r'\b([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+)\b', title)
                if city_match:
                    city = city_match.group(1)
            
            if dry_run:
                self.stdout.write(
                    self.style.SUCCESS(
                        f'✓ Zostałaby dodana: {data["name"][:50]}...'
                    )
                )
                self.stdout.write(f'  URL: {data["website"]}')
                self.stdout.write(f'  Tel: {data["phone"] or "brak"}')
                self.stdout.write(f'  Email: {data["email"] or "brak"}')
            else:
                # Stwórz nową placówkę
                voivodeship = self._find_voivodeship_by_city(city) if city else None
                if not voivodeship:
                    # Użyj pierwszego dostępnego województwa jako domyślnego
                    voivodeship = Voivodeship.objects.first()
                
                facility = MedicalFacility(
                    name=data['name'],
                    website=data['website'],
                    phone=data['phone'] or '',
                    email=data['email'] or '',
                    description=data['description'] or '',
                    city=city or 'Nieznane',
                    street_address='Do weryfikacji',
                    postal_code='00-000',
                    voivodeship=voivodeship,
                    status='pending',  # Wymaga weryfikacji
                )
                facility.save()
                added += 1
                self.stdout.write(
                    self.style.SUCCESS(
                        f'✅ Dodano: {facility.name[:50]}...'
                    )
                )
            
            time.sleep(1)  # Opóźnienie między requestami
        
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS('📊 PODSUMOWANIE'))
        self.stdout.write('=' * 60)
        if dry_run:
            self.stdout.write(f'Zostałoby dodanych: {added}')
        else:
            self.stdout.write(f'Dodano: {added}')
        self.stdout.write(f'Pominięto: {skipped}')
        
        if dry_run:
            self.stdout.write(self.style.WARNING('\n🔍 DRY RUN: Uruchom ponownie bez --dry-run aby faktycznie dodać.'))

