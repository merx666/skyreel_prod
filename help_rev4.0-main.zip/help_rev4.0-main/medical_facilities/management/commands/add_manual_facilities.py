from django.core.management.base import BaseCommand
from medical_facilities.models import MedicalFacility, Voivodeship, FacilityType
from bs4 import BeautifulSoup
import requests
import re
from urllib.parse import urlparse


class Command(BaseCommand):
    help = 'Dodaje placówki na podstawie listy URL-i (do ręcznego użycia)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--urls',
            type=str,
            nargs='+',
            help='Lista URL-i placówek do dodania',
        )
        parser.add_argument(
            '--file',
            type=str,
            help='Plik tekstowy z URL-ami (jeden na linię)',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko pokaż co zostałoby dodane',
        )

    def _extract_facility_data(self, url):
        """Wyciąga dane placówki ze strony"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)
            if response.status_code != 200:
                return None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Wyciągnij tytuł
            title = soup.find('title')
            name = title.get_text(strip=True) if title else urlparse(url).netloc
            
            data = {
                'name': name,
                'website': url,
                'phone': None,
                'email': None,
                'description': None,
                'city': None,
                'address': None,
            }
            
            # Wyciągnij tekst strony
            text = soup.get_text()
            
            # Wyciągnij telefon
            phone_patterns = [
                r'\+?\d{2,3}[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{3}',
                r'\+?\d{9,12}',
                r'Tel[\.:]?\s*([+\d\s\-\(\)]{8,})',
            ]
            for pattern in phone_patterns:
                match = re.search(pattern, text)
                if match:
                    phone = re.sub(r'[\s\-\(\)]', '', match.group(0) if match.lastindex is None else match.group(1))
                    if len(phone) >= 9:
                        data['phone'] = phone
                        break
            
            # Wyciągnij email
            email_match = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
            if email_match:
                data['email'] = email_match.group(0)
            
            # Wyciągnij adres
            address_patterns = [
                r'ul\.\s+[A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż\s]+(?:\d+[a-z]?)?',
                r'[A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+\s+\d+',
            ]
            for pattern in address_patterns:
                match = re.search(pattern, text)
                if match:
                    data['address'] = match.group(0)
                    break
            
            # Wyciągnij miasto
            city_patterns = [
                r'\b([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+)\s+\d{2}-\d{3}\b',  # Miasto + kod pocztowy
                r'(\d{2}-\d{3})\s+([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+)',  # Kod + miasto
            ]
            for pattern in city_patterns:
                match = re.search(pattern, text)
                if match:
                    if match.lastindex >= 2:
                        data['city'] = match.group(2)
                    elif 'Warszawa' in text or 'Warszaw' in text:
                        data['city'] = 'Warszawa'
                    elif 'Kraków' in text or 'Krakow' in text:
                        data['city'] = 'Kraków'
                    elif 'Wrocław' in text or 'Wroclaw' in text:
                        data['city'] = 'Wrocław'
                    break
            
            # Wyciągnij opis
            paragraphs = soup.find_all(['p', 'div'])
            for p in paragraphs:
                text = p.get_text(strip=True)
                if 100 < len(text) < 1000:
                    if any(keyword in text.lower() for keyword in [
                        'ośrodek', 'poradnia', 'terapia', 'leczenie', 'uzależnienie',
                        'rehabilitacja', 'detoks', 'pomoc'
                    ]):
                        data['description'] = text[:500]
                        break
            
            return data
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Błąd parsowania {url}: {e}'))
            return None

    def _find_voivodeship_by_city(self, city):
        """Znajduje województwo na podstawie miasta"""
        if not city:
            return None
        
        city_lower = city.lower()
        city_to_voivodeship = {
            'warszawa': 'mazowieckie',
            'kraków': 'małopolskie',
            'krakow': 'małopolskie',
            'wrocław': 'dolnośląskie',
            'wroclaw': 'dolnośląskie',
            'poznań': 'wielkopolskie',
            'poznan': 'wielkopolskie',
            'gdańsk': 'pomorskie',
            'gdansk': 'pomorskie',
            'łódź': 'łódzkie',
            'lodz': 'łódzkie',
            'katowice': 'śląskie',
            'lublin': 'lubelskie',
            'białystok': 'podlaskie',
            'bialystok': 'podlaskie',
            'szczecin': 'zachodniopomorskie',
            'bydgoszcz': 'kujawsko-pomorskie',
            'toruń': 'kujawsko-pomorskie',
            'torun': 'kujawsko-pomorskie',
            'zielona góra': 'lubuskie',
            'zielona gora': 'lubuskie',
            'opole': 'opolskie',
            'rzeszów': 'podkarpackie',
            'rzeszow': 'podkarpackie',
            'kielce': 'świętokrzyskie',
            'olsztyn': 'warmińsko-mazurskie',
        }
        
        for key, voivodeship_name in city_to_voivodeship.items():
            if key in city_lower:
                try:
                    return Voivodeship.objects.get(name__icontains=voivodeship_name)
                except:
                    pass
        
        return Voivodeship.objects.first()  # Domyślne

    def handle(self, *args, **options):
        urls = options.get('urls', [])
        file_path = options.get('file')
        dry_run = options.get('dry_run', False)
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    urls.extend([line.strip() for line in f if line.strip()])
            except FileNotFoundError:
                self.stdout.write(self.style.ERROR(f'Plik nie znaleziony: {file_path}'))
                return
        
        if not urls:
            self.stdout.write(self.style.ERROR('Brak URL-i do przetworzenia. Użyj --urls lub --file'))
            return
        
        self.stdout.write(self.style.SUCCESS(f'🔍 Przetwarzanie {len(urls)} URL-i...\n'))
        
        added = 0
        skipped = 0
        errors = 0
        
        for url in urls:
            if not url.startswith('http'):
                url = 'http://' + url
            
            self.stdout.write(f'Przetwarzanie: {url}...')
            
            # Sprawdź czy już istnieje
            if MedicalFacility.objects.filter(website=url).exists():
                self.stdout.write(self.style.WARNING('  ⚠ Już istnieje'))
                skipped += 1
                continue
            
            # Wyciągnij dane
            data = self._extract_facility_data(url)
            
            if not data:
                self.stdout.write(self.style.ERROR('  ✗ Nie udało się wyciągnąć danych'))
                errors += 1
                continue
            
            # Znajdź województwo
            voivodeship = self._find_voivodeship_by_city(data.get('city'))
            
            if dry_run:
                self.stdout.write(self.style.SUCCESS(f'  ✓ Zostałaby dodana: {data["name"][:60]}'))
                self.stdout.write(f'     Miasto: {data.get("city", "Nieznane")}')
                self.stdout.write(f'     Tel: {data.get("phone", "brak")}')
                self.stdout.write(f'     Email: {data.get("email", "brak")}')
            else:
                facility = MedicalFacility(
                    name=data['name'],
                    website=data['website'],
                    phone=data.get('phone', ''),
                    email=data.get('email', ''),
                    description=data.get('description', ''),
                    city=data.get('city', 'Nieznane'),
                    street_address=data.get('address', 'Do weryfikacji'),
                    postal_code='00-000',
                    voivodeship=voivodeship,
                    status='pending',
                )
                facility.save()
                added += 1
                self.stdout.write(self.style.SUCCESS(f'  ✅ Dodano: {facility.name[:60]}'))
        
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS('📊 PODSUMOWANIE'))
        self.stdout.write('=' * 60)
        if dry_run:
            self.stdout.write(f'Zostałoby dodanych: {added}')
        else:
            self.stdout.write(f'Dodano: {added}')
        self.stdout.write(f'Pominięto: {skipped}')
        self.stdout.write(f'Błędy: {errors}')

