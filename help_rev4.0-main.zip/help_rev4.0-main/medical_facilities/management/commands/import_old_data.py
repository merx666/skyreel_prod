import os
import re
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from medical_facilities.models import (
    MedicalFacility, FacilityRating, FacilityImage,
    Voivodeship, AddictionType, FacilityType, TherapyType, AgeGroup
)

class Command(BaseCommand):
    help = 'Importuje dane ze starej bazy danych'

    def add_arguments(self, parser):
        parser.add_argument(
            '--file',
            type=str,
            default='staryhelp_baza/stary_help_baza.sql',
            help='Ścieżka do pliku SQL ze starą bazą danych'
        )

    def handle(self, *args, **options):
        sql_file = options['file']
        
        if not os.path.exists(sql_file):
            self.stdout.write(self.style.ERROR(f'Plik SQL nie istnieje: {sql_file}'))
            return
        
        # Wczytaj plik SQL
        try:
            with open(sql_file, 'r', encoding='latin1') as f:
                sql_content = f.read()
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Błąd podczas wczytywania pliku: {e}'))
            return
        
        # Importuj dane
        self.import_facilities(sql_content)
        self.import_ratings(sql_content)
        
        self.stdout.write(self.style.SUCCESS('Import zakończony pomyślnie'))
    
    def import_facilities(self, sql_content):
        """Importuje placówki medyczne"""
        self.stdout.write('Importowanie placówek...')
        
        # Znajdź wszystkie placówki
        placowki_count = 0
        
        # Szukaj wpisów w tabeli node dla typu 'placowka'
        node_pattern = r"INSERT INTO `node` VALUES \((\d+),[^,]*,'([^']*)',[^,]*,'placowka'"
        for match in re.finditer(node_pattern, sql_content):
            nid = match.group(1)
            name = match.group(2)
            
            # Sprawdź czy placówka już istnieje
            if MedicalFacility.objects.filter(name=name).exists():
                continue
            
            # Utwórz nową placówkę
            facility = MedicalFacility(
                name=name,
                status='approved'
            )
            
            # Znajdź adres
            address_match = re.search(r"INSERT INTO `field_data_field_adres`.*?entity_id = " + nid + ".*?field_adres_value = '([^']*)'", sql_content)
            if address_match:
                facility.address = address_match.group(1)
            
            # Znajdź miasto
            city_match = re.search(r"INSERT INTO `field_data_field_miasto`.*?entity_id = " + nid + ".*?field_miasto_value = '([^']*)'", sql_content)
            if city_match:
                facility.city = city_match.group(1)
            
            # Znajdź kod pocztowy
            postal_match = re.search(r"INSERT INTO `field_data_field_kod_pocztowy`.*?entity_id = " + nid + ".*?field_kod_pocztowy_value = '([^']*)'", sql_content)
            if postal_match:
                facility.postal_code = postal_match.group(1)
            
            # Znajdź telefon
            phone_match = re.search(r"INSERT INTO `field_data_field_telefon`.*?entity_id = " + nid + ".*?field_telefon_value = '([^']*)'", sql_content)
            if phone_match:
                facility.phone = phone_match.group(1)
            
            # Znajdź email
            email_match = re.search(r"INSERT INTO `field_data_field_email`.*?entity_id = " + nid + ".*?field_email_email = '([^']*)'", sql_content)
            if email_match:
                facility.email = email_match.group(1)
            
            # Znajdź stronę www
            website_match = re.search(r"INSERT INTO `field_data_field_www`.*?entity_id = " + nid + ".*?field_www_url = '([^']*)'", sql_content)
            if website_match:
                facility.website = website_match.group(1)
            
            # Zapisz placówkę
            facility.save()
            
            # Znajdź województwo
            voivodeship_match = re.search(r"INSERT INTO `field_data_field_wojewodztwo`.*?entity_id = " + nid + ".*?field_wojewodztwo_tid = (\d+)", sql_content)
            if voivodeship_match:
                tid = voivodeship_match.group(1)
                taxonomy_match = re.search(r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)'", sql_content)
                if taxonomy_match:
                    voivodeship_name = taxonomy_match.group(1)
                    voivodeship, _ = Voivodeship.objects.get_or_create(name=voivodeship_name)
                    facility.voivodeship = voivodeship
                    facility.save()
            
            # Znajdź typy placówek
            for ft_match in re.finditer(r"INSERT INTO `field_data_field_typ_placowki`.*?entity_id = " + nid + ".*?field_typ_placowki_tid = (\d+)", sql_content):
                tid = ft_match.group(1)
                taxonomy_match = re.search(r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)'", sql_content)
                if taxonomy_match:
                    ft_name = taxonomy_match.group(1)
                    ft, _ = FacilityType.objects.get_or_create(name=ft_name)
                    facility.facility_types.add(ft)
            
            # Znajdź typy terapii
            for tt_match in re.finditer(r"INSERT INTO `field_data_field_typ_terapii`.*?entity_id = " + nid + ".*?field_typ_terapii_tid = (\d+)", sql_content):
                tid = tt_match.group(1)
                taxonomy_match = re.search(r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)'", sql_content)
                if taxonomy_match:
                    tt_name = taxonomy_match.group(1)
                    tt, _ = TherapyType.objects.get_or_create(name=tt_name)
                    facility.therapy_types.add(tt)
            
            # Znajdź grupy wiekowe
            for ag_match in re.finditer(r"INSERT INTO `field_data_field_grupa_wiekowa`.*?entity_id = " + nid + ".*?field_grupa_wiekowa_tid = (\d+)", sql_content):
                tid = ag_match.group(1)
                taxonomy_match = re.search(r"INSERT INTO `taxonomy_term_data` VALUES \(" + tid + ",[^,]*,'([^']*)'", sql_content)
                if taxonomy_match:
                    ag_name = taxonomy_match.group(1)
                    ag, _ = AgeGroup.objects.get_or_create(name=ag_name)
                    facility.age_groups.add(ag)
            
            placowki_count += 1
            if placowki_count % 10 == 0:
                self.stdout.write(f'Zaimportowano {placowki_count} placówek')
        
        self.stdout.write(self.style.SUCCESS(f'Zaimportowano {placowki_count} placówek'))
    
    def import_ratings(self, sql_content):
        """Importuje oceny placówek"""
        self.stdout.write('Importowanie ocen...')
        
        # Znajdź wszystkie komentarze (oceny)
        oceny_count = 0
        
        # Szukaj wpisów w tabeli comment
        comment_pattern = r"INSERT INTO `comment` VALUES \((\d+),\d+,(\d+),[^,]*,\d+,[^,]*,'([^']*)',[^,]*,'([^']*)',[^,]*,(\d+),(\d+)"
        for match in re.finditer(comment_pattern, sql_content):
            cid = match.group(1)
            nid = match.group(2)
            subject = match.group(3)
            comment_text = match.group(4).replace('\\n', '\n').replace('\\r', '\r')
            created = match.group(5)
            changed = match.group(6)
            
            # Znajdź placówkę
            node_match = re.search(r"INSERT INTO `node` VALUES \(" + nid + ",[^,]*,'([^']*)'", sql_content)
            if not node_match:
                continue
            
            facility_name = node_match.group(1)
            facility = MedicalFacility.objects.filter(name=facility_name).first()
            
            if not facility:
                continue
            
            # Sprawdź czy ocena już istnieje
            if FacilityRating.objects.filter(facility=facility, comment=subject).exists():
                continue
            
            # Znajdź oceny
            overall_rating = 0
            overall_match = re.search(r"INSERT INTO `field_data_field_ocena_ogolna`.*?entity_id = " + cid + ".*?field_ocena_ogolna_value = '(\d+)'", sql_content)
            if overall_match:
                overall_rating = int(overall_match.group(1))
            
            staff_rating = None
            staff_match = re.search(r"INSERT INTO `field_data_field_ocena_personel`.*?entity_id = " + cid + ".*?field_ocena_personel_value = '(\d+)'", sql_content)
            if staff_match:
                staff_rating = int(staff_match.group(1))
            
            facilities_rating = None
            facilities_match = re.search(r"INSERT INTO `field_data_field_ocena_warunki`.*?entity_id = " + cid + ".*?field_ocena_warunki_value = '(\d+)'", sql_content)
            if facilities_match:
                facilities_rating = int(facilities_match.group(1))
            
            treatment_rating = None
            treatment_match = re.search(r"INSERT INTO `field_data_field_ocena_leczenie`.*?entity_id = " + cid + ".*?field_ocena_leczenie_value = '(\d+)'", sql_content)
            if treatment_match:
                treatment_rating = int(treatment_match.group(1))
            
            # Utwórz nową ocenę
            rating = FacilityRating(
                facility=facility,
                overall_rating=overall_rating,
                staff_rating=staff_rating,
                facilities_rating=facilities_rating,
                treatment_rating=treatment_rating,
                comment=subject,
                comment_text=comment_text,
                status='approved',
                created_at=created,
                updated_at=changed
            )
            
            # Zapisz ocenę
            rating.save()
            
            oceny_count += 1
            if oceny_count % 10 == 0:
                self.stdout.write(f'Zaimportowano {oceny_count} ocen')
        
        self.stdout.write(self.style.SUCCESS(f'Zaimportowano {oceny_count} ocen'))