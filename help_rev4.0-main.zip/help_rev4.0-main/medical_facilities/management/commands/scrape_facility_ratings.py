"""
Django management command do scrapowania ocen placówek ze starej strony hyperreal.info/help
"""
import re
import time
from urllib.parse import quote, unquote
from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import User
from django.db import transaction

from medical_facilities.models import MedicalFacility, FacilityRating

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    raise CommandError(
        'Ten skrypt wymaga bibliotek requests i beautifulsoup4.\n'
        'Zainstaluj je: pip install requests beautifulsoup4'
    )


class Command(BaseCommand):
    help = 'Scrapuje oceny placówek ze starej strony hyperreal.info/help'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tryb testowy - nie zapisuje zmian do bazy'
        )
        parser.add_argument(
            '--limit',
            type=int,
            default=None,
            help='Ogranicza liczbę placówek do przetworzenia'
        )
        parser.add_argument(
            '--delay',
            type=float,
            default=1.0,
            help='Opóźnienie między requestami w sekundach (domyślnie: 1.0)'
        )
        parser.add_argument(
            '--force',
            action='store_true',
            help='Wymuś aktualizację nawet jeśli ocena już istnieje'
        )

    def handle(self, *args, **options):
        dry_run = options.get('dry_run', False)
        limit = options.get('limit')
        delay = options.get('delay', 1.0)
        force = options.get('force', False)

        if dry_run:
            self.stdout.write(self.style.WARNING('TRYB TESTOWY - żadne zmiany nie zostaną zapisane'))

        # Pobierz listę placówek ze strony glossary
        self.stdout.write('Pobieranie listy placówek ze strony glossary...')
        facilities_from_glossary = self._scrape_glossary_page(delay)
        
        if not facilities_from_glossary:
            self.stdout.write(self.style.ERROR('Nie udało się pobrać listy placówek ze strony glossary'))
            return
        
        self.stdout.write(f'Znaleziono {len(facilities_from_glossary)} placówek na stronie glossary\n')

        # Jeśli podano limit, ogranicz
        if limit:
            facilities_from_glossary = facilities_from_glossary[:limit]

        self.stdout.write(f'Przetwarzanie {len(facilities_from_glossary)} placówek')
        self.stdout.write(f'Opóźnienie między requestami: {delay}s\n')

        total_scraped = 0
        total_updated = 0
        errors = []
        not_found = []

        for facility_data in facilities_from_glossary:
            facility_name = facility_data['name']
            facility_url = facility_data['url']
            
            try:
                # Znajdź placówkę w bazie Django
                facility = self._find_facility_by_name(facility_name)
                
                if not facility:
                    not_found.append(facility_name)
                    self.stdout.write(
                        self.style.WARNING(
                            f'  ? {facility_name[:50]}... - nie znaleziono w bazie Django'
                        )
                    )
                    continue
                
                # Scrapuj oceny używając znalezionego URL
                ratings = self._scrape_facility_ratings_from_url(facility_url, delay)
                
                if ratings:
                    if not dry_run:
                        # Sprawdź czy ocena już istnieje przed zapisem
                        was_existing = FacilityRating.objects.filter(
                            facility=facility,
                            user__isnull=True,
                            comment=''
                        ).exists()
                        
                        updated = self._save_ratings(facility, ratings, force)
                        if updated:
                            total_updated += 1
                            action = "utworzono" if not was_existing else "zaktualizowano"
                            self.stdout.write(
                                self.style.SUCCESS(
                                    f'✓ {facility.name[:50]}... - {action} oceny: {ratings}'
                                )
                            )
                        else:
                            self.stdout.write(f'  {facility.name[:50]}... - brak zmian w ocenach')
                    else:
                        self.stdout.write(
                            self.style.SUCCESS(
                                f'  [DRY-RUN] {facility.name[:50]}... - znaleziono oceny: {ratings}'
                            )
                        )
                        total_scraped += 1
                else:
                    # Tylko pokazuj informację o braku ocen co 20 placówek, żeby nie zaśmiecać wyjścia
                    processed_count = len([f for f in facilities_from_glossary[:facilities_from_glossary.index(facility_data) + 1] if f])
                    if processed_count % 20 == 0:
                        self.stdout.write(f'  Przetworzono {processed_count}/{len(facilities_from_glossary)} placówek...')
                
                time.sleep(delay)  # Szanuj serwer

            except Exception as e:
                error_msg = f'{facility_name}: {str(e)}'
                errors.append(error_msg)
                self.stdout.write(self.style.ERROR(f'✗ {error_msg}'))
                time.sleep(delay)  # Nawet po błędzie czekaj

        # Podsumowanie
        self.stdout.write(self.style.SUCCESS(f'\n=== PODSUMOWANIE ==='))
        self.stdout.write(f'Zaktualizowano ocen: {total_updated}')
        self.stdout.write(f'Przetworzono placówek: {total_scraped + total_updated}')
        if not_found:
            self.stdout.write(
                self.style.WARNING(f'\nNie znaleziono w bazie Django ({len(not_found)}):')
            )
            for name in not_found[:10]:  # Pokaż pierwsze 10
                self.stdout.write(f'  - {name[:60]}...')
            if len(not_found) > 10:
                self.stdout.write(f'  ... i {len(not_found) - 10} więcej')
        if errors:
            self.stdout.write(self.style.WARNING(f'\nBłędy ({len(errors)}):'))
            for error in errors[:10]:  # Pokaż pierwsze 10 błędów
                self.stdout.write(f'  - {error}')
            if len(errors) > 10:
                self.stdout.write(f'  ... i {len(errors) - 10} więcej')

    def _scrape_glossary_page(self, delay=1.0):
        """Scrapuje stronę glossary i zwraca listę placówek z URL-ami"""
        base_url = 'https://hyperreal.info/help/glossary'
        facilities = []
        seen_urls = set()
        
        try:
            # Najpierw pobierz główną stronę glossary
            response = requests.get(base_url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
            })
            
            if response.status_code != 200:
                self.stdout.write(
                    self.style.ERROR(f'Błąd HTTP {response.status_code} przy pobieraniu glossary')
                )
                return []
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Szukaj wszystkich linków do placówek na głównej stronie
            facilities.extend(self._extract_facilities_from_page(soup, seen_urls))
            
            # Szukaj linków do różnych sekcji alfabetycznych
            # Format: linki z href="glossary?..." lub podobne
            glossary_links = soup.find_all('a', href=re.compile(r'glossary'))
            alphabet_urls = []
            
            for link in glossary_links:
                href = link.get('href', '')
                if 'glossary' in href and href not in ['/help/glossary', 'glossary', '#']:
                    # Buduj pełny URL
                    if href.startswith('/'):
                        full_url = f'https://hyperreal.info{href}'
                    elif href.startswith('glossary'):
                        full_url = f'https://hyperreal.info/help/{href}'
                    else:
                        full_url = href
                    
                    if full_url not in alphabet_urls and full_url.startswith('https://hyperreal.info/help/glossary'):
                        alphabet_urls.append(full_url)
            
            # Przetwórz każdą sekcję alfabetyczną
            self.stdout.write(f'Znaleziono {len(alphabet_urls)} sekcji alfabetycznych')
            
            for alphabet_url in alphabet_urls[:30]:  # Ograniczenie do 30 sekcji
                try:
                    time.sleep(delay / 2)  # Opóźnienie między sekcjami
                    
                    response = requests.get(alphabet_url, timeout=10, headers={
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
                    })
                    
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        page_facilities = self._extract_facilities_from_page(soup, seen_urls)
                        facilities.extend(page_facilities)
                except Exception:
                    continue
            
            self.stdout.write(f'Znaleziono {len(facilities)} placówek na stronie glossary')
            return facilities
            
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Błąd przy scrapowaniu glossary: {str(e)}')
            )
            import traceback
            self.stdout.write(traceback.format_exc())
            return []
    
    def _extract_facilities_from_page(self, soup, seen_urls):
        """Wyciąga listę placówek z pojedynczej strony"""
        facilities = []
        
        # Szukaj wszystkich linków do placówek
        all_links = soup.find_all('a')
        links = [link for link in all_links if 'placowka' in link.get('href', '').lower()]
        
        for link in links:
            href = link.get('href', '')
            
            if 'placowka' not in href.lower():
                continue
            
            # Wyciągnij slug z href
            slug = None
            if href.startswith('placowka/'):
                slug = href.replace('placowka/', '').split('"')[0].split("'")[0].strip()
            elif '/placowka/' in href:
                slug = href.split('/placowka/')[-1].split('"')[0].split("'")[0].strip()
            elif href.startswith('/help/placowka/'):
                slug = href.replace('/help/placowka/', '').split('"')[0].split("'")[0].strip()
            elif 'hyperreal.info/help/placowka/' in href:
                slug = href.split('hyperreal.info/help/placowka/')[-1].split('"')[0].split("'")[0].strip()
            
            if not slug:
                continue
            
            # Dekoduj URL encoding
            try:
                slug = unquote(slug)
            except:
                slug = slug.replace('%5F', '_').replace('%20', '_')
            
            slug = slug.replace(' ', '_').strip()
            
            # Pobierz nazwę placówki z tekstu linku
            name = link.get_text().strip()
            name = re.sub(r'^\s+|\s+$', '', name)
            
            # Buduj pełny URL
            full_url = f'https://hyperreal.info/help/placowka/{slug}'
            
            # Sprawdź czy nie ma duplikatu
            if name and slug and full_url not in seen_urls:
                seen_urls.add(full_url)
                facilities.append({
                    'name': name,
                    'slug': slug,
                    'url': full_url
                })
        
        return facilities

    def _find_facility_by_name(self, name):
        """Znajduje placówkę w bazie Django po nazwie (próbuje różne dopasowania)"""
        # Spróbuj dokładne dopasowanie
        try:
            return MedicalFacility.objects.get(name=name)
        except MedicalFacility.DoesNotExist:
            pass
        except MedicalFacility.MultipleObjectsReturned:
            return MedicalFacility.objects.filter(name=name).first()
        
        # Spróbuj częściowe dopasowanie (zawiera)
        facilities = MedicalFacility.objects.filter(name__icontains=name[:40])
        if facilities.count() == 1:
            return facilities.first()
        elif facilities.count() > 1:
            # Jeśli wiele, spróbuj dokładniejsze dopasowanie
            for facility in facilities:
                # Porównaj po normalizowanych nazwach (bez spacji, małe litery)
                facility_name_norm = re.sub(r'\s+', '', facility.name.lower())
                name_norm = re.sub(r'\s+', '', name.lower())
                if facility_name_norm == name_norm or facility_name_norm.startswith(name_norm[:30]):
                    return facility
            # Jeśli nie znaleziono, zwróć pierwszą
            return facilities.first()
        
        # Spróbuj wyszukiwanie po początku nazwy (dla długich nazw)
        if len(name) > 30:
            facilities = MedicalFacility.objects.filter(name__istartswith=name[:30])
            if facilities.count() == 1:
                return facilities.first()
        
        return None

    def _scrape_facility_ratings_from_url(self, url, delay=1.0):
        """Scrapuje oceny z konkretnego URL"""
        try:
            response = requests.get(url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
            })
            
            if response.status_code == 200:
                # Parsuj oceny
                ratings = self._parse_ratings_from_html(response.text)
                return ratings
            else:
                return None
                
        except requests.RequestException:
            return None
        except Exception:
            return None

    def _generate_slug_from_name(self, name):
        """Generuje slug z nazwy placówki na podstawie wzorca ze starej strony (używa podkreśleń)"""
        # Usuń znaki specjalne, zamień na małe litery
        slug = name.lower()
        # Zamień polskie znaki na odpowiedniki łacińskie
        replacements = {
            'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z'
        }
        for pl, en in replacements.items():
            slug = slug.replace(pl, en)
        # Zamień spacje i znaki specjalne na podkreślenia (stara strona używa podkreśleń)
        slug = re.sub(r'[^\w\s-]', '', slug)
        slug = re.sub(r'[-\s]+', '_', slug)
        # Usuń podwójne podkreślenia
        slug = re.sub(r'_+', '_', slug)
        slug = slug.strip('_')
        return slug

    def _generate_possible_urls(self, facility):
        """Generuje możliwe URL-e dla placówki"""
        urls = []
        
        # Stara strona używa podkreśleń w slugach, np. attente_prywatny_osrodek_terapii_uzaleznien
        # Generuj slug z nazwy (używając podkreśleń)
        generated_slug = self._generate_slug_from_name(facility.name)
        
        # Spróbuj różne warianty
        slugs_to_try = []
        
        # 1. Wygenerowany slug z nazwy
        if generated_slug:
            slugs_to_try.append(generated_slug)
        
        # 2. Slug z Django (ale zamień myślniki na podkreślenia)
        if facility.slug:
            django_slug_underscore = facility.slug.replace('-', '_')
            # Usuń końcówki typu "-swia-2"
            django_slug_underscore = re.sub(r'-\d+$', '', django_slug_underscore)
            django_slug_underscore = django_slug_underscore.replace('-', '_')
            slugs_to_try.append(django_slug_underscore)
        
        # 3. Różne warianty nazwy
        name_slug = facility.name.lower()
        # Zamień polskie znaki
        replacements = {
            'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z'
        }
        for pl, en in replacements.items():
            name_slug = name_slug.replace(pl, en)
        name_slug = re.sub(r'[^\w\s]', '', name_slug)
        name_slug = re.sub(r'[-\s]+', '_', name_slug)
        name_slug = re.sub(r'_+', '_', name_slug).strip('_')
        if name_slug:
            slugs_to_try.append(name_slug)
        
        # Usuń duplikaty i puste
        slugs_to_try = list(set([s for s in slugs_to_try if s]))
        
        base_url = 'https://hyperreal.info/help/placowka/'
        for slug in slugs_to_try:
            urls.append(base_url + slug)
        
        return list(set(urls))  # Usuń duplikaty

    def _scrape_facility_ratings(self, facility, delay=1.0):
        """Scrapuje oceny dla pojedynczej placówki"""
        urls = self._generate_possible_urls(facility)
        
        for url in urls:
            try:
                response = requests.get(url, timeout=10, headers={
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
                })
                
                if response.status_code == 200:
                    # Znaleziono stronę - parsuj
                    ratings = self._parse_ratings_from_html(response.text)
                    if ratings:
                        self.stdout.write(f'  Znaleziono stronę: {url}')
                        return ratings
                    else:
                        # Strona istnieje ale nie ma ocen
                        continue
                elif response.status_code == 404:
                    # Nie znaleziono - spróbuj następny URL
                    continue
                else:
                    # Inny błąd HTTP
                    self.stdout.write(
                        self.style.WARNING(f'  HTTP {response.status_code} dla {url}')
                    )
                    continue

            except requests.RequestException as e:
                # Błąd sieciowy - spróbuj następny URL
                continue
            except Exception as e:
                # Inny błąd
                continue
            
            time.sleep(delay / 2)  # Krótsze opóźnienie między próbami
        
        return None

    def _parse_ratings_from_html(self, html):
        """Parsuje oceny z HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        
        ratings = {}
        
        # Mapowanie kategorii na pola
        category_mapping = {
            'baza materialna': 'facilities_rating',
            'ocena kadry': 'staff_rating',
            'jakość pomocy': 'treatment_rating',
            'zasady i wymagania': 'rules_rating',
            'atmosfera': 'atmosphere_rating',
        }
        
        # Mapowanie nazw pól w klasach CSS na pola Django
        field_mapping = {
            'field-baza-materialna': 'facilities_rating',
            'field-ocena-kadry': 'staff_rating',
            'field-jakosc-pomocy': 'treatment_rating',
            'field-zasady-i-wymagania': 'rules_rating',
            'field-atmosfera': 'atmosphere_rating',
        }
        
        # Szukaj wszystkich sekcji field-name-field-*
        # BeautifulSoup może mieć problemy z wieloma klasami - użyj regex
        field_divs = soup.find_all('div', class_=re.compile(r'field-name-field'))
        
        for field_div in field_divs:
            # Pobierz klasę CSS
            classes = field_div.get('class', [])
            field_class = None
            
            for cls in classes:
                if cls.startswith('field-name-field-'):
                    field_class = cls.replace('field-name-', '')
                    break
            
            if not field_class or field_class not in field_mapping:
                continue
            
            django_field = field_mapping[field_class]
            
            # Szukaj sekcji fivestar-summary
            summary_div = field_div.find(class_=re.compile(r'fivestar-summary'))
            
            if not summary_div:
                continue
            
            # Sprawdź czy jest "Brak głosów" (empty)
            empty_span = summary_div.find('span', class_='empty')
            if empty_span:
                # Nie ma ocen dla tej kategorii
                continue
            
            # Szukaj wartości oceny - może być w różnych formatach
            value = None
            
            # Metoda 1: Szukaj bezpośrednio wartości w tekście summary_div
            text = summary_div.get_text()
            # Szukaj wzorców typu "3.5", "7", "8.2" itp.
            match = re.search(r'(\d+\.?\d*)', text)
            if match:
                val = float(match.group(1))
                if 0 <= val <= 10:
                    value = val
            
            # Metoda 2: Szukaj w atrybutach data-* lub w elementach span
            if value is None:
                # Szukaj w span-ach z wartościami
                for span in summary_div.find_all('span'):
                    text = span.get_text()
                    match = re.search(r'(\d+\.?\d*)', text)
                    if match:
                        val = float(match.group(1))
                        if 0 <= val <= 10:
                            value = val
                            break
            
            # Metoda 3: Sprawdź czy są aktywne gwiazdki w fivestar-widget
            if value is None:
                widget = field_div.find(class_=re.compile(r'fivestar-widget'))
                if widget:
                    # Policz aktywne gwiazdki (bez klasy "off")
                    active_stars = widget.find_all(class_=lambda x: x and 'star' in ' '.join(x) if x else False)
                    active_count = 0
                    for star in active_stars:
                        off_span = star.find('span', class_='off')
                        if not off_span:
                            active_count += 1
                        else:
                            # Sprawdź czy jest wartość w span
                            star_text = star.get_text()
                            match = re.search(r'(\d+)', star_text)
                            if match:
                                val = int(match.group(1))
                                if val > 0:
                                    active_count = val
                                    break
                    
                    if active_count > 0:
                        value = active_count
            
            # Konwertuj wartość na 1-5
            if value is not None:
                if value == 0:
                    rating_value = 1
                elif 0 < value <= 10:
                    # Konwertuj z skali 0-10 (fivestar) na 1-5
                    rating_value = max(1, min(5, round(value / 2)))
                else:
                    rating_value = None
                
                if rating_value is not None:
                    ratings[django_field] = rating_value
        
        return ratings if ratings else None

    def _save_ratings(self, facility, ratings, force=False):
        """Zapisuje oceny do bazy danych"""
        # Oblicz overall_rating jako średnią
        rating_values = [v for v in ratings.values() if v is not None]
        if rating_values:
            overall_rating = round(sum(rating_values) / len(rating_values))
        else:
            overall_rating = 3
        
        # Sprawdź czy już istnieje ocena
        existing = FacilityRating.objects.filter(
            facility=facility,
            user__isnull=True,
            comment=''
        ).first()
        
        if existing:
            # Zawsze aktualizuj istniejącą ocenę (nawet bez force) jeśli są nowe wartości
            updated = False
            
            # Sprawdź czy są nowe wartości do zapisania
            for field, value in ratings.items():
                current_value = getattr(existing, field)
                # Aktualizuj jeśli wartość się różni (uwzględniając None)
                if current_value != value:
                    setattr(existing, field, value)
                    updated = True
            
            # Aktualizuj overall_rating jeśli się różni
            if existing.overall_rating != overall_rating:
                existing.overall_rating = overall_rating
                updated = True
            
            # Jeśli są nowe wartości lub force, zapisz
            if updated or force:
                existing.status = 'approved'
                existing.save()
                return True
            # Jeśli nie ma zmian, ale nie ma żadnych ocen w bazie, a są na stronie - zaktualizuj
            if not any([existing.facilities_rating, existing.staff_rating, existing.treatment_rating, 
                       existing.rules_rating, existing.atmosphere_rating]) and any(ratings.values()):
                # Brak ocen w bazie, a są na stronie - zaktualizuj
                for field, value in ratings.items():
                    setattr(existing, field, value)
                existing.overall_rating = overall_rating
                existing.status = 'approved'
                existing.save()
                return True
            return False
        else:
            # Utwórz nową ocenę
            rating = FacilityRating.objects.create(
                facility=facility,
                user=None,
                comment='',
                overall_rating=overall_rating,
                staff_rating=ratings.get('staff_rating'),
                facilities_rating=ratings.get('facilities_rating'),
                treatment_rating=ratings.get('treatment_rating'),
                rules_rating=ratings.get('rules_rating'),
                atmosphere_rating=ratings.get('atmosphere_rating'),
                status='approved',
            )
            return True

