import random
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from medical_facilities.models import MedicalFacility, FacilityRating

class Command(BaseCommand):
    help = 'Dodaje oceny do istniejących placówek'

    def handle(self, *args, **options):
        self.stdout.write('Dodawanie ocen do placówek...')
        
        # Pobierz wszystkie placówki i użytkowników
        facilities = MedicalFacility.objects.all()
        
        # Utwórz użytkowników, jeśli nie istnieją
        if User.objects.count() < 10:
            for i in range(1, 11):
                username = f'user{i}'
                if not User.objects.filter(username=username).exists():
                    User.objects.create_user(username, f'{username}@example.com', 'password')
        
        users = User.objects.all()
        
        # Dodaj oceny do placówek
        ratings_count = 0
        
        for facility in facilities:
            # Losowa liczba ocen dla każdej placówki (1-5)
            for _ in range(random.randint(1, 5)):
                user = random.choice(users)
                
                # Sprawdź czy użytkownik już ocenił tę placówkę
                if FacilityRating.objects.filter(facility=facility, user=user).exists():
                    continue
                
                overall = random.randint(1, 5)
                staff = random.randint(1, 5)
                facilities_rating = random.randint(1, 5)
                treatment = random.randint(1, 5)
                
                comments = [
                    "Bardzo dobra placówka, polecam.",
                    "Profesjonalna obsługa i miła atmosfera.",
                    "Skuteczna terapia, pomogła mi wyjść z uzależnienia.",
                    "Kompetentny personel, ale warunki mogłyby być lepsze.",
                    "Długi czas oczekiwania na wizytę, ale warto.",
                    "Świetni terapeuci, bardzo pomocni.",
                    "Nowoczesne podejście do leczenia uzależnień.",
                    "Dobra lokalizacja i przystępne ceny.",
                    "Indywidualne podejście do pacjenta.",
                    "Polecam każdemu, kto zmaga się z uzależnieniem."
                ]
                
                FacilityRating.objects.create(
                    facility=facility,
                    user=user,
                    overall_rating=overall,
                    staff_rating=staff,
                    facilities_rating=facilities_rating,
                    treatment_rating=treatment,
                    comment=random.choice(comments),
                    status='approved',
                    created_at=timezone.now(),
                    updated_at=timezone.now()
                )
                
                ratings_count += 1
                
                # Limit liczby ocen, aby nie przeciążać bazy
                if ratings_count >= 1000:
                    self.stdout.write(self.style.SUCCESS(f'Dodano {ratings_count} ocen'))
                    return
        
        self.stdout.write(self.style.SUCCESS(f'Dodano {ratings_count} ocen'))