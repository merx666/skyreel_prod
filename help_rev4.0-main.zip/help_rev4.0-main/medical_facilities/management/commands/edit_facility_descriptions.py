from django.core.management.base import BaseCommand
from medical_facilities.models import MedicalFacility
import re


class Command(BaseCommand):
    help = 'Redaguje opisy placówek do najważniejszych informacji'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko pokaż co zostałoby zmienione, bez faktycznej edycji',
        )
        parser.add_argument(
            '--min-length',
            type=int,
            default=100,
            help='Minimalna długość opisu po redakcji (domyślnie: 100)',
        )
        parser.add_argument(
            '--max-length',
            type=int,
            default=500,
            help='Maksymalna długość opisu po redakcji (domyślnie: 500)',
        )

    def _extract_key_info(self, description, facility):
        """Wyciąga najważniejsze informacje z opisu, usuwa duplikaty danych"""
        if not description or len(description.strip()) < 50:
            return description
        
        # Przygotuj listę danych do usunięcia (są już w tabeli)
        data_to_remove = []
        if facility.street_address:
            data_to_remove.append(facility.street_address.lower())
        if facility.city:
            data_to_remove.append(facility.city.lower())
        if facility.postal_code:
            data_to_remove.append(facility.postal_code)
        if facility.phone:
            # Usuń wszystkie formaty telefonu
            phone_clean = re.sub(r'[\s\-\(\)]', '', facility.phone)
            data_to_remove.append(phone_clean)
            data_to_remove.append(facility.phone)
        if facility.email:
            data_to_remove.append(facility.email.lower())
        if facility.website:
            website_clean = facility.website.replace('http://', '').replace('https://', '').replace('www.', '')
            data_to_remove.append(website_clean.lower())
            data_to_remove.append(facility.website.lower())
        if facility.voivodeship:
            data_to_remove.append(facility.voivodeship.name.lower())
        
        # Podziel na linie i zdania
        text = description
        
        # Najpierw usuń całe linie z danymi kontaktowymi
        lines = text.split('\n')
        key_lines = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Pomiń linie z nagłówkami danych kontaktowych i ich wartościami
            if re.match(r'^(adres|telefon|email|www|strona|województwo|kod pocztowy|ilość miejsc|rodzaje uzależnień|długość programu|rodzaj terapii)[:\s]', line, re.IGNORECASE):
                continue
            
            # Pomiń linie które zawierają tylko dane kontaktowe
            if re.match(r'^[\d\s\+\-\(\)]+$', line) or '@' in line or 'www.' in line.lower() or 'http' in line.lower():
                continue
            
            # Pomiń linie które zawierają konkretne dane z facility
            if any(data and data in line.lower() for data in data_to_remove if len(data) > 3):
                continue
            
            # Pomiń bardzo krótkie linie (prawdopodobnie fragmenty danych)
            if len(line) < 20:
                continue
            
            # Zachowaj linie z opisem działalności
            key_lines.append(line)
        
        # Połącz linie i usuń pozostałe duplikaty
        text = ' '.join(key_lines)
        
        # Usuń powtarzające się frazy z danymi kontaktowymi z całego tekstu
        for data in data_to_remove:
            if data and len(data) > 3:
                text = re.sub(rf'\b{re.escape(data)}\b', '', text, flags=re.IGNORECASE)
        
        # Usuń pozostałe wzorce z danymi kontaktowymi
        text = re.sub(r'(adres|telefon|email|www|strona|województwo|kod pocztowy)[:\s][^.!?]*', '', text, flags=re.IGNORECASE)
        
        # Podziel ponownie na linie po czyszczeniu
        key_lines = [line.strip() for line in text.split('\n') if line.strip() and len(line.strip()) > 20]
        
        # Jeśli nie ma żadnych linii, spróbuj wyciągnąć pierwsze zdania z całego opisu
        if not key_lines:
            # Usuń wszystkie wzorce z danymi kontaktowymi z całego opisu
            cleaned = re.sub(r'(adres|telefon|email|www|strona|województwo|kod pocztowy|ilość miejsc|rodzaje uzależnień|długość programu|rodzaj terapii)[:\s][^.!?]*', '', description, flags=re.IGNORECASE)
            
            # Usuń konkretne dane kontaktowe
            for data in data_to_remove:
                if data and len(data) > 3:
                    cleaned = re.sub(rf'\b{re.escape(data)}\b', '', cleaned, flags=re.IGNORECASE)
            
            # Podziel na zdania
            sentences = re.split(r'[.!?]\s+', cleaned)
            key_lines = []
            for s in sentences:
                s = s.strip()
                # Sprawdź czy zdanie zawiera informacje o działalności
                if len(s) > 30 and not any(data in s.lower() for data in data_to_remove if data and len(data) > 3):
                    # Sprawdź czy nie jest to tylko lista danych
                    if not re.match(r'^[\d\s\+\-\(\)]+$', s) and '@' not in s and 'www.' not in s.lower():
                        key_lines.append(s)
                        if len(key_lines) >= 3:  # Maksymalnie 3 zdania
                            break
        
        # Połącz linie w czytelny tekst
        result = ' '.join(key_lines)
        
        # Usuń pozostałe fragmenty danych kontaktowych i technicznych
        result = re.sub(r'\.(pl|com|org|net|eu)\b', '', result, flags=re.IGNORECASE)
        result = re.sub(r'\b(ilość miejsc|rodzaje uzależnień|długość programu|rodzaj terapii)[:\s][^.!?]*', '', result, flags=re.IGNORECASE)
        result = re.sub(r'\b\d+\s*(miejsc|osób|pacjentów)\b', '', result, flags=re.IGNORECASE)
        result = re.sub(r'\b(program|terapia)\s+(krótko|średnio|długo)term(inowy|inowa)\b', '', result, flags=re.IGNORECASE)
        
        # Usuń pozostałe fragmenty URL-i i emaili
        result = re.sub(r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b', '', result)
        result = re.sub(r'\bhttps?://[^\s]+\b', '', result)
        result = re.sub(r'\bwww\.[^\s]+\b', '', result, flags=re.IGNORECASE)
        
        # Usuń podwójne spacje i znaki specjalne
        result = re.sub(r'\s+', ' ', result)
        result = re.sub(r'\s*[:\|]\s*', ': ', result)
        result = re.sub(r'\s*\.\s*\.', '.', result)  # Usuń podwójne kropki
        result = re.sub(r'^\s*[:\|]\s*', '', result)  # Usuń na początku
        result = result.strip()
        
        # Jeśli wynik jest głównie fragmentami danych, spróbuj jeszcze raz z całego opisu
        if len(result) < 50 or result.count(':') > 3:
            # Użyj bardziej agresywnego podejścia - wyciągnij tylko zdania z informacjami o działalności
            cleaned = re.sub(r'(adres|telefon|email|www|strona|województwo|kod pocztowy|ilość miejsc|rodzaje uzależnień|długość programu|rodzaj terapii)[:\s][^.!?]*', '', description, flags=re.IGNORECASE)
            for data in data_to_remove:
                if data and len(data) > 3:
                    cleaned = re.sub(rf'\b{re.escape(data)}\b', '', cleaned, flags=re.IGNORECASE)
            
            sentences = re.split(r'[.!?]\s+', cleaned)
            best_sentences = []
            for s in sentences:
                s = s.strip()
                if len(s) > 40:
                    # Sprawdź czy zawiera informacje o działalności
                    if any(keyword in s.lower() for keyword in [
                        'ośrodek', 'poradnia', 'terapia', 'leczenie', 'uzależnienie',
                        'pacjent', 'oferta', 'program', 'pomoc', 'rehabilitacja',
                        'profilaktyka', 'konsultacja', 'specjalizacja', 'stowarzyszenie',
                        'centrum', 'placówka', 'oddział', 'przyjmuje', 'oferuje'
                    ]):
                        # Sprawdź czy nie zawiera danych kontaktowych
                        if not any(data in s.lower() for data in data_to_remove if data and len(data) > 3):
                            if not re.match(r'^[\d\s\+\-\(\)]+$', s) and '@' not in s:
                                best_sentences.append(s)
                                if len(' '.join(best_sentences)) > self.min_length:
                                    break
            
            if best_sentences:
                result = '. '.join(best_sentences)
                result = re.sub(r'\s+', ' ', result).strip()
        
        # Skróć jeśli za długie
        if len(result) > self.max_length:
            # Znajdź ostatnią kropkę przed max_length
            truncated = result[:self.max_length]
            last_period = truncated.rfind('.')
            if last_period > self.max_length * 0.7:
                result = truncated[:last_period + 1]
            else:
                result = truncated.rstrip() + '...'
        
        # Minimalna długość - jeśli za krótki, spróbuj jeszcze raz z oryginału
        if len(result) < self.min_length and len(description) > self.min_length:
            # Usuń wszystkie wzorce z danymi kontaktowymi z całego opisu
            cleaned = re.sub(r'(adres|telefon|email|www|strona|województwo|kod pocztowy|ilość miejsc|rodzaje uzależnień|długość programu|rodzaj terapii)[:\s][^.!?]*', '', description, flags=re.IGNORECASE)
            
            # Usuń konkretne dane kontaktowe
            for data in data_to_remove:
                if data and len(data) > 3:
                    cleaned = re.sub(rf'\b{re.escape(data)}\b', '', cleaned, flags=re.IGNORECASE)
            
            # Podziel na zdania i wybierz najlepsze
            sentences = re.split(r'[.!?]\s+', cleaned)
            best_sentences = []
            for s in sentences:
                s = s.strip()
                if len(s) > 40:
                    # Sprawdź czy zdanie zawiera informacje o działalności (słowa kluczowe)
                    if any(keyword in s.lower() for keyword in [
                        'ośrodek', 'poradnia', 'terapia', 'leczenie', 'uzależnienie',
                        'pacjent', 'oferta', 'program', 'pomoc', 'rehabilitacja',
                        'profilaktyka', 'konsultacja', 'specjalizacja'
                    ]):
                        if not any(data in s.lower() for data in data_to_remove if data and len(data) > 3):
                            best_sentences.append(s)
                            if len(' '.join(best_sentences)) > self.min_length:
                                break
            
            if best_sentences:
                result = '. '.join(best_sentences)
                if len(result) > self.max_length:
                    result = result[:self.max_length].rstrip() + '...'
        
        return result.strip()

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        self.min_length = options['min_length']
        self.max_length = options['max_length']
        
        self.stdout.write(self.style.SUCCESS('📝 Redagowanie opisów placówek...\n'))
        
        facilities = MedicalFacility.objects.exclude(description='').filter(description__isnull=False)
        total = facilities.count()
        
        updated = 0
        skipped = 0
        stats = {
            'shortened': 0,
            'unchanged': 0,
            'too_short': 0,
        }
        
        for facility in facilities:
            original = facility.description
            edited = self._extract_key_info(original, facility)
            
            if len(edited) < self.min_length:
                stats['too_short'] += 1
                if stats['too_short'] <= 5:
                    self.stdout.write(
                        self.style.WARNING(
                            f'⚠ Pominięto "{facility.name[:50]}...": '
                            f'zbyt krótki opis po redakcji ({len(edited)} znaków)'
                        )
                    )
                skipped += 1
                continue
            
            if edited == original:
                stats['unchanged'] += 1
                continue
            
            if len(edited) < len(original):
                stats['shortened'] += 1
            
            if dry_run:
                self.stdout.write(
                    self.style.SUCCESS(
                        f'✓ "{facility.name[:50]}...": '
                        f'{len(original)} → {len(edited)} znaków'
                    )
                )
                if updated < 5:
                    self.stdout.write(f'  Przed: {original[:100]}...')
                    self.stdout.write(f'  Po: {edited[:100]}...')
            else:
                facility.description = edited
                facility.save(update_fields=['description'])
            
            updated += 1
        
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS('📊 PODSUMOWANIE'))
        self.stdout.write('=' * 60)
        self.stdout.write(f'Przetworzono: {total}')
        self.stdout.write(f'Zaktualizowano: {updated}')
        self.stdout.write(f'Skrócono: {stats["shortened"]}')
        self.stdout.write(f'Bez zmian: {stats["unchanged"]}')
        self.stdout.write(f'Pominięto (za krótkie): {stats["too_short"]}')
        
        if dry_run:
            self.stdout.write(self.style.WARNING('\n🔍 DRY RUN: Uruchom ponownie bez --dry-run aby faktycznie zaktualizować.'))
        else:
            self.stdout.write(self.style.SUCCESS(f'\n✅ Zaktualizowano {updated} opisów!'))

