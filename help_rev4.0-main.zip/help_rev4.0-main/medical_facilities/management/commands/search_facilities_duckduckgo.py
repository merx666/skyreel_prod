from django.core.management.base import BaseCommand
from medical_facilities.models import MedicalFacility, Voivodeship
from bs4 import BeautifulSoup
import requests
import re
import time
from urllib.parse import urlparse, quote_plus


class Command(BaseCommand):
    help = 'Wyszukuje nowe placówki używając DuckDuckGo (bez API key)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--limit',
            type=int,
            default=20,
            help='Maksymalna liczba nowych placówek do dodania',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tylko pokaż co zostałoby dodane',
        )
        parser.add_argument(
            '--cities',
            type=str,
            nargs='+',
            default=['Warszawa', 'Kraków', 'Wrocław', 'Gdańsk', 'Poznań'],
            help='Lista miast do wyszukania',
        )

    def _search_duckduckgo(self, query):
        """Wyszukuje w DuckDuckGo"""
        try:
            url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                results = []
                
                # DuckDuckGo HTML results structure
                for result in soup.find_all('a', class_='result__a'):
                    href = result.get('href', '')
                    title = result.get_text(strip=True)
                    
                    if href and title and 'google' not in href.lower() and 'duckduckgo' not in href.lower():
                        # DuckDuckGo redirects through their own URL
                        if 'uddg=' in href:
                            actual_url = href.split('uddg=')[1].split('&')[0]
                            actual_url = requests.utils.unquote(actual_url)
                        else:
                            actual_url = href
                        
                        if actual_url.startswith('http'):
                            results.append({
                                'title': title,
                                'url': actual_url
                            })
                            if len(results) >= 10:
                                break
                
                return results
        except Exception as e:
            self.stdout.write(self.style.WARNING(f'Błąd wyszukiwania DuckDuckGo: {e}'))
        
        return []

    def _extract_facility_data(self, url):
        """Wyciąga dane placówki ze strony"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)
            if response.status_code != 200:
                return None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            text = soup.get_text()
            
            # Wyciągnij tytuł
            title = soup.find('title')
            name = title.get_text(strip=True) if title else urlparse(url).netloc.replace('www.', '')
            
            data = {
                'name': name,
                'website': url,
                'phone': None,
                'email': None,
                'description': None,
                'city': None,
                'address': None,
            }
            
            # Wyciągnij telefon
            phone_patterns = [
                r'\+?\d{2,3}[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{3}',
                r'Tel[\.:]?\s*([+\d\s\-\(\)]{8,})',
                r'Telefon[\.:]?\s*([+\d\s\-\(\)]{8,})',
            ]
            for pattern in phone_patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    phone = match.group(0) if match.lastindex is None else match.group(1)
                    phone = re.sub(r'[\s\-\(\)]', '', phone)
                    if len(phone) >= 9 and len(phone) <= 15:
                        data['phone'] = phone
                        break
            
            # Wyciągnij email
            email_match = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
            if email_match:
                data['email'] = email_match.group(0)
            
            # Wyciągnij miasto z URL lub tekstu
            url_parts = urlparse(url)
            domain = url_parts.netloc.replace('www.', '')
            
            city_keywords = {
                'warszawa': 'Warszawa', 'warsaw': 'Warszawa',
                'kraków': 'Kraków', 'krakow': 'Kraków',
                'wrocław': 'Wrocław', 'wroclaw': 'Wrocław',
                'gdańsk': 'Gdańsk', 'gdansk': 'Gdańsk',
                'poznań': 'Poznań', 'poznan': 'Poznań',
                'łódź': 'Łódź', 'lodz': 'Łódź',
                'katowice': 'Katowice',
                'lublin': 'Lublin',
            }
            
            for key, city_name in city_keywords.items():
                if key in domain.lower() or key in text.lower():
                    data['city'] = city_name
                    break
            
            # Wyciągnij adres
            address_match = re.search(r'ul\.\s+[A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż\s]+(?:\d+[a-z]?)?', text)
            if address_match:
                data['address'] = address_match.group(0)
            
            # Wyciągnij opis
            paragraphs = soup.find_all(['p', 'div'])
            for p in paragraphs:
                text = p.get_text(strip=True)
                if 100 < len(text) < 800:
                    if any(keyword in text.lower() for keyword in [
                        'ośrodek', 'poradnia', 'terapia', 'leczenie', 'uzależnienie',
                        'rehabilitacja', 'detoks', 'pomoc', 'pacjent'
                    ]):
                        data['description'] = text[:600]
                        break
            
            return data
        except Exception as e:
            self.stdout.write(self.style.WARNING(f'Błąd parsowania {url}: {e}'))
            return None

    def _find_voivodeship_by_city(self, city):
        """Znajduje województwo na podstawie miasta"""
        if not city:
            return Voivodeship.objects.first()
        
        city_lower = city.lower()
        city_to_voivodeship = {
            'warszawa': 'mazowieckie',
            'kraków': 'małopolskie', 'krakow': 'małopolskie',
            'wrocław': 'dolnośląskie', 'wroclaw': 'dolnośląskie',
            'poznań': 'wielkopolskie', 'poznan': 'wielkopolskie',
            'gdańsk': 'pomorskie', 'gdansk': 'pomorskie',
            'łódź': 'łódzkie', 'lodz': 'łódzkie',
            'katowice': 'śląskie',
            'lublin': 'lubelskie',
            'białystok': 'podlaskie', 'bialystok': 'podlaskie',
            'szczecin': 'zachodniopomorskie',
            'bydgoszcz': 'kujawsko-pomorskie',
            'toruń': 'kujawsko-pomorskie', 'torun': 'kujawsko-pomorskie',
            'zielona góra': 'lubuskie', 'zielona gora': 'lubuskie',
            'opole': 'opolskie',
            'rzeszów': 'podkarpackie', 'rzeszow': 'podkarpackie',
            'kielce': 'świętokrzyskie',
            'olsztyn': 'warmińsko-mazurskie',
        }
        
        for key, voivodeship_name in city_to_voivodeship.items():
            if key in city_lower:
                try:
                    return Voivodeship.objects.get(name__icontains=voivodeship_name)
                except:
                    pass
        
        return Voivodeship.objects.first()

    def handle(self, *args, **options):
        limit = options['limit']
        dry_run = options['dry_run']
        cities = options['cities']
        
        self.stdout.write(self.style.SUCCESS('🔍 Wyszukiwanie nowych placówek (DuckDuckGo)...\n'))
        
        all_results = []
        
        # Wyszukaj dla każdego miasta
        for city in cities:
            queries = [
                f'ośrodek leczenia uzależnień {city}',
                f'poradnia terapii uzależnień {city}',
                f'centrum leczenia uzależnień {city}',
            ]
            
            for query in queries:
                self.stdout.write(f'Wyszukiwanie: {query}...')
                results = self._search_duckduckgo(query)
                all_results.extend(results)
                time.sleep(2)  # Opóźnienie między zapytaniami
        
        # Usuń duplikaty
        seen_urls = set()
        unique_results = []
        for result in all_results:
            url = result.get('url', '')
            if url and url not in seen_urls:
                seen_urls.add(url)
                unique_results.append(result)
        
        self.stdout.write(f'\nZnaleziono {len(unique_results)} unikalnych wyników\n')
        
        added = 0
        skipped = 0
        
        for result in unique_results[:limit]:
            title = result.get('title', '')
            url = result.get('url', '')
            
            # Sprawdź czy już istnieje
            if MedicalFacility.objects.filter(website=url).exists() or \
               MedicalFacility.objects.filter(name__icontains=title[:40]).exists():
                skipped += 1
                continue
            
            # Wyciągnij dane
            self.stdout.write(f'Przetwarzanie: {title[:50]}...')
            data = self._extract_facility_data(url)
            
            if not data:
                skipped += 1
                continue
            
            # Znajdź województwo
            voivodeship = self._find_voivodeship_by_city(data.get('city'))
            
            if dry_run:
                self.stdout.write(
                    self.style.SUCCESS(f'  ✓ Zostałaby dodana: {data["name"][:60]}')
                )
                self.stdout.write(f'     URL: {data["website"]}')
                self.stdout.write(f'     Miasto: {data.get("city", "Nieznane")}')
                self.stdout.write(f'     Tel: {data.get("phone", "brak")}')
                self.stdout.write(f'     Email: {data.get("email", "brak")}')
            else:
                facility = MedicalFacility(
                    name=data['name'],
                    website=data['website'],
                    phone=data.get('phone', ''),
                    email=data.get('email', ''),
                    description=data.get('description', ''),
                    city=data.get('city', 'Nieznane'),
                    street_address=data.get('address', 'Do weryfikacji'),
                    postal_code='00-000',
                    voivodeship=voivodeship,
                    status='pending',
                )
                facility.save()
                added += 1
                self.stdout.write(
                    self.style.SUCCESS(f'  ✅ Dodano: {facility.name[:60]}')
                )
            
            time.sleep(1)
        
        self.stdout.write('\n' + '=' * 60)
        self.stdout.write(self.style.SUCCESS('📊 PODSUMOWANIE'))
        self.stdout.write('=' * 60)
        if dry_run:
            self.stdout.write(f'Zostałoby dodanych: {added}')
        else:
            self.stdout.write(f'Dodano: {added}')
        self.stdout.write(f'Pominięto: {skipped}')

