"""
Django management command do importu komentarzy i opisów placówek ze starej bazy Drupal.
"""
import re
import json
from datetime import datetime
from decimal import Decimal

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction, models
from django.contrib.auth.models import User
from django.utils import timezone

from medical_facilities.models import MedicalFacility, FacilityRating


class Command(BaseCommand):
    help = 'Importuje komentarze i opisy placówek ze starej bazy Drupal (plik SQL)'

    def add_arguments(self, parser):
        parser.add_argument(
            'sql_file',
            type=str,
            help='Ścieżka do pliku SQL ze starą bazą danych'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tryb testowy - nie zapisuje zmian do bazy'
        )
        parser.add_argument(
            '--skip-descriptions',
            action='store_true',
            help='Pomiń import opisów placówek'
        )
        parser.add_argument(
            '--skip-comments',
            action='store_true',
            help='Pomiń import komentarzy'
        )
        parser.add_argument(
            '--force',
            action='store_true',
            help='Wymuś pełną migrację - usuń stare komentarze i opisy przed importem'
        )

    def handle(self, *args, **options):
        sql_file = options['sql_file']
        dry_run = options.get('dry_run', False)
        skip_descriptions = options.get('skip_descriptions', False)
        skip_comments = options.get('skip_comments', False)

        try:
            # Próbuj różne kodowania
            encodings = ['utf-8', 'latin1', 'cp1252', 'iso-8859-1']
            sql_content = None
            
            for encoding in encodings:
                try:
                    with open(sql_file, 'r', encoding=encoding, errors='replace') as f:
                        sql_content = f.read()
                        self.stdout.write(f'Plik odczytany z kodowaniem: {encoding}')
                        break
                except UnicodeDecodeError:
                    continue
            
            if sql_content is None:
                raise CommandError('Nie udało się odczytać pliku z żadnym z obsługiwanych kodowań')
        except FileNotFoundError:
            raise CommandError(f'Plik {sql_file} nie został znaleziony.')
        except Exception as e:
            raise CommandError(f'Błąd przy czytaniu pliku: {e}')

        force = options.get('force', False)
        
        if dry_run:
            self.stdout.write(self.style.WARNING('TRYB TESTOWY - żadne zmiany nie zostaną zapisane'))

        # Usuń wszystkie opinie/oceny
        if not dry_run:
            self.stdout.write(self.style.WARNING('Usuwanie wszystkich opinii i ocen...'))
            deleted_comments = FacilityRating.objects.all().delete()[0]
            self.stdout.write(f'Usunięto {deleted_comments} opinii/ocen')
            
            # Usuń starych użytkowników z nazwami typu "user1", "user9", itp. którzy nie mają komentarzy
            import re
            old_users = User.objects.filter(username__iregex=r'^user\d+$')
            deleted_users = 0
            for user in old_users:
                # Sprawdź czy użytkownik nie ma żadnych komentarzy/ocen
                if user.facility_ratings.count() == 0:
                    user.delete()
                    deleted_users += 1
            if deleted_users > 0:
                self.stdout.write(f'Usunięto {deleted_users} starych użytkowników (user1-user10 bez komentarzy)')

        # Parsuj dane z SQL
        self.stdout.write('Parsowanie danych z pliku SQL...')
        
        # Pobierz węzły (node) - mapowanie nid -> title
        nodes = self._parse_nodes(sql_content)
        self.stdout.write(f'Znaleziono {len(nodes)} węzłów w bazie')
        
        # Pobierz komentarze
        if not skip_comments:
            comments = self._parse_comments(sql_content)
            comment_bodies = self._parse_comment_bodies(sql_content)
            self.stdout.write(f'Znaleziono {len(comments)} komentarzy')
        else:
            comments = {}
            comment_bodies = {}
        
        # Pobierz opisy placówek
        if not skip_descriptions:
            descriptions = self._parse_descriptions(sql_content)
            self.stdout.write(f'Znaleziono {len(descriptions)} opisów placówek')
        else:
            descriptions = {}

        # Importuj opisy placówek
        if not skip_descriptions:
            imported_descriptions = self._import_descriptions(
                nodes, descriptions, dry_run, force
            )
            self.stdout.write(
                self.style.SUCCESS(
                    f'Zaktualizowano {imported_descriptions} opisów placówek'
                )
            )

        # Importuj komentarze jako oceny
        if not skip_comments:
            imported_comments = self._import_comments(
                nodes, comments, comment_bodies, dry_run, force, sql_content
            )
            self.stdout.write(
                self.style.SUCCESS(
                    f'Zaimportowano {imported_comments} komentarzy jako oceny'
                )
            )

        # Importuj agregowane oceny placówek (baza materialna, kadra, jakość pomocy)
        imported_ratings = self._import_facility_ratings(sql_content, nodes, dry_run, force)
        self.stdout.write(
            self.style.SUCCESS(
                f'Zaimportowano {imported_ratings} agregowanych ocen placówek'
            )
        )

        self.stdout.write(self.style.SUCCESS('\n=== PODSUMOWANIE IMPORTU ==='))
        self.stdout.write(
            self.style.SUCCESS(
                f'✓ Zaimportowano {imported_descriptions} opisów placówek'
            )
        )
        if not skip_comments:
            self.stdout.write(
                self.style.SUCCESS(
                    f'✓ Zaimportowano {imported_comments} komentarzy użytkowników'
                )
            )
        self.stdout.write(
            self.style.SUCCESS(
                f'✓ Zaimportowano {imported_ratings} agregowanych ocen placówek'
            )
        )
        self.stdout.write(self.style.SUCCESS('\nImport zakończony pomyślnie!'))
        
        # Wyczyść cache statystyk po imporcie
        if not dry_run:
            from django.core.cache import cache
            cache.delete('home_stats')
            self.stdout.write('Cache statystyk wyczyszczony')

    def _parse_nodes(self, sql_content):
        """Parsuje węzły (node) z SQL i zwraca dict {nid: title}"""
        nodes = {}
        # Pattern dla INSERT INTO node - szukamy nid i title
        # Format: (nid, vid, type, language, title, uid, status, created, changed, comment, promote, sticky, tnid, translate)
        # Szukamy tylko węzłów typu 'osrodek'
        pattern = r"\((\d+),\d+,'osrodek','[^']*','([^']*)'[^)]*\)"
        
        for match in re.finditer(pattern, sql_content, re.MULTILINE | re.DOTALL):
            try:
                nid = int(match.group(1))
                title = match.group(2).strip()
                # Oczyszczanie tytułu z escape'ów SQL
                title = title.replace("\\'", "'").replace("\\\"", "\"").replace("\\\\", "\\")
                if title:
                    nodes[nid] = title
            except (ValueError, IndexError):
                continue
        
        return nodes

    def _parse_comments(self, sql_content):
        """Parsuje komentarze z tabeli comment"""
        comments = {}
        # Pattern dla INSERT INTO comment - może być wiele wartości w jednym INSERT
        # Format: (cid, pid, nid, uid, subject, hostname, created, changed, status, thread, name, mail, homepage, language)
        # Szukamy WSZYSTKICH bloków INSERT INTO `comment` VALUES (może być wiele bloków)
        pattern = r"INSERT INTO `comment` VALUES\s+"
        
        # Znajdź WSZYSTKIE bloki INSERT
        insert_matches = list(re.finditer(pattern, sql_content, re.MULTILINE | re.IGNORECASE))
        if not insert_matches:
            return comments
        
        self.stdout.write(f'Znaleziono {len(insert_matches)} blok(ów) INSERT INTO comment')
        
        # Przetwórz każdy blok osobno
        for insert_idx, insert_match in enumerate(insert_matches):
            start_pos = insert_match.end()
            
            # Znajdź koniec bloku - szukaj do ; lub następnego INSERT INTO comment
            end_pos = sql_content.find(';', start_pos)
            next_insert = sql_content.find('INSERT INTO `comment`', start_pos, len(sql_content))
            if next_insert != -1 and (end_pos == -1 or next_insert < end_pos):
                end_pos = next_insert
            
            if end_pos == -1:
                # Jeśli nie znaleziono, użyj końca pliku
                end_pos = len(sql_content)
            
            values_block = sql_content[start_pos:end_pos]
            
            # Parsuj poszczególne rekordy (każdy zaczyna się od ( i kończy na ),
            # Użyj bardziej elastycznego wzorca - wartości mogą zawierać escape'owane apostrofy
            row_pattern = r"\((\d+),(\d+),(\d+),(\d+),'([^']*(?:\\'[^']*)*)','([^']*(?:\\'[^']*)*)',(\d+),(\d+),(\d+),'([^']*(?:\\'[^']*)*)','([^']*(?:\\'[^']*)*)','([^']*(?:\\'[^']*)*)','([^']*(?:\\'[^']*)*)','([^']*(?:\\'[^']*)*)'\)"
            
            block_comments = 0
            for match in re.finditer(row_pattern, values_block, re.MULTILINE):
                try:
                    cid = int(match.group(1))
                    pid = int(match.group(2))
                    nid = int(match.group(3))
                    uid = int(match.group(4))
                    subject = match.group(5).strip()
                    hostname = match.group(6)
                    created = int(match.group(7))
                    changed = int(match.group(8))
                    status = int(match.group(9))  # 0 = nieopublikowany, 1 = opublikowany
                    thread = match.group(10)
                    name = match.group(11).strip() if match.group(11) and match.group(11) != 'NULL' else None
                    mail = match.group(12).strip() if match.group(12) and match.group(12) != 'NULL' else None
                    homepage = match.group(13).strip() if match.group(13) and match.group(13) != 'NULL' else None
                    language = match.group(14)
                    
                    # Oczyszczanie escape'ów SQL
                    if subject:
                        subject = subject.replace("\\'", "'").replace("\\\"", "\"")
                    if name:
                        name = name.replace("\\'", "'").replace("\\\"", "\"")
                    
                    # Tylko opublikowane komentarze (status=1 lub 0 w tym przypadku), główne komentarze (pid=0)
                    # W danych widzę status=0 ale są to opublikowane komentarze
                    # Importujemy wszystkie komentarze (status=0 lub 1), bo status=0 oznacza opublikowane
                    # Importujemy WSZYSTKIE główne komentarze, nie tylko CID 1-215
                    if pid == 0:  # Główne komentarze, nie odpowiedzi
                        comments[cid] = {
                            'cid': cid,
                            'nid': nid,
                            'uid': uid if uid > 0 else None,
                            'name': name,  # To jest nazwa użytkownika z pola 'name' w tabeli comment
                            'subject': subject,
                            'created': created,
                            'changed': changed,
                            'hostname': hostname,
                            'mail': mail,
                            'status': status,  # Zapisz status dla informacji
                        }
                        block_comments += 1
                except (ValueError, IndexError) as e:
                    continue
            
            if block_comments > 0:
                self.stdout.write(f'  Blok {insert_idx + 1}: znaleziono {block_comments} głównych komentarzy')
        
        return comments

    def _parse_comment_bodies(self, sql_content):
        """Parsuje treść komentarzy z tabeli field_data_comment_body i field_revision_comment_body"""
        comment_bodies = {}
        
        # Parsuj z field_data_comment_body
        pattern = r"INSERT INTO `field_data_comment_body` VALUES\s+"
        insert_match = re.search(pattern, sql_content, re.MULTILINE | re.IGNORECASE)
        
        if insert_match:
            start_pos = insert_match.end()
            end_pos = sql_content.find(';', start_pos)
            if end_pos == -1:
                end_pos = sql_content.find('/*!40000', start_pos)
            if end_pos == -1:
                end_pos = len(sql_content)
            
            values_block = sql_content[start_pos:end_pos]
            
            # Format: ('comment', 'comment_node_osrodek', 0, entity_id, revision_id, 'und', 0, 'value', 'format')
            row_pattern = r"\('comment','comment_node_osrodek',0,(\d+),(\d+),'([^']*)',(\d+),'([^']*)','([^']*)'\)"
            
            for match in re.finditer(row_pattern, values_block, re.MULTILINE | re.DOTALL):
                try:
                    entity_id = int(match.group(1))  # To jest cid (comment ID)
                    revision_id = int(match.group(2))
                    language = match.group(3)
                    delta = int(match.group(4))
                    value = match.group(5).strip() if match.group(5) else ''
                    format_type = match.group(6) if match.group(6) else ''
                    
                    # Oczyszczanie wartości (usunięcie escape'ów SQL)
                    if value:
                        value = value.replace("\\'", "'").replace("\\n", "\n").replace("\\r", "\r").replace("\\\\", "\\")
                        
                    if value:
                        # Jeśli już jest wartość, użyj dłuższą
                        if entity_id not in comment_bodies or len(value) > len(comment_bodies[entity_id]):
                            comment_bodies[entity_id] = value
                except (ValueError, IndexError):
                    continue
        
        # Parsuj również z field_revision_comment_body (revisions)
        pattern_revision = r"INSERT INTO `field_revision_comment_body` VALUES\s+"
        insert_match_revision = re.search(pattern_revision, sql_content, re.MULTILINE | re.IGNORECASE)
        
        if insert_match_revision:
            start_pos = insert_match_revision.end()
            end_pos = sql_content.find(';', start_pos)
            if end_pos == -1:
                end_pos = sql_content.find('/*!40000', start_pos)
            if end_pos == -1:
                end_pos = len(sql_content)
            
            values_block = sql_content[start_pos:end_pos]
            
            # Format: ('comment', 'comment_node_osrodek', 0, entity_id, revision_id, 'und', 0, 'value', 'format')
            row_pattern = r"\('comment','comment_node_osrodek',0,(\d+),(\d+),'([^']*)',(\d+),'([^']*)','([^']*)'\)"
            
            for match in re.finditer(row_pattern, values_block, re.MULTILINE | re.DOTALL):
                try:
                    entity_id = int(match.group(1))  # To jest cid (comment ID)
                    revision_id = int(match.group(2))
                    language = match.group(3)
                    delta = int(match.group(4))
                    value = match.group(5).strip() if match.group(5) else ''
                    format_type = match.group(6) if match.group(6) else ''
                    
                    # Oczyszczanie wartości (usunięcie escape'ów SQL)
                    if value:
                        value = value.replace("\\'", "'").replace("\\n", "\n").replace("\\r", "\r").replace("\\\\", "\\")
                        
                    if value:
                        # Jeśli już jest wartość, użyj dłuższą (revisions mogą mieć nowsze wersje)
                        if entity_id not in comment_bodies or len(value) > len(comment_bodies[entity_id]):
                            comment_bodies[entity_id] = value
                except (ValueError, IndexError):
                    continue
        
        return comment_bodies

    def _parse_descriptions(self, sql_content):
        """Parsuje opisy placówek z tabeli field_data_field_opis_placowki"""
        descriptions = {}
        # Pattern dla INSERT INTO field_data_field_opis_placowki - może być wiele wartości
        pattern = r"INSERT INTO `field_data_field_opis_placowki` VALUES\s+"
        
        insert_match = re.search(pattern, sql_content, re.MULTILINE | re.IGNORECASE)
        if not insert_match:
            self.stdout.write(self.style.WARNING('Nie znaleziono bloku INSERT INTO field_data_field_opis_placowki'))
            return descriptions
        
        self.stdout.write('Znaleziono blok INSERT INTO field_data_field_opis_placowki')
        
        start_pos = insert_match.end()
        # Znajdź koniec bloku INSERT - szukamy wzorca po końcu bloku VALUES
        # Format: ...); /*!40000 ALTER TABLE ... ENABLE KEYS */;
        # Albo: ...); UNLOCK TABLES;
        # Najpierw szukaj */ /*!40000 - to oznacza koniec VALUES
        end_marker1 = sql_content.find('/*!40000 ALTER TABLE', start_pos)
        if end_marker1 == -1:
            end_marker1 = sql_content.find('UNLOCK TABLES', start_pos)
        
        if end_marker1 == -1:
            # Jeśli nie znaleziono, szukaj pierwszego ');' po VALUES (ale to może być w wartości)
            # Lepsze: szukaj końca ostatniego rekordu - szukaj wzorca ),\n(' lub );\n
            # Ale najprościej: szukaj pierwszego ');' po VALUES
            end_pos = sql_content.find(');', start_pos)
            if end_pos != -1:
                # Sprawdź czy następny znak to ; lub nowa linia
                next_chars = sql_content[end_pos+2:end_pos+10].strip()
                if next_chars.startswith(';') or next_chars.startswith('/*!') or next_chars.startswith('UNLOCK'):
                    end_pos = end_pos + 2
                else:
                    # To nie jest koniec bloku, szukaj dalej
                    end_pos = sql_content.find('\n/*!40000', start_pos)
        else:
            # Znajdź początek komentarza /*!40000
            # Cofnij się do poprzedniego ');'
            end_pos = sql_content.rfind(');', start_pos, end_marker1)
            if end_pos != -1:
                end_pos = end_pos + 2
            else:
                end_pos = end_marker1
        
        if end_pos == -1:
            self.stdout.write(self.style.WARNING('Nie znaleziono końca bloku INSERT'))
            return descriptions
        
        values_block = sql_content[start_pos:end_pos]
        self.stdout.write(f'Blok VALUES ma {len(values_block)} znaków, pierwsze 200: {values_block[:200]}')
        
        # Format: ('node', 'osrodek', 0, entity_id, revision_id, 'und', 0, 'value', 'summary', 'format')
        # Wartości mogą zawierać długie teksty z escape'ami - musimy parsować bardziej elastycznie
        # Używamy prostszego podejścia - szukamy każdego rekordu osobno
        
        # Znajdź wszystkie wystąpienia ('node','osrodek',0,
        # W bloku VALUES każdy rekord jest w osobnej linii (lub może być w jednej linii)
        # Szukamy wszystkich rekordów w bloku - każdy zaczyna się od '('
        # Format każdego rekordu: ('node','osrodek',0,entity_id,revision_id,'und',delta,'value','summary','format')
        start_pattern = r"\('node','osrodek',0,"
        positions = []
        for match in re.finditer(start_pattern, values_block):
            positions.append(match.start())
        
        self.stdout.write(f'Znaleziono {len(positions)} rekordów w bloku opisów (rozmiar bloku: {len(values_block)} znaków)')
        
        for start_pos_rel in positions:
            # Znajdź początek tego rekordu w całym bloku
            record_start = start_pos_rel
            # Szukamy zamykającego nawiasu - musimy znaleźć matching )
            # Ale wartości mogą zawierać ')' w treści, więc musimy liczyć
            depth = 0
            record_end = record_start
            in_string = False
            escape_next = False
            
            for i, char in enumerate(values_block[record_start:], start=record_start):
                if escape_next:
                    escape_next = False
                    continue
                if char == '\\':
                    escape_next = True
                    continue
                if char == "'" and not escape_next:
                    in_string = not in_string
                    continue
                if not in_string:
                    if char == '(':
                        depth += 1
                    elif char == ')':
                        depth -= 1
                        if depth == 0:
                            record_end = i + 1
                            break
            
            record = values_block[record_start:record_end]
            
            # Debug: sprawdź długość rekordu
#                self.stdout.write(f'DEBUG: Parsuję rekord, długość: {len(record)}, pierwsze 300 znaków: {record[:300]}')
            
            # Parsuj ten konkretny rekord - musimy użyć innego podejścia dla wieloliniowych wartości
            # Format: ('node','osrodek',0,ID,REV,'und',0,'VALUE','SUMMARY','FORMAT')
            # Parsuj krok po kroku
            try:
                # Znajdź entity_id - 4. wartość po 'osrodek',0,
                id_match = re.search(r"\('node','osrodek',0,(\d+),", record)
                if not id_match:
                    self.stdout.write(self.style.WARNING('DEBUG: Nie znaleziono entity_id w rekordzie'))
                    continue
                entity_id = int(id_match.group(1))
#                self.stdout.write(f'DEBUG: Znaleziono entity_id: {entity_id}')
                
                # Znajdź wartość - to 8. wartość w apostrofach (po 'und', delta)
                # Format: ...'und',0,'VALUE','SUMMARY','FORMAT')
                # Używamy prostszego podejścia - znajdź wartość bezpośrednio w rekordzie
                # Pattern: znajdź 'und',delta,'VALUE','SUMMARY','FORMAT')
                # Problem: wartość może zawierać escape'owane apostrofy jak \' więc musimy je obsłużyć
                
                # Najprostsze podejście: znajdź wszystkie wartości między apostrofami od 'und' do końca rekordu
                # Format: ...'und',DELTA,'VALUE','SUMMARY','FORMAT')
                # Znajdź pozycję 'und',DELTA,'
                und_match = re.search(r"'und',(\d+),'", record)
                if not und_match:
                    continue
                
                delta = int(und_match.group(1))
                # und_match.end() zwraca pozycję po wzorcu 'und',delta,'
                # Wzorzec kończy się na apostrofie, więc und_end jest po apostrofie
                und_end = und_match.end()
                
                # Wzorzec 'und',delta,' kończy się na apostrofie
                # und_match.end() zwraca pozycję PO wzorcu, czyli po apostrofie wzorca
                # W danych widzę: 'und',0,'Przyjmowani... 
                # Wzorzec to: 'und',0,' - kończy się na apostrofie wartości
                # und_end jest po tym apostrofie, więc und_end wskazuje na początek wartości
                
                # Ale wartość zaczyna się od apostrofu, więc und_end powinien wskazywać na apostrof wartości
                # Sprawdź czy und_end wskazuje na apostrof wartości
                if und_end >= len(record):
                    continue
                
                # Wzorzec kończy się na ', więc und_end jest po apostrofie wartości
                # Ale wartość zaczyna się od apostrofu, więc musimy sprawdzić czy und_end wskazuje na apostrof wartości
                # W danych: 'und',0,'Przyjmowani...
                # und_match.group(0) to 'und',0,'
                # und_end jest po apostrofie, więc następny znak to wartość (np. 'P')
                
                # Problem: wzorzec kończy się na apostrofie, ale ten apostrof to początek wartości
                # und_end wskazuje już po apostrofie wartości, więc start_pos = und_end - 1
                # Ale lepiej: sprawdź czy następny znak to apostrof wartości
                # Jeśli tak, to und_end jest po apostrofie wartości, więc start_pos = und_end - 1
                # Ale widzę że następny znak to wartość, nie apostrof
                
                # W rzeczywistości: wzorzec 'und',0,' kończy się na apostrofie, który jest początkiem wartości
                # und_end jest po apostrofie, więc start_pos powinien być und_end - 1
                # Ale najbezpieczniej: znajdź apostrof wartości bezpośrednio przed wartością
                
                # Sprawdź czy und_end - 1 to apostrof wartości
                if und_end > 0 and und_end <= len(record):
                    # Sprawdź znak przed und_end - powinien być apostrof wartości
                    if record[und_end - 1] == "'":
                        # Znak przed und_end to apostrof wartości
                        start_pos = und_end - 1
                    elif und_end < len(record) and record[und_end] == "'":
                        # Następny znak to apostrof - może to jest początek wartości
                        start_pos = und_end
                    else:
                        # Znajdź pierwszy apostrof przed lub po und_end
                        # Najpierw spróbuj znaleźć apostrof przed und_end (wcześniej w rekordzie)
                        start_pos = record.rfind("'", 0, und_end)
                        if start_pos == -1 or start_pos < und_match.start():
                            # Nie znaleziono, spróbuj po und_end
                            start_pos = record.find("'", und_end)
                            if start_pos == -1:
                                continue
                else:
                    continue
                
                # Parsuj ręcznie - znajdź wartość między apostrofami
                # start_pos wskazuje na apostrof wartości
                # Znajdź zamykający apostrof (nie escape'owany)
                # Musimy obsłużyć escape'owane apostrofy jak \'
                value_parts = []
                i = start_pos + 1  # Pomiń pierwszy apostrof wartości
                escape_next = False
                
                while i < len(record):
                    char = record[i]
                    if escape_next:
                        # Poprzedni znak był escape, więc ten znak jest escape'owany
                        value_parts.append(char)
                        escape_next = False
                    elif char == '\\':
                        # Następny znak będzie escape'owany
                        escape_next = True
                        value_parts.append(char)  # Zapisz escape
                    elif char == "'" and not escape_next:
                        # Znaleziono zamykający apostrof wartości (nie escape'owany)
                        break
                    else:
                        value_parts.append(char)
                    i += 1
                
                value_str = ''.join(value_parts)
                
                # Oczyszczanie escape'ów - najpierw double escape, potem single escape
                # W SQL escape'y są podwojone: \\r\\n więc musimy je obsłużyć
                value_str = value_str.replace("\\\\", "\\")  # Najpierw double escape
                value_str = value_str.replace("\\'", "'").replace("\\n", "\n").replace("\\r", "\r")
                
                # Summary i format nie są potrzebne - ignorujemy je
                value = value_str
                summary = ''
                format_type = ''
                
                # Oczyszczanie wartości (usunięcie escape'ów SQL)
                if value:
                    value = value.replace("\\'", "'").replace("\\n", "\n").replace("\\r", "\r").replace("\\\\", "\\")
                
                if value and len(value) > 10:  # Tylko wartości dłuższe niż 10 znaków
                    descriptions[entity_id] = value
                    self.stdout.write(f'  Znaleziono opis dla entity_id {entity_id}, długość: {len(value)}')
            except (ValueError, IndexError, AttributeError) as e:
                self.stdout.write(self.style.WARNING(f'Błąd parsowania opisu dla entity_id {entity_id}: {e}'))
                continue
        
        return descriptions

    def _extract_quoted_string(self, text):
        """Wyciąga pierwszą wartość w apostrofach z obsługą escape'ów"""
        if not text:
            return ''
        
        # Jeśli nie zaczyna się od ', znajdź pierwszy '
        if not text.startswith("'"):
            # Znajdź pierwszy apostrof
            quote_pos = text.find("'")
            if quote_pos == -1:
                return ''
            text = text[quote_pos:]
        
        result = []
        i = 1  # Pomiń pierwszy apostrof
        escape_next = False
        
        while i < len(text):
            char = text[i]
            if escape_next:
                result.append(char)
                escape_next = False
            elif char == '\\':
                escape_next = True
                result.append(char)
            elif char == "'":
                # Koniec wartości
                break
            else:
                result.append(char)
            i += 1
        
        return ''.join(result)

    def _import_descriptions(self, nodes, descriptions, dry_run, force=False):
        """Importuje opisy placówek do istniejących placówek Django"""
        imported = 0
        
        for nid, description in descriptions.items():
            if nid not in nodes:
                continue
            
            node_title = nodes[nid]
            
            # Znajdź placówkę po nazwie
            try:
                facility = MedicalFacility.objects.get(name=node_title)
            except MedicalFacility.DoesNotExist:
                # Spróbuj znaleźć częściowe dopasowanie
                facilities = MedicalFacility.objects.filter(name__icontains=node_title[:30])
                if facilities.count() == 1:
                    facility = facilities.first()
                elif facilities.count() > 1:
                    # Jeśli wiele, użyj pierwszego najlepszego dopasowania
                    facility = facilities.first()
                    self.stdout.write(
                        self.style.WARNING(
                            f'Wielu placówek dla węzła {nid} ({node_title}), używam pierwszej: {facility.name}'
                        )
                    )
                else:
                    # Nie znaleziono placówki - utwórz nową z opisem
                    if not dry_run:
                        from medical_facilities.models import Voivodeship
                        from django.utils.text import slugify
                        
                        # Znajdź lub utwórz domyślne województwo
                        default_voivodeship, _ = Voivodeship.objects.get_or_create(
                            name='Nieznane',
                            defaults={'slug': slugify('Nieznane')}
                        )
                        
                        # Utwórz nową placówkę z minimalnymi danymi
                        facility = MedicalFacility(
                            name=node_title,
                            street_address='Do uzupełnienia',
                            city='Do uzupełnienia',
                            postal_code='00-000',
                            voivodeship=default_voivodeship,
                            status='pending',
                            description=description  # Ustaw opis od razu
                        )
                        facility.save()
                        imported += 1
                        self.stdout.write(
                            self.style.SUCCESS(
                                f'Utworzono nową placówkę z opisem: {node_title[:50]}... (nid: {nid})'
                            )
                        )
                    else:
                        self.stdout.write(
                            self.style.WARNING(
                                f'[DRY-RUN] Utworzyłbym nową placówkę dla węzła {nid} ({node_title[:50]}...)'
                            )
                        )
                        imported += 1
                    continue
            except MedicalFacility.MultipleObjectsReturned:
                # Jeśli wiele placówek, użyj pierwszej
                facility = MedicalFacility.objects.filter(name=node_title).first()
                self.stdout.write(
                    self.style.WARNING(
                        f'Wielu placówek dla węzła {nid} ({node_title}), używam pierwszej'
                    )
                )
            
            # Zaktualizuj opis - zawsze aktualizuj jeśli nowy jest dłuższy lub obecny jest pusty
            current_desc = facility.description or ''
            should_update = not current_desc or len(description) > len(current_desc)
            
            if should_update:
                if not dry_run:
                    facility.description = description
                    facility.save(update_fields=['description'])
                    imported += 1
                    self.stdout.write(f'  Zaktualizowano opis: {facility.name[:50]}... (długość: {len(description)})')
                else:
                    imported += 1
        
        return imported

    def _import_comments(self, nodes, comments, comment_bodies, dry_run, force=False, sql_content=None):
        """Importuje komentarze jako FacilityRating"""
        imported = 0
        skipped = 0
        if sql_content is None:
            sql_content = ''
        
        for cid, comment_data in comments.items():
            nid = comment_data['nid']
            
            # Znajdź node_title - może być z nodes lub spróbuj znaleźć po nid
            node_title = nodes.get(nid)
            if not node_title:
                # Jeśli nie ma w nodes, może to być węzeł innego typu niż 'osrodek'
                # Spróbuj znaleźć po nid w całym SQL
                if sql_content:
                    node_pattern = rf"\({nid},\d+,'[^']*','[^']*','([^']*)'"
                    node_match = re.search(node_pattern, sql_content)
                if node_match:
                    node_title = node_match.group(1).replace("\\'", "'").replace("\\\"", "\"").strip()
                else:
                    self.stdout.write(
                        self.style.WARNING(
                            f'Komentarz {cid} (nid: {nid}) - nie znaleziono węzła w bazie'
                        )
                    )
                    skipped += 1
                    continue
            
            # Znajdź placówkę - szukaj szerzej
            facility = None
            try:
                facility = MedicalFacility.objects.get(name=node_title)
            except MedicalFacility.DoesNotExist:
                # Spróbuj różne warianty nazwy
                facilities = MedicalFacility.objects.filter(name__icontains=node_title[:50])
                if facilities.count() >= 1:
                    facility = facilities.first()
                    if facilities.count() > 1:
                        self.stdout.write(
                            self.style.WARNING(
                                f'Wielu placówek dla komentarza {cid} (nid: {nid}, {node_title[:50]}), używam pierwszej: {facility.name[:50]}'
                            )
                        )
                else:
                    # Spróbuj bez ostatnich znaków (może być problem z kodowaniem)
                    facilities = MedicalFacility.objects.filter(name__icontains=node_title[:40])
                    if facilities.count() >= 1:
                        facility = facilities.first()
                    else:
                        self.stdout.write(
                            self.style.WARNING(
                                f'Komentarz {cid} (nid: {nid}) - nie znaleziono placówki: {node_title[:50]}'
                            )
                        )
                        skipped += 1
                        continue
            except MedicalFacility.MultipleObjectsReturned:
                facility = MedicalFacility.objects.filter(name=node_title).first()
                self.stdout.write(
                    self.style.WARNING(
                        f'Wielu placówek dla komentarza {cid} (nid: {nid}), używam pierwszej'
                    )
                )
            
            # Pobierz treść komentarza - użyj subject jeśli nie ma treści w comment_body
            comment_text = comment_bodies.get(cid)
            if not comment_text:
                # Jeśli nie ma treści w comment_body, użyj subject
                comment_text = comment_data.get('subject', '')
            
            # Jeśli nadal nie ma treści, użyj "Komentarz" jako domyślna treść
            if not comment_text or not comment_text.strip():
                comment_text = comment_data.get('subject', 'Komentarz')
                if not comment_text or not comment_text.strip():
                    self.stdout.write(
                        self.style.WARNING(
                            f'Komentarz {cid} (nid: {nid}) - brak treści, pomijam'
                        )
                    )
                    skipped += 1
                    continue
            
            # Znajdź lub utwórz użytkownika z nazwą z pola 'name'
            user = None
            username = comment_data.get('name')
            
            if username and username.strip():
                # Spróbuj znaleźć istniejącego użytkownika po username
                try:
                    user = User.objects.get(username=username)
                except User.DoesNotExist:
                    # Spróbuj znaleźć po imieniu/nazwisku lub nazwie
                    user = User.objects.filter(
                        models.Q(username=username) |
                        models.Q(first_name=username) |
                        models.Q(last_name=username)
                    ).first()
                    
                    if not user:
                        # Utwórz nowego użytkownika z nazwą z komentarza
                        # Użyj nazwy jako username (musi być unikalne)
                        base_username = username.strip().lower().replace(' ', '_')
                        username_final = base_username
                        counter = 1
                        
                        # Upewnij się że username jest unikalne
                        while User.objects.filter(username=username_final).exists():
                            username_final = f"{base_username}_{counter}"
                            counter += 1
                        
                        if not dry_run:
                            user = User.objects.create_user(
                                username=username_final,
                                email=f'{username_final}@imported.local',
                                first_name=username,
                                is_active=True
                            )
                            self.stdout.write(f'  Utworzono użytkownika: {username_final} (z nazwy: {username})')
            
            # Konwertuj timestamp na datetime
            try:
                created_dt = datetime.fromtimestamp(comment_data['created'], tz=timezone.get_current_timezone())
            except (ValueError, OSError):
                created_dt = timezone.now()
            
            # Określ ocenę na podstawie treści komentarza (heurystyka)
            # Domyślnie 5 gwiazdek jeśli komentarz jest pozytywny
            overall_rating = self._extract_rating_from_comment(comment_text, comment_data.get('subject', ''))
            
            # Sprawdź czy taki komentarz już istnieje (po treści i placówce) - tylko jeśli nie --force
            if not dry_run and not force:
                existing = FacilityRating.objects.filter(
                    facility=facility,
                    comment__startswith=comment_text[:200]  # Porównaj pierwsze 200 znaków
                ).exists()
                
                if existing:
                    skipped += 1
                    continue
            
            if not dry_run:
                # Utwórz ocenę
                rating = FacilityRating(
                    facility=facility,
                    user=user,
                    overall_rating=overall_rating,
                    comment=comment_text,
                    status='approved',  # Komentarze z bazy są już opublikowane
                    created_at=created_dt,
                    approved_at=created_dt,
                )
                rating.save()
                imported += 1
                self.stdout.write(
                    f'  Zaimportowano komentarz od {username or "anonim"} dla {facility.name[:40]}...'
                )
            else:
                imported += 1
                self.stdout.write(
                    f'  [DRY-RUN] Zaimportowałbym komentarz od {username or "anonim"} dla {facility.name[:40]}...'
                )
        
        if skipped > 0:
            self.stdout.write(
                self.style.WARNING(f'Pominięto {skipped} komentarzy (duplikaty lub brak treści)')
            )
        
        return imported

    def _extract_rating_from_comment(self, comment_text, subject):
        """Próbuje wyciągnąć ocenę z komentarza (heurystyka)"""
        text_lower = (comment_text + ' ' + subject).lower()
        
        # Sprawdź czy jest wyraźna ocena (np. "9/10", "5/5")
        rating_pattern = r'(\d+)\s*[/-]\s*(\d+|10|5)'
        match = re.search(rating_pattern, text_lower)
        if match:
            num = float(match.group(1))
            den = float(match.group(2))
            if den > 0:
                rating = int((num / den) * 5)
                return max(1, min(5, rating))  # Ogranicz do 1-5
        
        # Sprawdź pozytywne słowa kluczowe
        positive_words = ['polecam', 'genialny', 'świetny', 'doskonały', 'bardzo dobry', 'super', 'spoko', 'ok']
        negative_words = ['nie polecam', 'zły', 'słaby', 'beznadziejny', 'cpunstwo', 'shame']
        
        if any(word in text_lower for word in negative_words):
            return 2  # Niska ocena dla negatywnych komentarzy
        
        if any(word in text_lower for word in positive_words):
            return 5  # Wysoka ocena dla pozytywnych komentarzy
        
        # Domyślnie 4 gwiazdki dla neutralnych komentarzy
        return 4

    def _convert_fivestar_to_rating(self, fivestar_value):
        """Konwertuje wartość fivestar (0-100) na ocenę 1-5"""
        if fivestar_value == 0:
            return 1
        # fivestar: 0=0, 10=1, 20=2, ..., 100=10 gwiazdek
        # Konwertuj na 1-5: dziel przez 20 i zaokrąglij w górę
        rating = max(1, min(5, round(fivestar_value / 20)))
        return rating

    def _parse_facility_ratings(self, sql_content):
        """Parsuje agregowane oceny placówek z pól fivestar"""
        ratings = {}  # {nid: {facilities_rating, staff_rating, treatment_rating}}
        
        # Mapowanie pól Drupal na pola FacilityRating
        field_mapping = {
            'baza_materialna': 'facilities_rating',
            'ocena_kadry': 'staff_rating',
            'jakosc_pomocy': 'treatment_rating',
            'zasady_i_wymagania': 'rules_rating',
            'atmosfera': 'atmosphere_rating',
        }
        
        for field_name, django_field in field_mapping.items():
            pattern = rf"INSERT INTO `field_data_field_{field_name}` VALUES"
            match = re.search(pattern, sql_content, re.IGNORECASE)
            
            if match:
                start = match.end()
                end = sql_content.find('/*!40000 ALTER TABLE', start)
                if end == -1:
                    end = sql_content.find('UNLOCK TABLES', start)
                if end == -1:
                    end = sql_content.find(');', start)
                    if end != -1:
                        end = end + 2
                
                if end != -1:
                    block = sql_content[start:end]
                    
                    # Format: ('node','osrodek',0,entity_id,revision_id,'und',delta,VALUE,NULL)
                    pattern_rating = r"\('node','osrodek',0,(\d+),(\d+),'und',(\d+),(\d+),NULL\)"
                    matches = list(re.finditer(pattern_rating, block))
                    
                    for m in matches:
                        nid = int(m.group(1))
                        fivestar_value = int(m.group(4))
                        
                        # Konwertuj z skali fivestar (0-100) na 1-5
                        rating = self._convert_fivestar_to_rating(fivestar_value)
                        
                        if nid not in ratings:
                            ratings[nid] = {}
                        ratings[nid][django_field] = rating
        
        return ratings

    def _import_facility_ratings(self, sql_content, nodes, dry_run, force=False):
        """Importuje agregowane oceny placówek jako FacilityRating"""
        imported = 0
        
        # Parsuj oceny
        ratings = self._parse_facility_ratings(sql_content)
        self.stdout.write(f'Znaleziono oceny dla {len(ratings)} placówek')
        
        for nid, rating_data in ratings.items():
            if nid not in nodes:
                continue
            
            node_title = nodes[nid]
            
            # Znajdź placówkę
            facility = None
            try:
                facility = MedicalFacility.objects.get(name=node_title)
            except MedicalFacility.DoesNotExist:
                # Spróbuj znaleźć częściowe dopasowanie
                facilities = MedicalFacility.objects.filter(name__icontains=node_title[:30])
                if facilities.count() == 1:
                    facility = facilities.first()
                elif facilities.count() > 1:
                    facility = facilities.first()
                    self.stdout.write(
                        self.style.WARNING(
                            f'Wielu placówek dla nid {nid} ({node_title}), używam pierwszej'
                        )
                    )
                else:
                    self.stdout.write(
                        self.style.WARNING(
                            f'Nie znaleziono placówki dla nid {nid} ({node_title[:50]}...)'
                        )
                    )
                    continue
            except MedicalFacility.MultipleObjectsReturned:
                facility = MedicalFacility.objects.filter(name=node_title).first()
                self.stdout.write(
                    self.style.WARNING(
                        f'Wielu placówek dla nid {nid}, używam pierwszej'
                    )
                )
            
            # Oblicz overall_rating jako średnią z dostępnych ocen
            rating_values = [v for v in rating_data.values() if v is not None]
            if rating_values:
                overall_rating = round(sum(rating_values) / len(rating_values))
            else:
                overall_rating = 3  # Domyślna ocena
            
            # Sprawdź czy już istnieje ocena dla tej placówki (bez użytkownika, bez komentarza)
            if not dry_run and not force:
                existing = FacilityRating.objects.filter(
                    facility=facility,
                    user__isnull=True,
                    comment=''
                ).exists()
                if existing:
                    continue
            
            if not dry_run:
                # Utwórz lub zaktualizuj ocenę
                rating, created = FacilityRating.objects.get_or_create(
                    facility=facility,
                    user=None,
                    comment='',
                    defaults={
                        'overall_rating': overall_rating,
                        'staff_rating': rating_data.get('staff_rating'),
                        'facilities_rating': rating_data.get('facilities_rating'),
                        'treatment_rating': rating_data.get('treatment_rating'),
                        'rules_rating': rating_data.get('rules_rating'),
                        'atmosphere_rating': rating_data.get('atmosphere_rating'),
                        'status': 'approved',
                    }
                )
                
                if not created:
                    # Zaktualizuj istniejącą ocenę
                    rating.overall_rating = overall_rating
                    rating.staff_rating = rating_data.get('staff_rating', rating.staff_rating)
                    rating.facilities_rating = rating_data.get('facilities_rating', rating.facilities_rating)
                    rating.treatment_rating = rating_data.get('treatment_rating', rating.treatment_rating)
                    rating.rules_rating = rating_data.get('rules_rating', rating.rules_rating)
                    rating.atmosphere_rating = rating_data.get('atmosphere_rating', rating.atmosphere_rating)
                    rating.status = 'approved'
                    rating.save()
                
                imported += 1
                self.stdout.write(
                    f'  {"Utworzono" if created else "Zaktualizowano"} oceny dla {facility.name[:40]}... '
                    f'(ogólna: {overall_rating}, kadra: {rating_data.get("staff_rating", "N/A")}, '
                    f'wyposażenie: {rating_data.get("facilities_rating", "N/A")}, '
                    f'leczenie: {rating_data.get("treatment_rating", "N/A")}, '
                    f'zasady: {rating_data.get("rules_rating", "N/A")}, '
                    f'atmosfera: {rating_data.get("atmosphere_rating", "N/A")})'
                )
            else:
                imported += 1
                self.stdout.write(
                    f'  [DRY-RUN] Utworzyłbym oceny dla {facility.name[:40]}...'
                )
        
        return imported

