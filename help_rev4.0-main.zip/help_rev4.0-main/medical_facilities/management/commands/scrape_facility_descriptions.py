"""
Django management command do scrapowania opisów i danych placówek ze starej strony hyperreal.info/help
"""
import re
import time
from urllib.parse import quote, unquote
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from medical_facilities.models import MedicalFacility

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    raise CommandError(
        'Ten skrypt wymaga bibliotek requests i beautifulsoup4.\n'
        'Zainstaluj je: pip install requests beautifulsoup4'
    )


class Command(BaseCommand):
    help = 'Scrapuje opisy i dane placówek ze starej strony hyperreal.info/help'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Tryb testowy - nie zapisuje zmian do bazy'
        )
        parser.add_argument(
            '--limit',
            type=int,
            default=None,
            help='Ogranicza liczbę placówek do przetworzenia'
        )
        parser.add_argument(
            '--delay',
            type=float,
            default=1.5,
            help='Opóźnienie między requestami w sekundach (domyślnie: 1.5)'
        )
        parser.add_argument(
            '--force',
            action='store_true',
            help='Wymuś aktualizację nawet jeśli opis już istnieje'
        )
        parser.add_argument(
            '--skip-existing',
            action='store_true',
            help='Pomiń placówki które już mają opis'
        )

    def handle(self, *args, **options):
        dry_run = options.get('dry_run', False)
        limit = options.get('limit')
        delay = options.get('delay', 1.5)
        force = options.get('force', False)
        skip_existing = options.get('skip_existing', False)

        if dry_run:
            self.stdout.write(self.style.WARNING('TRYB TESTOWY - żadne zmiany nie zostaną zapisane'))

        # Pobierz listę placówek ze strony glossary
        self.stdout.write('Pobieranie listy placówek ze strony glossary...')
        facilities_from_glossary = self._scrape_glossary_page(delay)
        
        if not facilities_from_glossary:
            self.stdout.write(self.style.ERROR('Nie udało się pobrać listy placówek ze strony glossary'))
            return
        
        self.stdout.write(f'Znaleziono {len(facilities_from_glossary)} placówek na stronie glossary\n')

        # Jeśli podano limit, ogranicz
        if limit:
            facilities_from_glossary = facilities_from_glossary[:limit]

        self.stdout.write(f'Przetwarzanie {len(facilities_from_glossary)} placówek')
        self.stdout.write(f'Opóźnienie między requestami: {delay}s\n')

        total_updated = 0
        total_skipped = 0
        errors = []
        not_found = []

        for idx, facility_data in enumerate(facilities_from_glossary, 1):
            facility_name = facility_data['name']
            facility_url = facility_data['url']
            
            try:
                # Znajdź placówkę w bazie Django
                facility = self._find_facility_by_name(facility_name)
                
                if not facility:
                    not_found.append(facility_name)
                    if len(not_found) <= 10:
                        self.stdout.write(
                            self.style.WARNING(
                                f'  ? [{idx}/{len(facilities_from_glossary)}] {facility_name[:50]}... - nie znaleziono w bazie Django'
                            )
                        )
                    continue
                
                # Sprawdź czy już ma opis
                if skip_existing and facility.description and not force:
                    total_skipped += 1
                    if total_skipped % 20 == 0:
                        self.stdout.write(f'  Pominięto {total_skipped} placówek z istniejącymi opisami...')
                    continue
                
                # Scrapuj dane placówki
                facility_data_scraped = self._scrape_facility_data_from_url(facility_url, delay)
                
                if facility_data_scraped:
                    updated = False
                    changes = []
                    
                    # Debug: pokaż co znaleziono
                    if idx <= 3:
                        self.stdout.write(f'  DEBUG: Znaleziono dane dla {facility.name[:40]}...: {list(facility_data_scraped.keys())}')
                    
                    # Aktualizuj opis
                    if facility_data_scraped.get('description'):
                        new_description = facility_data_scraped['description'].strip()
                        if force or not facility.description or len(new_description) > len(facility.description or ''):
                            if not dry_run:
                                facility.description = new_description
                                changes.append('opis')
                            updated = True
                            if idx <= 3:
                                self.stdout.write(f'    DEBUG: Opis długość: {len(new_description)} znaków')
                    
                    # Aktualizuj inne pola jeśli są dostępne
                    if facility_data_scraped.get('phone') and not facility.phone:
                        if not dry_run:
                            facility.phone = facility_data_scraped['phone']
                            changes.append('telefon')
                        updated = True
                    
                    if facility_data_scraped.get('email') and not facility.email:
                        if not dry_run:
                            facility.email = facility_data_scraped['email']
                            changes.append('email')
                        updated = True
                    
                    if facility_data_scraped.get('website') and not facility.website:
                        if not dry_run:
                            facility.website = facility_data_scraped['website']
                            changes.append('strona WWW')
                        updated = True
                    
                    if updated:
                        if not dry_run:
                            facility.save()
                            total_updated += 1
                            self.stdout.write(
                                self.style.SUCCESS(
                                    f'✓ [{idx}/{len(facilities_from_glossary)}] {facility.name[:50]}... - zaktualizowano: {", ".join(changes)}'
                                )
                            )
                        else:
                            self.stdout.write(
                                self.style.SUCCESS(
                                    f'  [DRY-RUN] [{idx}/{len(facilities_from_glossary)}] {facility.name[:50]}... - znaleziono dane: {", ".join(changes)}'
                                )
                            )
                    else:
                        if idx <= 3:
                            self.stdout.write(f'  DEBUG: Brak zmian dla {facility.name[:40]}...')
                        if idx % 20 == 0:
                            self.stdout.write(f'  Przetworzono {idx}/{len(facilities_from_glossary)} placówek...')
                else:
                    if idx <= 3:
                        self.stdout.write(f'  DEBUG: Brak danych dla {facility.name[:40]}... (URL: {facility_url})')
                    if idx % 20 == 0:
                        self.stdout.write(f'  Przetworzono {idx}/{len(facilities_from_glossary)} placówek...')
                
                time.sleep(delay)  # Szanuj serwer

            except Exception as e:
                error_msg = f'{facility_name}: {str(e)}'
                errors.append(error_msg)
                self.stdout.write(self.style.ERROR(f'✗ [{idx}/{len(facilities_from_glossary)}] {error_msg}'))
                time.sleep(delay)  # Nawet po błędzie czekaj

        # Podsumowanie
        self.stdout.write(self.style.SUCCESS(f'\n=== PODSUMOWANIE ==='))
        self.stdout.write(f'Zaktualizowano: {total_updated}')
        self.stdout.write(f'Pominięto: {total_skipped}')
        if not_found:
            self.stdout.write(
                self.style.WARNING(f'\nNie znaleziono w bazie Django ({len(not_found)}):')
            )
            for name in not_found[:10]:  # Pokaż pierwsze 10
                self.stdout.write(f'  - {name[:60]}...')
            if len(not_found) > 10:
                self.stdout.write(f'  ... i {len(not_found) - 10} więcej')
        if errors:
            self.stdout.write(self.style.WARNING(f'\nBłędy ({len(errors)}):'))
            for error in errors[:10]:  # Pokaż pierwsze 10 błędów
                self.stdout.write(f'  - {error}')
            if len(errors) > 10:
                self.stdout.write(f'  ... i {len(errors) - 10} więcej')

    def _scrape_glossary_page(self, delay=1.5):
        """Scrapuje stronę glossary i zwraca listę placówek z URL-ami"""
        base_url = 'https://hyperreal.info/help/glossary'
        facilities = []
        seen_urls = set()
        
        try:
            # Najpierw pobierz główną stronę glossary
            response = requests.get(base_url, timeout=15, headers={
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }, allow_redirects=True)
            
            if response.status_code != 200:
                self.stdout.write(
                    self.style.ERROR(f'Błąd HTTP {response.status_code} przy pobieraniu glossary')
                )
                return []
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Szukaj wszystkich linków do placówek na głównej stronie
            facilities.extend(self._extract_facilities_from_page(soup, seen_urls))
            
            # Szukaj linków do różnych sekcji alfabetycznych
            glossary_links = soup.find_all('a', href=re.compile(r'glossary'))
            alphabet_urls = []
            
            for link in glossary_links:
                href = link.get('href', '')
                if 'glossary' in href and href not in ['/help/glossary', 'glossary', '#']:
                    # Buduj pełny URL
                    if href.startswith('/'):
                        full_url = f'https://hyperreal.info{href}'
                    elif href.startswith('glossary'):
                        full_url = f'https://hyperreal.info/help/{href}'
                    elif href.startswith('http'):
                        full_url = href
                    else:
                        full_url = f'https://hyperreal.info/help/{href}'
                    
                    if full_url not in alphabet_urls and 'hyperreal.info' in full_url and 'glossary' in full_url:
                        alphabet_urls.append(full_url)
            
            # Przetwórz każdą sekcję alfabetyczną
            if alphabet_urls:
                self.stdout.write(f'Znaleziono {len(alphabet_urls)} sekcji alfabetycznych')
            
            for alphabet_url in alphabet_urls[:50]:  # Ograniczenie do 50 sekcji
                try:
                    time.sleep(delay / 2)  # Opóźnienie między sekcjami
                    
                    response = requests.get(alphabet_url, timeout=15, headers={
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    }, allow_redirects=True)
                    
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        page_facilities = self._extract_facilities_from_page(soup, seen_urls)
                        facilities.extend(page_facilities)
                except Exception:
                    continue
            
            return facilities
            
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Błąd przy scrapowaniu glossary: {str(e)}')
            )
            import traceback
            self.stdout.write(traceback.format_exc())
            return []
    
    def _extract_facilities_from_page(self, soup, seen_urls):
        """Wyciąga listę placówek z pojedynczej strony"""
        facilities = []
        
        # Szukaj wszystkich linków do placówek
        all_links = soup.find_all('a')
        links = [link for link in all_links if 'placowka' in link.get('href', '').lower()]
        
        for link in links:
            href = link.get('href', '')
            
            if 'placowka' not in href.lower():
                continue
            
            # Wyciągnij slug z href
            slug = None
            if href.startswith('placowka/'):
                slug = href.replace('placowka/', '').split('"')[0].split("'")[0].strip()
            elif '/placowka/' in href:
                slug = href.split('/placowka/')[-1].split('"')[0].split("'")[0].strip()
            elif href.startswith('/help/placowka/'):
                slug = href.replace('/help/placowka/', '').split('"')[0].split("'")[0].strip()
            elif 'hyperreal.info/help/placowka/' in href:
                slug = href.split('hyperreal.info/help/placowka/')[-1].split('"')[0].split("'")[0].strip()
            
            if not slug:
                continue
            
            # Dekoduj URL encoding
            try:
                slug = unquote(slug)
            except:
                slug = slug.replace('%5F', '_').replace('%20', '_')
            
            slug = slug.replace(' ', '_').strip()
            
            # Pobierz nazwę placówki z tekstu linku
            name = link.get_text().strip()
            name = re.sub(r'^\s+|\s+$', '', name)
            
            # Buduj pełny URL
            full_url = f'https://hyperreal.info/help/placowka/{slug}'
            
            # Sprawdź czy nie ma duplikatu
            if name and slug and full_url not in seen_urls:
                seen_urls.add(full_url)
                facilities.append({
                    'name': name,
                    'slug': slug,
                    'url': full_url
                })
        
        return facilities

    def _find_facility_by_name(self, name):
        """Znajduje placówkę w bazie Django po nazwie (próbuje różne dopasowania)"""
        # Spróbuj dokładne dopasowanie
        try:
            return MedicalFacility.objects.get(name=name)
        except MedicalFacility.DoesNotExist:
            pass
        except MedicalFacility.MultipleObjectsReturned:
            return MedicalFacility.objects.filter(name=name).first()
        
        # Spróbuj częściowe dopasowanie (zawiera)
        facilities = MedicalFacility.objects.filter(name__icontains=name[:40])
        if facilities.count() == 1:
            return facilities.first()
        elif facilities.count() > 1:
            # Jeśli wiele, spróbuj dokładniejsze dopasowanie
            for facility in facilities:
                # Porównaj po normalizowanych nazwach (bez spacji, małe litery)
                facility_name_norm = re.sub(r'\s+', '', facility.name.lower())
                name_norm = re.sub(r'\s+', '', name.lower())
                if facility_name_norm == name_norm or facility_name_norm.startswith(name_norm[:30]):
                    return facility
            # Jeśli nie znaleziono, zwróć pierwszą
            return facilities.first()
        
        # Spróbuj wyszukiwanie po początku nazwy (dla długich nazw)
        if len(name) > 30:
            facilities = MedicalFacility.objects.filter(name__istartswith=name[:30])
            if facilities.count() == 1:
                return facilities.first()
        
        return None

    def _scrape_facility_data_from_url(self, url, delay=1.5):
        """Scrapuje dane placówki z konkretnego URL"""
        try:
            response = requests.get(url, timeout=15, headers={
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }, allow_redirects=True)
            
            if response.status_code == 200:
                # Parsuj dane
                data = self._parse_facility_data_from_html(response.text, url)
                return data
            else:
                return None
                
        except requests.RequestException as e:
            return None
        except Exception:
            return None

    def _parse_facility_data_from_html(self, html, url=None):
        """Parsuje dane placówki z HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        data = {}
        
        # Znajdź główną sekcję z danymi (col-sm-9 lub podobna)
        main_content = soup.find('section', class_=lambda x: x and isinstance(x, list) and 'col-sm-9' in x)
        if not main_content:
            main_content = soup.find('div', class_=lambda x: x and isinstance(x, list) and 'col-sm-9' in x)
        if not main_content:
            main_content = soup.find('main') or soup.find('article')
        
        # Jeśli nie znaleziono, użyj całej strony ale usuń nawigację i stopkę
        if not main_content:
            main_content = soup.find('body')
            if main_content:
                # Usuń nawigację, stopkę, itp.
                for elem in main_content.find_all(['nav', 'header', 'footer', 'aside']):
                    elem.decompose()
        
        if not main_content:
            return None
        
        page_text = main_content.get_text(separator=' | ', strip=True)
        full_page_text = soup.get_text()
        
        # Szukaj opisu placówki
        description = None
        
        # 1. Szukaj pola "Opis placówki" lub podobnego
        # Format może być: "Opis placówki: | tekst..."
        opis_match = re.search(r'Opis\s+placówki[:\|]?\s*\|\s*(.+?)(?:\s*\|\s*[A-Z][^|]{0,30}:|$)', page_text, re.I | re.DOTALL)
        if opis_match:
            description = opis_match.group(1).strip()
            # Usuń kolejne etykiety z końca
            description = re.sub(r'\s*\|\s*[A-Z][^|]{0,30}:.*$', '', description)
        
        # 2. Szukaj w polach field-opis-placowki (Drupal field structure)
        if not description or len(description) < 50:
            field_opis = soup.find('div', class_=lambda x: x and isinstance(x, list) and any('opis' in str(c).lower() for c in x))
            if field_opis:
                # Znajdź wartość pola
                field_item = field_opis.find('div', class_=lambda x: x and isinstance(x, list) and any('item' in str(c).lower() or 'value' in str(c).lower() for c in x))
                if field_item:
                    description = field_item.get_text(separator='\n', strip=True)
                else:
                    # Spróbuj bezpośrednio z field_opis
                    description = field_opis.get_text(separator='\n', strip=True)
        
        # 3. Szukaj najdłuższego bloku tekstu który wygląda na opis
        if not description or len(description) < 50:
            # Znajdź wszystkie bloki tekstu w main_content
            text_blocks = []
            for elem in main_content.find_all(['div', 'p', 'section']):
                text = elem.get_text(separator=' ', strip=True)
                # Pomiń bardzo krótkie lub bardzo długie
                if 100 < len(text) < 5000:
                    text_blocks.append((len(text), text))
            
            if text_blocks:
                # Weź najdłuższy sensowny blok
                text_blocks.sort(reverse=True)
                for length, text in text_blocks[:5]:
                    # Sprawdź czy wygląda na opis (zawiera typowe słowa)
                    if any(word in text.lower() for word in ['pacjent', 'terapia', 'leczenie', 'ośrodek', 'poradnia', 'uzależnienie', 'program', 'oferta', 'przyjmowani']):
                        description = text
                        break
        
        if description and len(description) > 50:
            # Oczyść opis z nadmiarowych białych znaków
            description = re.sub(r'\n{3,}', '\n\n', description)
            description = re.sub(r' {2,}', ' ', description)
            description = re.sub(r'\|\s*', '\n', description)  # Zamień separatory | na nowe linie
            description = description.strip()
            data['description'] = description
        
        # Szukaj telefonu stacjonarnego
        phone_match = re.search(r'Telefon\s+stacjonarny[:\|]?\s*\|\s*([+\d\s\-\(\)]{8,})', page_text, re.I)
        if phone_match:
            phone = re.sub(r'[\s\-\(\)]', '', phone_match.group(1))
            if len(phone) >= 9:
                data['phone'] = phone
        
        # Jeśli nie znaleziono, szukaj ogólnie telefonu
        if 'phone' not in data:
            phone_patterns = [
                r'Tel[\.:]?\s*\|\s*([+\d\s\-\(\)]{8,})',
                r'Telefon[\.:]?\s*\|\s*([+\d\s\-\(\)]{8,})',
                r'(\+?\d{1,3}[\s\-]?\(?\d{1,4}\)?[\s\-]?\d{1,4}[\s\-]?\d{1,4}[\s\-]?\d{1,4}[\s\-]?\d{1,4})',
            ]
            for pattern in phone_patterns:
                match = re.search(pattern, page_text, re.I)
                if match:
                    phone = re.sub(r'[\s\-\(\)]', '', match.group(1))
                    if len(phone) >= 9:
                        data['phone'] = phone
                        break
        
        # Szukaj emaila
        email_match = re.search(r'Email[:\|]?\s*\|\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', page_text, re.I)
        if email_match:
            data['email'] = email_match.group(1)
        else:
            # Szukaj ogólnie emaila
            email_pattern = r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
            email_match = re.search(email_pattern, full_page_text)
            if email_match:
                data['email'] = email_match.group(1)
        
        # Szukaj strony WWW
        website_match = re.search(r'Adres\s+strony\s+WWW[:\|]?\s*\|\s*(https?://[^\s\|]+|www\.[^\s\|]+)', page_text, re.I)
        if website_match:
            website = website_match.group(1)
            if not website.startswith('http'):
                website = 'http://' + website
            data['website'] = website
        else:
            # Szukaj ogólnie strony WWW
            website_patterns = [
                r'www\.([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
                r'http[s]?://([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            ]
            for pattern in website_patterns:
                match = re.search(pattern, full_page_text)
                if match:
                    website = match.group(1)
                    if not website.startswith('http'):
                        website = 'http://' + website
                    data['website'] = website
                    break
        
        return data if data else None

