# Django management command: import_legacy_facilities
# Importuje placówki z bazy legacy (MySQL) do aktualnego modelu Facility.
import os
import re
import shutil
import unicodedata
from typing import Dict, List, Optional, Tuple

from django.core.management.base import BaseCommand, CommandError
from django.db import connections, transaction
from django.utils.text import slugify

from medical_facilities.models import MedicalFacility, Voivodeship

SYNONYMS = {
    'name': [
        'name', 'nazwa', 'title', 'facility_name',
        'post_title', 'subject', 'subject_title', 'nazwa_placowki', 'placowka', 'placowka_nazwa'
    ],
    'slug': ['slug', 'permalink', 'post_name'],
    'description': ['description', 'opis', 'desc', 'content', 'full_description', 'post_content'],
    'short_description': ['short_description', 'summary', 'lead', 'opis_krotki'],
    'address': ['address', 'adres', 'street', 'ulica'],
    'city': ['city', 'miasto', 'town'],
    'country': ['country', 'kraj', 'państwo', 'panstwo'],
    'phone': ['phone', 'telefon', 'tel'],
    'email': ['email', 'mail'],
    'website': ['website', 'www', 'url', 'link', 'homepage'],
    'latitude': ['lat', 'latitude', 'geo_lat'],
    'longitude': ['lon', 'lng', 'long', 'longitude', 'geo_lon'],
    'image': ['image', 'photo', 'logo', 'image_path', 'thumbnail'],
}

def normalize_str(val) -> str:
    if val is None:
        return ''
    return str(val).strip()

def try_float(val) -> Optional[float]:
    if val is None:
        return None
    try:
        return float(val)
    except Exception:
        try:
            return float(str(val).replace(',', '.'))
        except Exception:
            return None

class Command(BaseCommand):
    help = "Importuje placówki z bazy legacy (MySQL) do modelu MedicalFacility w bieżącej bazie."

    def add_arguments(self, parser):
        parser.add_argument('--legacy-table', type=str, required=False,
                            help='Nazwa tabeli w bazie legacy zawierającej placówki. Jeśli nie podasz, spróbuję wykryć.')
        parser.add_argument('--dry-run', action='store_true', help='Tryb podglądu: nie zapisuje, tylko raportuje.')
        parser.add_argument('--batch-size', type=int, default=500, help='Limit rekordów pobieranych naraz.')
        parser.add_argument('--truncate', action='store_true', help='Usuwa istniejące placówki przed importem.')
        parser.add_argument('--image-base-path', type=str, required=False,
                            help='Bazowa ścieżka do legacy obrazów (opcjonalnie).')
        parser.add_argument('--drupal', action='store_true', help='Import danych z Drupala (bundle osrodek) z wielu tabel.')

    def handle(self, *args, **options):
        legacy_alias = 'legacy'
        if legacy_alias not in connections.databases:
            raise CommandError("Brak konfiguracji bazy 'legacy' w settings.DATABASES.")

        legacy = connections[legacy_alias]
        table = options.get('legacy_table')
        dry_run = options.get('dry_run', False)
        batch_size = options.get('batch_size', 500)
        truncate = options.get('truncate', False)
        image_base_path = options.get('image_base_path')

        # DRUPAL: specjalny tryb importu z wielu tabel
        if options.get('drupal', False):
            return self._handle_drupal_import(legacy, dry_run, batch_size, truncate, image_base_path)

        if not table:
            table = self.detect_legacy_table(legacy)
            if not table:
                raise CommandError("Nie udało się automatycznie wykryć tabeli. Podaj nazwę przez --legacy-table.")
            self.stdout.write(self.style.WARNING(f"Wykryto kandydata: {table}"))
        elif not self.table_exists(legacy, table):
            raise CommandError(f"Podana tabela '{table}' nie istnieje w bazie danych 'legacy'.")

        columns = self.get_columns(legacy, table)
        if not columns:
            raise CommandError(f"Nie można odczytać kolumn z `{table}`.")

        facility_fields = self.get_facility_fields()
        mapping = self.build_mapping(columns, facility_fields)

        if 'name' not in mapping:
            raise CommandError("Brak mapowania 'name' (nazwa placówki). Podaj poprawną tabelę lub kolumny.")

        self.stdout.write("Mapowanie (MedicalFacility <- legacy):")
        for k, v in mapping.items():
            self.stdout.write(f"  {k} <- {v}")

        total = self.count_rows(legacy, table)
        self.stdout.write(self.style.SUCCESS(f"Rekordów do importu: {total}"))

        if truncate and not dry_run:
            self.stdout.write(self.style.WARNING("Usuwam istniejące placówki..."))
            MedicalFacility.objects.all().delete()

        created_count = 0
        updated_count = 0
        skipped_count = 0

        offset = 0
        while offset < total:
            rows = self.fetch_rows(legacy, table, limit=batch_size, offset=offset)
            for row in rows:
                row_dict = dict(zip(columns, row))
                data = self.row_to_facility_dict(row_dict, mapping, facility_fields)

                key_name = normalize_str(data.get('name'))
                key_city = normalize_str(data.get('city')) if 'city' in data else ''
                if not key_name:
                    skipped_count += 1
                    continue

                if 'slug' in facility_fields and not normalize_str(data.get('slug')):
                    base_slug = slugify(f"{key_name}-{key_city}") if key_city else slugify(key_name)
                    data['slug'] = base_slug[:50]

                if image_base_path and 'image' in data and normalize_str(data['image']):
                    new_rel_path = self.copy_image_if_exists(image_base_path, data['image'])
                    if new_rel_path:
                        data['image'] = new_rel_path
                    else:
                        data.pop('image', None)

                if dry_run:
                    continue

                with transaction.atomic():
                    existing_qs = MedicalFacility.objects.filter(name=key_name)
                    if key_city and 'city' in facility_fields:
                        existing_qs = existing_qs.filter(city=key_city)

                    obj = existing_qs.first()
                    if obj:
                        for field in data:
                            if field in facility_fields:
                                try:
                                    setattr(obj, field, data[field])
                                except Exception:
                                    pass
                        obj.save()
                        updated_count += 1
                    else:
                        filtered_defaults = {f: v for f, v in data.items() if f in facility_fields}
                        obj = MedicalFacility(**filtered_defaults)
                        obj.save()
                        created_count += 1

            offset += batch_size
            self.stdout.write(self.style.SUCCESS(f"Postęp: {min(offset, total)}/{total}"))

        self.stdout.write(self.style.SUCCESS(
            f"Zakończono. Utworzono: {created_count}, zaktualizowano: {updated_count}, pominięto: {skipped_count}"
        ))
        if dry_run:
            self.stdout.write(self.style.WARNING("Dry-run: nic nie zapisano."))

    def detect_legacy_table(self, legacy_conn) -> Optional[str]:
        """
        Spróbuj automatycznie wybrać tabelę z placówkami, preferując taką,
        która zawiera kolumnę odpowiadającą polu 'name' (np. name/nazwa/title/...).
        """
        candidates: List[str] = []
        with legacy_conn.cursor() as cursor:
            cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE();")
            names = [r[0] for r in cursor.fetchall()]
        patterns = [r'facility', r'facilities', r'plac', r'instyt', r'clinic', r'help']
        for n in names:
            lower = n.lower()
            if any(re.search(p, lower) for p in patterns):
                candidates.append(n)

        # Jeśli tylko jeden kandydat, spróbuj zweryfikować czy posiada kolumnę 'name' (lub synonim)
        if len(candidates) == 1:
            cols = set(c.lower() for c in self.get_columns(legacy_conn, candidates[0]))
            name_syns = [s.lower() for s in SYNONYMS.get('name', ['name'])]
            if any(s in cols for s in name_syns):
                return candidates[0]

        # Preferencje nazw tabel
        preference_order = ['facilities', 'facility', 'help_facility', 'placowki']
        sorted_candidates: List[str] = []
        # 1) dokładne dopasowania preferowane
        for preferred in preference_order:
            for c in candidates:
                if c.lower() == preferred and c not in sorted_candidates:
                    sorted_candidates.append(c)
        # 2) pozostałe kandydaty w kolejności znalezienia
        for c in candidates:
            if c not in sorted_candidates:
                sorted_candidates.append(c)

        # Wybierz pierwszą tabelę, która ma potencjalną kolumnę nazwy wśród kandydatów
        name_syns = [s.lower() for s in SYNONYMS.get('name', ['name'])]
        for tbl in sorted_candidates:
            try:
                cols_lower = set(c.lower() for c in self.get_columns(legacy_conn, tbl))
            except Exception:
                continue
            if any(s in cols_lower for s in name_syns):
                return tbl

        # Jeśli żadna z kandydackich nazw nie pasuje, przeszukaj wszystkie tabele i wybierz tę z największą liczbą dopasowań synonimów
        best_tbl: Optional[str] = None
        best_score = -1
        for tbl in names:
            try:
                cols_lower = set(c.lower() for c in self.get_columns(legacy_conn, tbl))
            except Exception:
                continue
            # Licz punkty za dopasowania kluczowych pól
            score = 0
            # 'name' jest krytyczne – brak eliminuje z rozważań
            if not any(s in cols_lower for s in name_syns):
                continue
            score += 5  # preferuj posiadanie 'name'
            # Dodatkowe punkty za inne typowe pola
            for key in ['city', 'address', 'website', 'phone', 'email', 'latitude', 'longitude']:
                for syn in SYNONYMS.get(key, [key]):
                    if syn.lower() in cols_lower:
                        score += 1
                        break
            if score > best_score:
                best_score = score
                best_tbl = tbl
        if best_tbl:
            return best_tbl

        # Brak oczywistych dopasowań – zwróć pierwszego kandydata jeśli istnieje
        return sorted_candidates[0] if sorted_candidates else None

    def get_columns(self, legacy_conn, table) -> List[str]:
        with legacy_conn.cursor() as cursor:
            cursor.execute(f"SHOW COLUMNS FROM `{table}`;")
            cols = [r[0] for r in cursor.fetchall()]
        return cols

    def fetch_rows(self, legacy_conn, table, limit=500, offset=0) -> List[Tuple]:
        q = f"SELECT * FROM `{table}` LIMIT {limit} OFFSET {offset};"
        with legacy_conn.cursor() as cursor:
            cursor.execute(q)
            rows = cursor.fetchall()
        return rows

    def count_rows(self, legacy_conn, table) -> int:
        with legacy_conn.cursor() as cursor:
            cursor.execute(f"SELECT COUNT(*) FROM `{table}`;")
            count = cursor.fetchone()[0]
        return int(count or 0)

    def get_facility_fields(self) -> List[str]:
        fields = []
        for f in MedicalFacility._meta.get_fields():
            if getattr(f, 'concrete', False) and not getattr(f, 'many_to_many', False) and not getattr(f, 'one_to_many', False):
                fields.append(f.name)
        return fields

    # --- DRUPAL IMPORT LOGIC ---
    def _normalize_voivodeship(self, raw: Optional[str]) -> Optional[str]:
        if not raw:
            return None
        s = str(raw).strip().lower()
        # Usuń znaki diakrytyczne do porównania ascii
        s_ascii = unicodedata.normalize('NFD', s)
        s_ascii = ''.join(ch for ch in s_ascii if unicodedata.category(ch) != 'Mn')
        s_ascii = s_ascii.replace('?', '').replace('�', '')
        replacements = {
            'zachodniopomorskie': 'zachodniopomorskie',
            'warminsko-mazurskie': 'warmińsko-mazurskie',
            'kujawsko-pomorskie': 'kujawsko-pomorskie',
            'dolnoslaskie': 'dolnośląskie',
            'wielkopolskie': 'wielkopolskie',
            'swietokrzyskie': 'świętokrzyskie',
            'malopolskie': 'małopolskie',
            'lodzkie': 'łódzkie',
            'pomorskie': 'pomorskie',
            'mazowieckie': 'mazowieckie',
            'podkarpackie': 'podkarpackie',
            'podlaskie': 'podlaskie',
            'lubuskie': 'lubuskie',
            'lubelskie': 'lubelskie',
            'opolskie': 'opolskie',
        }
        # Dopasuj najdłuższy klucz, aby unikać błędów typu 'pomorskie' vs 'zachodniopomorskie'
        for k in sorted(replacements.keys(), key=lambda x: -len(x)):
            if k in s_ascii:
                return replacements[k]
        # Jeśli łańcuch już odpowiada znanej nazwie, zwróć ją
        known = {v.name.lower() for v in Voivodeship.objects.all()}
        if s in known:
            return [x.name for x in Voivodeship.objects.all() if x.name.lower() == s][0]
        # Brak dopasowania
        return None

    def _get_voivodeship_obj(self, name: Optional[str]) -> Optional[Voivodeship]:
        if not name:
            return Voivodeship.objects.filter(name='Nieznane').first()
        obj = Voivodeship.objects.filter(name=name).first()
        if obj:
            return obj
        # Fallback: spróbuj dopasować po lower
        obj = Voivodeship.objects.filter(name__iexact=name).first()
        if obj:
            return obj
        return Voivodeship.objects.filter(name='Nieznane').first()

    def _unique_slug(self, base: str) -> str:
        base = (base or '')[:50]
        if not base:
            base = 'placowka'
        candidate = base
        i = 2
        while MedicalFacility.objects.filter(slug=candidate).exists():
            suffix = f"-{i}"
            candidate = (base[:50 - len(suffix)] + suffix)
            i += 1
        return candidate

    def _handle_drupal_import(self, legacy_conn, dry_run: bool, batch_size: int, truncate: bool, image_base_path: Optional[str]):
        # Policz liczbę węzłów typu osrodek
        with legacy_conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) FROM node WHERE type='osrodek';")
            total = int(cursor.fetchone()[0] or 0)
        self.stdout.write(self.style.SUCCESS(f"Węzłów Drupal (type=osrodek) do importu: {total}"))

        if truncate and not dry_run:
            self.stdout.write(self.style.WARNING("Usuwam istniejące placówki..."))
            MedicalFacility.objects.all().delete()

        # Przygotuj listę kolumn do pobrania z połączonych tabel
        # Uwaga: używamy LEFT JOIN, bo niektóre pola mogą nie istnieć
        def fetch_batch(limit: int, offset: int) -> List[Dict[str, Optional[str]]]:
            sql = (
                "SELECT n.nid, n.title AS name, "
                "addr.field_adres_thoroughfare AS street_address, "
                "addr.field_adres_locality AS city, "
                "addr.field_adres_postal_code AS postal_code, "
                "addr.field_adres_administrative_area AS admin_area, "
                "emails.field_email_email AS email, "
                "www.field_adres_strony_www_url AS website, "
                "kom.field_telefon_komorkowy_value AS phone_mobile, "
                "stac.field_telefon_stacjonarny_value AS phone_landline, "
                "zauf.field_telefon_zaufania_value AS phone_hotline, "
                "opisy.field_opis_placowki_value AS description "
                "FROM node n "
                "LEFT JOIN field_data_field_adres addr ON addr.entity_type='node' AND addr.bundle='osrodek' AND addr.entity_id=n.nid "
                "LEFT JOIN field_data_field_email emails ON emails.entity_type='node' AND emails.bundle='osrodek' AND emails.entity_id=n.nid "
                "LEFT JOIN field_data_field_adres_strony_www www ON www.entity_type='node' AND www.bundle='osrodek' AND www.entity_id=n.nid "
                "LEFT JOIN field_data_field_telefon_komorkowy kom ON kom.entity_type='node' AND kom.bundle='osrodek' AND kom.entity_id=n.nid "
                "LEFT JOIN field_data_field_telefon_stacjonarny stac ON stac.entity_type='node' AND stac.bundle='osrodek' AND stac.entity_id=n.nid "
                "LEFT JOIN field_data_field_telefon_zaufania zauf ON zauf.entity_type='node' AND zauf.bundle='osrodek' AND zauf.entity_id=n.nid "
                "LEFT JOIN field_data_field_opis_placowki opisy ON opisy.entity_type='node' AND opisy.bundle='osrodek' AND opisy.entity_id=n.nid "
                "WHERE n.type='osrodek' "
                f"LIMIT {limit} OFFSET {offset};"
            )
            with legacy_conn.cursor() as cursor:
                cursor.execute(sql)
                colnames = [d[0] for d in cursor.description]
                rows = cursor.fetchall()
            return [dict(zip(colnames, r)) for r in rows]

        created_count = 0
        updated_count = 0
        skipped_count = 0

        offset = 0
        while offset < total:
            batch = fetch_batch(batch_size, offset)
            for r in batch:
                name = normalize_str(r.get('name'))
                if not name:
                    skipped_count += 1
                    continue
                city = normalize_str(r.get('city'))
                postal_code = normalize_str(r.get('postal_code'))
                street_address = normalize_str(r.get('street_address'))
                description = normalize_str(r.get('description'))
                email = normalize_str(r.get('email'))
                website = normalize_str(r.get('website'))
                # Preferencja numeru telefonu: stacjonarny > komórkowy > zaufania
                phone = normalize_str(r.get('phone_landline')) or normalize_str(r.get('phone_mobile')) or normalize_str(r.get('phone_hotline'))

                slug = slugify(f"{name}-{city}")[:50] if city else slugify(name)[:50]
                slug = self._unique_slug(slug)

                admin_area = normalize_str(r.get('admin_area'))
                voi_name = self._normalize_voivodeship(admin_area)
                voiv_obj = self._get_voivodeship_obj(voi_name)

                if dry_run:
                    self.stdout.write(f"DRY-RUN: {name} | {city} | {postal_code} | {street_address} | {voi_name or 'Nieznane'} | {email} | {phone} | {website}")
                    continue

                defaults = {
                    'name': name,
                    'slug': slug,
                    'description': description,
                    'street_address': street_address,
                    'city': city,
                    'postal_code': postal_code,
                    'voivodeship': voiv_obj,
                    'phone': phone,
                    'email': email,
                    'website': website,
                }

                with transaction.atomic():
                    obj = MedicalFacility.objects.filter(name=name, city=city).first()
                    if obj:
                        for k, v in defaults.items():
                            setattr(obj, k, v)
                        obj.save()
                        updated_count += 1
                    else:
                        obj = MedicalFacility(**defaults)
                        obj.save()
                        created_count += 1

            offset += batch_size
            self.stdout.write(self.style.SUCCESS(f"Postęp: {min(offset, total)}/{total}"))

        self.stdout.write(self.style.SUCCESS(
            f"Zakończono (Drupal). Utworzono: {created_count}, zaktualizowano: {updated_count}, pominięto: {skipped_count}"
        ))
        if dry_run:
            self.stdout.write(self.style.WARNING("Dry-run: nic nie zapisano."))

    def get_facility_fields(self) -> List[str]:
        fields = []
        for f in MedicalFacility._meta.get_fields():
            if getattr(f, 'concrete', False) and not getattr(f, 'many_to_many', False) and not getattr(f, 'one_to_many', False):
                fields.append(f.name)
        return fields

    def build_mapping(self, legacy_columns: List[str], facility_fields: List[str]) -> Dict[str, str]:
        mapping = {}
        lower_cols = {c.lower(): c for c in legacy_columns}
        for field in facility_fields:
            if field in SYNONYMS:
                for syn in SYNONYMS[field]:
                    if syn.lower() in lower_cols:
                        mapping[field] = lower_cols[syn.lower()]
                        break
            else:
                if field.lower() in lower_cols:
                    mapping[field] = lower_cols[field.lower()]
        return mapping

    def row_to_facility_dict(self, row: Dict, mapping: Dict[str, str], facility_fields: List[str]) -> Dict[str, object]:
        data = {}
        for field, legacy_col in mapping.items():
            val = row.get(legacy_col)
            if field in ('name', 'slug', 'description', 'short_description', 'address', 'city', 'country', 'phone', 'email', 'website', 'image'):
                data[field] = normalize_str(val)
            elif field in ('latitude', 'longitude'):
                data[field] = try_float(val)
            else:
                data[field] = val
        if 'slug' in data and data['slug']:
            data['slug'] = data['slug'][:50]
        return data

    def copy_image_if_exists(self, base_path: str, legacy_value: str) -> Optional[str]:
        legacy_path = os.path.join(base_path, legacy_value)
        if not os.path.isfile(legacy_path):
            return None
        filename = os.path.basename(legacy_path)
        media_target_dir = os.path.join('media', 'facility_images')
        os.makedirs(media_target_dir, exist_ok=True)
        target_path = os.path.join(media_target_dir, filename)
        try:
            shutil.copy2(legacy_path, target_path)
            return os.path.join('facility_images', filename)
        except Exception:
            return None

    def table_exists(self, legacy_conn, table_name: str) -> bool:
        with legacy_conn.cursor() as cursor:
            cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = %s;", [table_name])
            return cursor.fetchone() is not None
