from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Avg, Count
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.generic import ListView, DetailView
from django.conf import settings
from django.contrib.auth.models import User
from django.core.cache import cache
from django_ratelimit.decorators import ratelimit
from django_ratelimit.exceptions import Ratelimited
from .models import (
    MedicalFacility, FacilityRating, FacilityImage,
    Voivodeship, FacilityType, TherapyType, AgeGroup
)
from .forms import (
    MedicalFacilityForm, 
    FacilityRatingForm, 
    FacilitySearchForm,
    ContactForm
)
from .utils import geocode_address, get_client_ip
import json
from django.utils import timezone
import logging

logger = logging.getLogger('security')


@ratelimit(key='ip', rate='60/m', method='GET', block=False)
def home(request):
    """Strona główna z wyszukiwaniem placówek."""
    search_form = FacilitySearchForm(request.GET or None)
    
    # Cache statystyk na 5 minut
    cache_key_stats = 'home_stats'
    stats = cache.get(cache_key_stats)
    if not stats:
        stats = {
            'total_facilities': MedicalFacility.objects.filter(status='approved').count(),
            'total_ratings': FacilityRating.objects.filter(status='approved').count(),
            'avg_rating': FacilityRating.objects.filter(status='approved').aggregate(
                avg=Avg('overall_rating')
            )['avg'] or 0
        }
        cache.set(cache_key_stats, stats, 300)  # 5 minut
    
    total_facilities = stats['total_facilities']
    total_ratings = stats['total_ratings']
    avg_rating = stats['avg_rating']
    
    # Pobierz najlepiej oceniane placówki
    top_facilities = MedicalFacility.objects.filter(
        status='approved'
    ).annotate(
        avg_rating=Avg('ratings__overall_rating'),
        rating_count=Count('ratings')
    ).filter(
        rating_count__gte=3  # Minimum 3 oceny
    ).order_by('-avg_rating')[:6]
    
    # Pobierz najnowsze placówki
    recent_facilities = MedicalFacility.objects.filter(
        status='approved'
    ).annotate(
        approved_ratings_count=Count('ratings', filter=Q(ratings__status='approved'))
    ).order_by('-created_at')[:6]
    
    context = {
        'search_form': search_form,
        'total_facilities': total_facilities,
        'total_ratings': total_ratings,
        'avg_rating': round(avg_rating, 1),
        'top_facilities': top_facilities,
        'recent_facilities': recent_facilities,
        'voivodeships': Voivodeship.objects.all(),
        'facility_types': FacilityType.objects.all(),
    }
    
    return render(request, 'medical_facilities/home.html', context)


@method_decorator(ratelimit(key='ip', rate='60/m', method='GET', block=False), name='dispatch')
class FacilityListView(ListView):
    """Lista placówek medycznych z filtrowaniem i paginacją."""
    model = MedicalFacility
    template_name = 'medical_facilities/facility_list.html'
    context_object_name = 'facilities'
    paginate_by = 12
    
    def get_queryset(self):
        queryset = MedicalFacility.objects.filter(status='approved').annotate(
            avg_rating=Avg('ratings__overall_rating'),
            rating_count=Count('ratings')
        ).select_related('voivodeship').prefetch_related(
            'facility_types', 'therapy_types', 'age_groups'
        )
        
        # Filtrowanie na podstawie parametrów GET
        query = self.request.GET.get('query')
        if query:
            queryset = queryset.filter(
                Q(name__icontains=query) |
                Q(city__icontains=query) |
                Q(description__icontains=query)
            )
        
        voivodeship_id = self.request.GET.get('voivodeship')
        if voivodeship_id:
            queryset = queryset.filter(voivodeship_id=voivodeship_id)
        
        facility_type_id = self.request.GET.get('facility_type')
        if facility_type_id:
            queryset = queryset.filter(facility_types=facility_type_id)
        

        accepts_nfz = self.request.GET.get('accepts_nfz')
        if accepts_nfz:
            queryset = queryset.filter(accepts_nfz=True)
        
        has_emergency_service = self.request.GET.get('has_emergency_service')
        if has_emergency_service:
            queryset = queryset.filter(has_emergency_service=True)
        
        # Sortowanie
        sort_by = self.request.GET.get('sort', 'name')
        if sort_by == 'rating':
            queryset = queryset.order_by('-avg_rating', 'name')
        elif sort_by == 'newest':
            queryset = queryset.order_by('-created_at')
        else:
            queryset = queryset.order_by('name')
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_form'] = FacilitySearchForm(self.request.GET or None)
        context['current_params'] = self.request.GET.urlencode()
        
        # Dodaj dane potrzebne do filtrów
        context['voivodeships'] = Voivodeship.objects.all()
        context['facility_types'] = FacilityType.objects.all()
        context['age_groups'] = AgeGroup.objects.all()
        
        # Dodaj listę wybranych typów placówek
        context['selected_facility_types'] = self.request.GET.getlist('facility_types')
        
        # Dodaj informację o całkowitej liczbie wyników (przed paginacją)
        context['total_results'] = self.get_queryset().count()
        
        return context


@method_decorator(ratelimit(key='ip', rate='60/m', method='GET', block=False), name='dispatch')
class FacilityDetailView(DetailView):
    """Szczegóły placówki medycznej."""
    model = MedicalFacility
    template_name = 'medical_facilities/facility_detail.html'
    context_object_name = 'facility'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'
    
    def get_queryset(self):
        return MedicalFacility.objects.filter(status='approved').select_related(
            'voivodeship'
        ).prefetch_related(
            'facility_types', 'therapy_types', 'age_groups',
            'images', 'ratings__user'
        )
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        facility = self.object
        
        # Pobierz wszystkie oceny bez filtrowania statusu
        all_ratings = facility.ratings.all().select_related('user')
        # Pobierz tylko zatwierdzone oceny
        approved_ratings = facility.ratings.filter(status='approved').select_related('user')
        
        # Debugowanie usunięte - niepotrzebne w produkcji
        
        # Przekazujemy do szablonu zarówno wszystkie oceny jak i tylko zatwierdzone
        context['all_ratings'] = all_ratings  # Wszystkie oceny
        context['ratings_count'] = all_ratings.count()
        context['approved_ratings'] = approved_ratings[:5]  # Pierwsze 5 zatwierdzonych ocen
        context['approved_ratings_count'] = approved_ratings.count()
        
        # Oblicz średnie oceny
        if approved_ratings.exists():
            context['avg_overall'] = approved_ratings.aggregate(avg=Avg('overall_rating'))['avg']
            context['avg_staff'] = approved_ratings.filter(staff_rating__isnull=False).aggregate(avg=Avg('staff_rating'))['avg']
            context['avg_facilities'] = approved_ratings.filter(facilities_rating__isnull=False).aggregate(avg=Avg('facilities_rating'))['avg']
            context['avg_treatment'] = approved_ratings.filter(treatment_rating__isnull=False).aggregate(avg=Avg('treatment_rating'))['avg']
        else:
            context['avg_overall'] = 0
            context['avg_staff'] = 0
            context['avg_facilities'] = 0
            context['avg_treatment'] = 0
        
        # Sprawdź czy użytkownik już ocenił
        if self.request.user.is_authenticated:
            context['user_rating'] = all_ratings.filter(user=self.request.user).first()
            context['rating_form'] = FacilityRatingForm()
        
        # Pobierz zdjęcia
        context['images'] = facility.images.all()
        context['primary_image'] = facility.images.filter(is_primary=True).first()
        
        # Podobne placówki
        similar_facilities = MedicalFacility.objects.filter(
            status='approved',
            voivodeship=facility.voivodeship
        ).exclude(
            id=facility.id
        ).annotate(
            avg_rating=Avg('ratings__overall_rating')
        )[:4]
        context['similar_facilities'] = similar_facilities
        
        return context


class TestRatingsView(DetailView):
    """Widok testowy do sprawdzania ocen placówki."""
    model = MedicalFacility
    template_name = 'medical_facilities/test_ratings.html'
    context_object_name = 'facility'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'
    
    def get_queryset(self):
        return MedicalFacility.objects.filter(status='approved').prefetch_related('ratings__user')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        facility = self.object
        
        # Pobierz wszystkie oceny bez filtrowania statusu
        all_ratings = facility.ratings.all().select_related('user')
        approved_ratings = facility.ratings.filter(status='approved')
        
        context['all_ratings'] = all_ratings
        context['all_ratings_count'] = all_ratings.count()
        context['approved_ratings'] = approved_ratings
        context['approved_ratings_count'] = approved_ratings.count()
        
        return context


@ratelimit(key='ip', rate='10/m', method='POST', block=True)
def add_facility(request):
    """Dodawanie nowej placówki medycznej."""
    if request.method == 'POST':
        form = MedicalFacilityForm(request.POST)
        if form.is_valid():
            facility = form.save(commit=False)
            facility.created_by = request.user if request.user.is_authenticated else None
            facility.status = 'approved'  # Automatyczne zatwierdzenie
            
            # Automatyczny geocoding jeśli brak współrzędnych
            if not facility.latitude or not facility.longitude:
                lat, lon = geocode_address(
                    facility.street_address,
                    facility.city,
                    facility.postal_code
                )
                if lat and lon:
                    facility.latitude = lat
                    facility.longitude = lon
            
            facility.save()
            form.save_m2m()  # Zapisz relacje many-to-many
            
            # Wyczyść cache statystyk
            cache.delete('home_stats')
            
            messages.success(
                request,
                'Placówka została pomyślnie dodana i jest już widoczna na stronie.'
            )
            return redirect('medical_facilities:facility_detail', slug=facility.slug)
        else:
            # Obsługa rate limiting
            if hasattr(request, 'limited'):
                messages.error(
                    request,
                    'Zbyt wiele prób dodania placówki. Spróbuj ponownie później.'
                )
    else:
        form = MedicalFacilityForm()
    
    context = {
        'form': form,
        'title': 'Dodaj nową placówkę',
        'voivodeships': Voivodeship.objects.all(),
        'facility_types': FacilityType.objects.all(),
        'therapy_types': TherapyType.objects.all(),
        'age_groups': AgeGroup.objects.all(),
    }
    return render(request, 'medical_facilities/add_facility.html', context)


@ratelimit(key='ip', rate='20/m', method='POST', block=True)
def add_rating(request, slug):
    """Dodawanie oceny placówki."""
    facility = get_object_or_404(MedicalFacility, slug=slug, status='approved')
    
    if request.method == 'POST':
        form = FacilityRatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.facility = facility
            rating.user = request.user if request.user.is_authenticated else None
            rating.status = 'approved'  # Automatyczne zatwierdzenie
            rating.save()
            
            # Wyczyść cache statystyk
            cache.delete('home_stats')
            cache.delete(f'facility_{facility.id}_stats')
            
            messages.success(request, 'Dziękujemy za ocenę!')
            
            return redirect('medical_facilities:facility_detail', slug=slug)
        else:
            # Obsługa rate limiting
            if hasattr(request, 'limited'):
                messages.error(
                    request,
                    'Zbyt wiele prób dodania oceny. Spróbuj ponownie później.'
                )
    
    # W przypadku błędu lub GET, przekieruj z powrotem do strony szczegółów placówki
    return redirect('medical_facilities:facility_detail', slug=slug)


# Funkcja dodawania zdjęć została usunięta w celu optymalizacji serwera


@ratelimit(key='ip', rate='5/m', method='POST', block=True)
@ratelimit(key='ip', rate='60/m', method='GET', block=False)
def contact(request):
    """Strona kontaktowa."""
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Tu można dodać logikę wysyłania emaila
            messages.success(
                request,
                'Dziękujemy za wiadomość. Odpowiemy najszybciej jak to możliwe.'
            )
            return redirect('medical_facilities:contact')
    else:
        form = ContactForm()
    
    context = {
        'form': form,
        'title': 'Kontakt'
    }
    return render(request, 'pages/contact.html', context)


def about(request):
    """Strona o nas."""
    context = {
        'title': 'O nas'
    }
    return render(request, 'pages/about.html', context)


def privacy_policy(request):
    """Strona polityki prywatności."""
    return render(request, 'pages/privacy.html', {
        'title': 'Polityka prywatności'
    })


@require_http_methods(["GET"])
@ratelimit(key='ip', rate='100/m', method='GET', block=True)
def api_facilities_search(request):
    """API endpoint do wyszukiwania placówek (dla AJAX)."""
    query = request.GET.get('query', '').strip()
    
    if len(query) < 2:
        return JsonResponse({'facilities': []})
    
    # Cache wyników wyszukiwania na 5 minut
    cache_key = f'search_{hash(query)}'
    cached_results = cache.get(cache_key)
    if cached_results is not None:
        return JsonResponse(cached_results)
    
    facilities = MedicalFacility.objects.filter(
        status='approved'
    ).filter(
        Q(name__icontains=query) |
        Q(city__icontains=query) |
        Q(street_address__icontains=query)
    ).values(
        'id', 'name', 'city', 'slug'
    )[:10]
    
    result = {'facilities': list(facilities)}
    cache.set(cache_key, result, 300)  # 5 minut
    
    return JsonResponse(result)


@require_http_methods(["GET"])
@ratelimit(key='ip', rate='100/m', method='GET', block=True)
def api_facility_coordinates(request, facility_id):
    """API endpoint do pobierania współrzędnych placówki."""
    try:
        facility = MedicalFacility.objects.get(
            id=facility_id,
            status='approved'
        )
        
        return JsonResponse({
            'latitude': float(facility.latitude) if facility.latitude else None,
            'longitude': float(facility.longitude) if facility.longitude else None,
            'name': facility.name,
            'address': facility.get_full_address()
        })
    except MedicalFacility.DoesNotExist:
        return JsonResponse({'error': 'Facility not found'}, status=404)


@ratelimit(key='ip', rate='60/m', method='GET', block=False)
def statistics(request):
    """Strona ze statystykami."""
    # Podstawowe statystyki
    total_facilities = MedicalFacility.objects.filter(status='approved').count()
    total_ratings = FacilityRating.objects.filter(status='approved').count()
    total_users = User.objects.filter(is_active=True).count()
    
    # Statystyki według województw
    voivodeship_stats = Voivodeship.objects.annotate(
        facility_count=Count('medicalfacility', filter=Q(medicalfacility__status='approved'))
    ).order_by('-facility_count')
    
    # Statystyki według typów placówek
    facility_type_stats = FacilityType.objects.annotate(
        facility_count=Count('medicalfacility', filter=Q(medicalfacility__status='approved'))
    ).order_by('-facility_count')
    
    # Statystyki według typów terapii
    therapy_type_stats = TherapyType.objects.annotate(
        facility_count=Count('medicalfacility', filter=Q(medicalfacility__status='approved'))
    ).order_by('-facility_count')[:10]
    
    context = {
        'title': 'Statystyki',
        'total_facilities': total_facilities,
        'total_ratings': total_ratings,
        'total_users': total_users,
        'voivodeship_stats': voivodeship_stats,
        'facility_type_stats': facility_type_stats,
        'therapy_type_stats': therapy_type_stats,
    }
    
    return render(request, 'medical_facilities/statistics.html', context)


@ratelimit(key='ip', rate='60/m', method='GET', block=False)
def facility_map_view(request):
    """Widok mapy placówek."""
    facilities = MedicalFacility.objects.filter(status='approved')
    
    context = {
        'facilities': facilities,
        'now': timezone.now(),
    }
    return render(request, 'medical_facilities/facility_map.html', context)


@ratelimit(key='ip', rate='100/m', method='GET', block=True)
def facility_map_data(request):
    """API endpoint zwracający dane placówek w formacie JSON dla mapy."""
    facilities = MedicalFacility.objects.filter(status='approved')
    facilities_data = []
    
    for facility in facilities:
        # Pobierz kategorie dla tej placówki
        facility_types = [ft.name for ft in facility.facility_types.all()]
        voivodeships = [facility.voivodeship.name] if facility.voivodeship else []
        
        facility_data = {
            'id': facility.id,
            'name': facility.name,
            'slug': facility.slug,
            'address_city': facility.city,
            'address_street': facility.street_address,
            'phone_number': facility.phone,
            'email': facility.email,
            'website': facility.website,
            'description': facility.description[:200] + '...' if facility.description and len(facility.description) > 200 else facility.description,
            'latitude': float(facility.latitude) if facility.latitude else None,
            'longitude': float(facility.longitude) if facility.longitude else None,
            'facility_types': facility_types,
            'voivodeships': voivodeships,
        }
        facilities_data.append(facility_data)
    
    return JsonResponse({'facilities': facilities_data})


# Security Error Handlers

def rate_limit_exceeded(request, exception=None):
    """
    Handler dla przekroczenia rate limitu.
    Wyświetla przyjazną stronę błędu 429 i loguje zdarzenie.
    """
    from .models import AuditLog, SecurityEvent
    from .middleware import PageVisitMiddleware
    
    ip_address = PageVisitMiddleware().get_client_ip(request)
    
    # Loguj do AuditLog
    try:
        AuditLog.objects.create(
            user=request.user if request.user.is_authenticated else None,
            ip_address=ip_address,
            action='RATE_LIMIT_EXCEEDED',
            model_name='',
            object_id='',
            request_path=request.path,
            request_method=request.method,
            user_agent=request.META.get('HTTP_USER_AGENT', ''),
            status_code=429,
            severity='WARNING',
            notes=f'Rate limit exceeded on {request.path}'
        )
    except Exception as e:
        logger.error(f"Failed to log rate limit exceeded: {str(e)}")
    
    # Sprawdź czy to wielokrotne przekroczenie (potencjalny atak)
    recent_violations = AuditLog.objects.filter(
        ip_address=ip_address,
        action='RATE_LIMIT_EXCEEDED',
        timestamp__gte=timezone.now() - timezone.timedelta(hours=1)
    ).count()
    
    # Jeśli więcej niż 5 przekroczeń w ciągu godziny, utwórz SecurityEvent
    if recent_violations >= 5:
        try:
            SecurityEvent.objects.get_or_create(
                event_type='RATE_LIMIT_ABUSE',
                ip_address=ip_address,
                resolved=False,
                defaults={
                    'user': request.user if request.user.is_authenticated else None,
                    'description': f'Multiple rate limit violations detected from IP {ip_address}. '
                                 f'Total violations in last hour: {recent_violations}',
                    'request_data': {
                        'path': request.path,
                        'method': request.method,
                        'user_agent': request.META.get('HTTP_USER_AGENT', ''),
                        'violations_count': recent_violations,
                    },
                    'severity': 'MEDIUM',
                    'action_taken': 'Logged and monitored'
                }
            )
        except Exception as e:
            logger.error(f"Failed to create security event: {str(e)}")
    
    return render(request, 'errors/rate_limit.html', {
        'message': 'Zbyt wiele żądań. Proszę spróbować ponownie za chwilę.',
    }, status=429)


def csrf_failure(request, reason=""):
    """
    Handler dla błędów CSRF.
    Wyświetla przyjazną stronę błędu 403.
    """
    return render(request, 'errors/csrf_failure.html', {
        'reason': reason,
        'message': 'Błąd weryfikacji bezpieczeństwa. Proszę odświeżyć stronę i spróbować ponownie.',
    }, status=403)



# Security Dashboard

@login_required
def security_dashboard(request):
    """
    Dashboard bezpieczeństwa dla administratorów.
    Wyświetla statystyki moderacji i bezpieczeństwa.
    """
    from django.contrib.admin.views.decorators import staff_member_required
    from datetime import timedelta
    from .models import AuditLog, SecurityEvent
    
    # Sprawdź czy użytkownik jest adminem
    if not request.user.is_staff:
        return redirect('medical_facilities:home')
    
    # Statystyki moderacji
    pending_facilities = MedicalFacility.objects.filter(status='pending').count()
    pending_ratings = FacilityRating.objects.filter(status='pending').count()
    approved_facilities_today = MedicalFacility.objects.filter(
        status='approved',
        created_at__gte=timezone.now() - timedelta(days=1)
    ).count()
    
    # Statystyki bezpieczeństwa (ostatnie 24h)
    last_24h = timezone.now() - timedelta(hours=24)
    last_7d = timezone.now() - timedelta(days=7)
    
    # Rate limiting
    rate_limit_violations = AuditLog.objects.filter(
        timestamp__gte=last_24h,
        action='RATE_LIMIT_EXCEEDED'
    ).count()
    
    blocked_ips_24h = AuditLog.objects.filter(
        timestamp__gte=last_24h,
        action='RATE_LIMIT_EXCEEDED'
    ).values('ip_address').distinct().count()
    
    # Nieudane logowania
    failed_logins = AuditLog.objects.filter(
        timestamp__gte=last_24h,
        action='LOGIN_FAILED'
    ).count()
    
    # Próby ataków
    xss_attempts = AuditLog.objects.filter(
        timestamp__gte=last_24h,
        action='XSS_ATTEMPT'
    ).count()
    
    sql_injection_attempts = AuditLog.objects.filter(
        timestamp__gte=last_24h,
        action='SQL_INJECTION_ATTEMPT'
    ).count()
    
    suspicious_activities = xss_attempts + sql_injection_attempts
    
    # Zdarzenia bezpieczeństwa
    unresolved_security_events = SecurityEvent.objects.filter(
        resolved=False
    ).count()
    
    critical_events = SecurityEvent.objects.filter(
        resolved=False,
        severity='CRITICAL'
    ).count()
    
    high_severity_events = SecurityEvent.objects.filter(
        resolved=False,
        severity='HIGH'
    ).count()
    
    # Ostatnie akcje (50 najnowszych)
    recent_actions = AuditLog.objects.select_related('user').order_by('-timestamp')[:50]
    
    # Ostatnie zdarzenia bezpieczeństwa (10 najnowszych)
    recent_security_events = SecurityEvent.objects.select_related(
        'user', 'resolved_by'
    ).order_by('-timestamp')[:10]
    
    # Statystyki akcji w ostatnim tygodniu (dla wykresu)
    actions_by_day = []
    for i in range(7):
        day_start = timezone.now() - timedelta(days=i+1)
        day_end = timezone.now() - timedelta(days=i)
        count = AuditLog.objects.filter(
            timestamp__gte=day_start,
            timestamp__lt=day_end
        ).count()
        actions_by_day.append({
            'date': day_start.strftime('%Y-%m-%d'),
            'count': count
        })
    actions_by_day.reverse()
    
    # Top 10 IP adresów z największą aktywnością
    top_ips = AuditLog.objects.filter(
        timestamp__gte=last_7d
    ).values('ip_address').annotate(
        count=Count('id')
    ).order_by('-count')[:10]
    
    # Statystyki typów akcji
    action_stats = AuditLog.objects.filter(
        timestamp__gte=last_7d
    ).values('action').annotate(
        count=Count('id')
    ).order_by('-count')[:10]
    
    context = {
        'title': 'Dashboard Bezpieczeństwa',
        # Moderacja
        'pending_facilities': pending_facilities,
        'pending_ratings': pending_ratings,
        'approved_facilities_today': approved_facilities_today,
        # Bezpieczeństwo
        'rate_limit_violations': rate_limit_violations,
        'blocked_ips_24h': blocked_ips_24h,
        'failed_logins': failed_logins,
        'suspicious_activities': suspicious_activities,
        'xss_attempts': xss_attempts,
        'sql_injection_attempts': sql_injection_attempts,
        # Zdarzenia
        'unresolved_security_events': unresolved_security_events,
        'critical_events': critical_events,
        'high_severity_events': high_severity_events,
        # Listy
        'recent_actions': recent_actions,
        'recent_security_events': recent_security_events,
        'actions_by_day': actions_by_day,
        'top_ips': top_ips,
        'action_stats': action_stats,
    }
    
    return render(request, 'admin/security_dashboard.html', context)
