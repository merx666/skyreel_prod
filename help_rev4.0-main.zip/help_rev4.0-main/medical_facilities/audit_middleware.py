"""
Middleware do audytu i logowania wszystkich akcji w systemie.
"""
from django.utils.deprecation import MiddlewareMixin
from django.utils import timezone
import logging
import json

logger = logging.getLogger('security')


class AuditLogMiddleware(MiddlewareMixin):
    """
    Middleware rejestrujący wszystkie akcje użytkowników w systemie.
    Loguje szczegóły requestów, odpowiedzi i potencjalne zagrożenia bezpieczeństwa.
    """
    
    # Ścieżki, które nie powinny być logowane (aby nie zaśmiecać logów)
    EXCLUDED_PATHS = [
        '/static/',
        '/media/',
        '/favicon.ico',
        '/jsi18n/',
    ]
    
    # Metody HTTP, które zawsze logujemy (modyfikujące dane)
    IMPORTANT_METHODS = ['POST', 'PUT', 'PATCH', 'DELETE']
    
    def process_request(self, request):
        """Przygotowuje dane requestu do logowania."""
        # Zapisz czas rozpoczęcia requestu
        request._audit_start_time = timezone.now()
        return None
    
    def process_response(self, request, response):
        """Loguje szczegóły requestu i odpowiedzi."""
        # Pomiń wykluczone ścieżki
        path = request.path
        if any(path.startswith(excluded) for excluded in self.EXCLUDED_PATHS):
            return response
        
        # Loguj tylko ważne metody lub błędy
        method = request.method
        status_code = response.status_code
        
        should_log = (
            method in self.IMPORTANT_METHODS or
            status_code >= 400 or
            path.startswith('/admin/')
        )
        
        if not should_log:
            return response
        
        # Przygotuj dane do logowania
        try:
            user = request.user if hasattr(request, 'user') else None
            ip_address = self.get_client_ip(request)
            user_agent = request.META.get('HTTP_USER_AGENT', '')[:500]
            
            # Określ poziom logowania na podstawie status code
            if status_code >= 500:
                log_level = 'ERROR'
                severity = 'ERROR'
            elif status_code >= 400:
                log_level = 'WARNING'
                severity = 'WARNING'
            else:
                log_level = 'INFO'
                severity = 'INFO'
            
            # Przygotuj wiadomość logowania
            log_message = self._format_log_message(
                request, response, user, ip_address, user_agent, severity
            )
            
            # Loguj do odpowiedniego poziomu
            if log_level == 'ERROR':
                logger.error(log_message)
            elif log_level == 'WARNING':
                logger.warning(log_message)
            else:
                logger.info(log_message)
            
            # Dla requestów modyfikujących dane w panelu admin, zapisz do bazy
            # (to będzie zaimplementowane w kolejnym tasku z modelem AuditLog)
            if path.startswith('/admin/') and method in self.IMPORTANT_METHODS:
                self._save_audit_log(request, response, user, ip_address, user_agent)
        
        except Exception as e:
            # Nie przerywaj requestu jeśli logowanie się nie powiedzie
            logger.error(f"Error in AuditLogMiddleware: {str(e)}")
        
        return response
    
    def _format_log_message(self, request, response, user, ip_address, user_agent, severity):
        """Formatuje wiadomość logowania."""
        user_str = str(user) if user and user.is_authenticated else 'Anonymous'
        
        return (
            f"[{severity}] {request.method} {request.path} | "
            f"User: {user_str} | IP: {ip_address} | "
            f"Status: {response.status_code} | "
            f"UA: {user_agent[:100]}"
        )
    
    def _save_audit_log(self, request, response, user, ip_address, user_agent):
        """
        Zapisuje log audytu do bazy danych.
        """
        try:
            from .models import AuditLog
            
            # Określ akcję na podstawie metody HTTP
            action_map = {
                'POST': 'CREATE',
                'PUT': 'UPDATE',
                'PATCH': 'UPDATE',
                'DELETE': 'DELETE',
                'GET': 'VIEW',
            }
            action = action_map.get(request.method, 'VIEW')
            
            # Określ severity na podstawie status code
            if response.status_code >= 500:
                severity = 'ERROR'
            elif response.status_code >= 400:
                severity = 'WARNING'
            else:
                severity = 'INFO'
            
            AuditLog.objects.create(
                user=user if user and user.is_authenticated else None,
                ip_address=ip_address,
                action=action,
                model_name='',  # Będzie wypełnione w widokach
                object_id='',
                object_repr='',
                request_path=request.path,
                request_method=request.method,
                user_agent=user_agent,
                status_code=response.status_code,
                severity=severity,
            )
        except Exception as e:
            logger.error(f"Failed to save audit log: {str(e)}")
    
    def get_client_ip(self, request):
        """Pobiera adres IP klienta z request."""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR', 'unknown')
        return ip
    
    def process_exception(self, request, exception):
        """Loguje wyjątki."""
        try:
            user = request.user if hasattr(request, 'user') else None
            user_str = str(user) if user and user.is_authenticated else 'Anonymous'
            ip_address = self.get_client_ip(request)
            
            logger.error(
                f"[EXCEPTION] {request.method} {request.path} | "
                f"User: {user_str} | IP: {ip_address} | "
                f"Exception: {type(exception).__name__}: {str(exception)}"
            )
        except Exception:
            pass
        
        return None
