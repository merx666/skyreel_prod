from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.conf import settings
from .models import (
    MedicalFacility, FacilityRating, FacilityImage,
    Voivodeship, AddictionType, FacilityType, TherapyType, AgeGroup
)
from .security_utils import InputSanitizer, create_security_event_from_attack
from django_recaptcha.fields import ReCaptchaField
from django_recaptcha.widgets import ReCaptchaV2Checkbox
import re
import logging

logger = logging.getLogger('security')


class MedicalFacilityForm(forms.ModelForm):
    """Formularz do dodawania nowych placówek medycznych."""
    
    # Add reCAPTCHA field (only if keys are configured)
    if settings.RECAPTCHA_PUBLIC_KEY and settings.RECAPTCHA_PRIVATE_KEY:
        captcha = ReCaptchaField(
            widget=ReCaptchaV2Checkbox(
                attrs={
                    'data-theme': 'light',
                    'data-size': 'normal',
                }
            ),
            label='Weryfikacja'
        )
    
    class Meta:
        model = MedicalFacility
        fields = [
            'name', 'description', 'street_address', 'city', 'postal_code',
            'voivodeship', 'phone', 'email', 'website', 'facility_types',
            'therapy_types', 'age_groups', 'is_public',
            'is_private', 'has_emergency_service', 'accepts_nfz', 'opening_hours'
        ]
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nazwa placówki medycznej'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Opis placówki, oferowane usługi, specjalizacje...'
            }),
            'street_address': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'ul. Przykładowa 123'
            }),
            'city': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Warszawa'
            }),
            'postal_code': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '00-000'
            }),
            'voivodeship': forms.Select(attrs={
                'class': 'form-select'
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '+48 123 456 789'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'kontakt@placowka.pl'
            }),
            'website': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://www.placowka.pl'
            }),
            'facility_types': forms.CheckboxSelectMultiple(attrs={
                'class': 'form-check-input'
            }),
            'therapy_types': forms.CheckboxSelectMultiple(attrs={
                'class': 'form-check-input'
            }),
            'age_groups': forms.CheckboxSelectMultiple(attrs={
                'class': 'form-check-input'
            }),
            'is_public': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'is_private': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'has_emergency_service': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'accepts_nfz': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'opening_hours': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Pon-Pt: 8:00-16:00\nSob: 9:00-14:00\nNiedz: zamknięte'
            }),
        }
        labels = {
            'name': 'Nazwa placówki *',
            'description': 'Opis placówki',
            'street_address': 'Ulica i numer *',
            'city': 'Miasto *',
            'postal_code': 'Kod pocztowy',
            'voivodeship': 'Województwo *',
            'phone': 'Telefon',
            'email': 'Email',
            'website': 'Strona internetowa',
            'facility_types': 'Typy placówek *',
            'therapy_types': 'Typy terapii',
            'age_groups': 'Grupy wiekowe',
            'is_public': 'Placówka publiczna',
            'is_private': 'Placówka prywatna',
            'has_emergency_service': 'Służba ratunkowa',
            'accepts_nfz': 'Przyjmuje NFZ',
            'opening_hours': 'Godziny otwarcia',
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Oznacz wymagane pola
        required_fields = ['name', 'street_address', 'city', 'postal_code', 'voivodeship', 'facility_types']
        for field_name in required_fields:
            if field_name in self.fields:
                self.fields[field_name].required = True
    
    def clean_name(self):
        """Walidacja i sanityzacja nazwy placówki."""
        name = self.cleaned_data.get('name')
        if name:
            # Wykryj próby XSS
            if InputSanitizer.detect_xss_attempt(name):
                logger.warning(f"XSS attempt detected in facility name: {name}")
                raise ValidationError('Nazwa zawiera niedozwolone znaki lub kod.')
            
            # Wykryj próby SQL Injection
            if InputSanitizer.detect_sql_injection_attempt(name):
                logger.warning(f"SQL Injection attempt detected in facility name: {name}")
                raise ValidationError('Nazwa zawiera niedozwolone znaki.')
            
            # Usuń wszystkie tagi HTML
            name = InputSanitizer.strip_all_html(name)
            
            # Waliduj długość
            InputSanitizer.validate_text_length(name, 200, "Nazwa placówki")
        
        return name
    
    def clean_description(self):
        """Sanityzacja opisu placówki."""
        description = self.cleaned_data.get('description')
        if description:
            # Wykryj próby XSS
            if InputSanitizer.detect_xss_attempt(description):
                logger.warning(f"XSS attempt detected in facility description")
                raise ValidationError('Opis zawiera niedozwolone tagi lub kod.')
            
            # Sanityzuj HTML - dozwól tylko bezpieczne tagi
            description = InputSanitizer.sanitize_html(description)
            
            # Waliduj długość
            InputSanitizer.validate_text_length(description, 2000, "Opis")
        
        return description
    
    def clean_postal_code(self):
        """Walidacja kodu pocztowego."""
        postal_code = self.cleaned_data.get('postal_code')
        if postal_code:
            try:
                postal_code = InputSanitizer.validate_postal_code(postal_code)
            except ValidationError as e:
                raise ValidationError(str(e))
        return postal_code
    
    def clean_phone(self):
        """Walidacja numeru telefonu."""
        phone = self.cleaned_data.get('phone')
        if phone:
            try:
                phone = InputSanitizer.validate_phone(phone)
            except ValidationError as e:
                raise ValidationError(str(e))
        return phone
    
    def clean_email(self):
        """Walidacja adresu email."""
        email = self.cleaned_data.get('email')
        if email:
            try:
                InputSanitizer.validate_email(email)
            except ValidationError as e:
                raise ValidationError(str(e))
        return email
    
    def clean_website(self):
        """Walidacja adresu strony internetowej."""
        website = self.cleaned_data.get('website')
        if website:
            try:
                InputSanitizer.validate_url(website)
            except ValidationError as e:
                raise ValidationError(str(e))
        return website
    
    def clean_city(self):
        """Walidacja i sanityzacja nazwy miasta."""
        city = self.cleaned_data.get('city')
        if city:
            # Wykryj próby ataków
            if InputSanitizer.detect_xss_attempt(city) or InputSanitizer.detect_sql_injection_attempt(city):
                raise ValidationError('Nazwa miasta zawiera niedozwolone znaki.')
            
            # Usuń HTML
            city = InputSanitizer.strip_all_html(city)
            InputSanitizer.validate_text_length(city, 100, "Nazwa miasta")
        
        return city
    
    def clean_street_address(self):
        """Walidacja i sanityzacja adresu."""
        address = self.cleaned_data.get('street_address')
        if address:
            # Wykryj próby ataków
            if InputSanitizer.detect_xss_attempt(address) or InputSanitizer.detect_sql_injection_attempt(address):
                raise ValidationError('Adres zawiera niedozwolone znaki.')
            
            # Usuń HTML
            address = InputSanitizer.strip_all_html(address)
            InputSanitizer.validate_text_length(address, 200, "Adres")
        
        return address
    
    def clean_opening_hours(self):
        """Sanityzacja godzin otwarcia."""
        hours = self.cleaned_data.get('opening_hours')
        if hours:
            # Usuń HTML
            hours = InputSanitizer.strip_all_html(hours)
            InputSanitizer.validate_text_length(hours, 500, "Godziny otwarcia")
        
        return hours
    
    def clean(self):
        cleaned_data = super().clean()
        is_public = cleaned_data.get('is_public')
        is_private = cleaned_data.get('is_private')
        
        # Sprawdź czy wybrano przynajmniej jeden typ placówki (publiczna/prywatna)
        if not is_public and not is_private:
            raise ValidationError('Wybierz przynajmniej jeden typ placówki (publiczna lub prywatna)')
        
        return cleaned_data


class FacilityRatingForm(forms.ModelForm):
    """Formularz do dodawania ocen placówek."""
    
    # Add reCAPTCHA field (only if keys are configured)
    if settings.RECAPTCHA_PUBLIC_KEY and settings.RECAPTCHA_PRIVATE_KEY:
        captcha = ReCaptchaField(
            widget=ReCaptchaV2Checkbox(
                attrs={
                    'data-theme': 'light',
                    'data-size': 'normal',
                }
            ),
            label='Weryfikacja'
        )
    
    class Meta:
        model = FacilityRating
        fields = ['overall_rating', 'staff_rating', 'facilities_rating', 'treatment_rating', 'rules_rating', 'atmosphere_rating', 'comment']
        widgets = {
            'overall_rating': forms.Select(
                choices=[(i, f'{i} ⭐') for i in range(1, 6)],
                attrs={'class': 'form-select'}
            ),
            'staff_rating': forms.Select(
                choices=[(None, 'Nie oceniam')] + [(i, f'{i} ⭐') for i in range(1, 6)],
                attrs={'class': 'form-select'}
            ),
            'facilities_rating': forms.Select(
                choices=[(None, 'Nie oceniam')] + [(i, f'{i} ⭐') for i in range(1, 6)],
                attrs={'class': 'form-select'}
            ),
            'treatment_rating': forms.Select(
                choices=[(None, 'Nie oceniam')] + [(i, f'{i} ⭐') for i in range(1, 6)],
                attrs={'class': 'form-select'}
            ),
            'rules_rating': forms.Select(
                choices=[(None, 'Nie oceniam')] + [(i, f'{i} ⭐') for i in range(1, 6)],
                attrs={'class': 'form-select'}
            ),
            'atmosphere_rating': forms.Select(
                choices=[(None, 'Nie oceniam')] + [(i, f'{i} ⭐') for i in range(1, 6)],
                attrs={'class': 'form-select'}
            ),
            'comment': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Podziel się swoimi doświadczeniami z placówką...'
            }),
        }
        labels = {
            'overall_rating': 'Ocena ogólna *',
            'staff_rating': 'Ocena personelu',
            'facilities_rating': 'Ocena wyposażenia (baza materialna)',
            'treatment_rating': 'Ocena leczenia (jakość pomocy)',
            'rules_rating': 'Ocena zasad i wymagań',
            'atmosphere_rating': 'Ocena atmosfery',
            'comment': 'Komentarz',
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['overall_rating'].required = True
    
    def clean_comment(self):
        """Walidacja i sanityzacja komentarza."""
        comment = self.cleaned_data.get('comment')
        if comment:
            # Wykryj próby XSS
            if InputSanitizer.detect_xss_attempt(comment):
                logger.warning(f"XSS attempt detected in rating comment")
                raise ValidationError('Komentarz zawiera niedozwolone tagi lub kod.')
            
            # Wykryj próby SQL Injection
            if InputSanitizer.detect_sql_injection_attempt(comment):
                logger.warning(f"SQL Injection attempt detected in rating comment")
                raise ValidationError('Komentarz zawiera niedozwolone znaki.')
            
            # Sanityzuj HTML - dozwól tylko podstawowe formatowanie
            comment = InputSanitizer.sanitize_html(
                comment,
                allowed_tags=['p', 'br', 'strong', 'em'],
                allowed_attributes={}
            )
            
            # Sprawdź długość komentarza
            if len(comment) < 10:
                raise ValidationError('Komentarz musi mieć przynajmniej 10 znaków')
            
            InputSanitizer.validate_text_length(comment, 1000, "Komentarz")
        
        return comment


# Formularz do dodawania zdjęć został usunięty w celu optymalizacji serwera


class FacilitySearchForm(forms.Form):
    """Formularz wyszukiwania placówek."""
    
    query = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Wyszukaj placówkę po nazwie lub mieście...',
            'autocomplete': 'off'
        }),
        label='Wyszukaj'
    )
    
    def clean_query(self):
        """Walidacja i sanityzacja zapytania wyszukiwania."""
        query = self.cleaned_data.get('query')
        if query:
            # Wykryj próby SQL Injection
            if InputSanitizer.detect_sql_injection_attempt(query):
                logger.warning(f"SQL Injection attempt detected in search query: {query}")
                raise ValidationError('Zapytanie zawiera niedozwolone znaki.')
            
            # Wykryj próby XSS
            if InputSanitizer.detect_xss_attempt(query):
                logger.warning(f"XSS attempt detected in search query: {query}")
                raise ValidationError('Zapytanie zawiera niedozwolone znaki.')
            
            # Usuń HTML
            query = InputSanitizer.strip_all_html(query)
            
            # Sanityzuj dla LIKE queries
            query = InputSanitizer.sanitize_sql_like(query)
            
            InputSanitizer.validate_text_length(query, 200, "Zapytanie")
        
        return query
    
    voivodeship = forms.ModelChoiceField(
        queryset=Voivodeship.objects.all(),
        required=False,
        empty_label='Wszystkie województwa',
        widget=forms.Select(attrs={'class': 'form-select'}),
        label='Województwo'
    )
    
    facility_type = forms.ModelChoiceField(
        queryset=FacilityType.objects.all(),
        required=False,
        empty_label='Wszystkie typy placówek',
        widget=forms.Select(attrs={'class': 'form-select'}),
        label='Typ placówki'
    )
    

    
    accepts_nfz = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label='Tylko placówki NFZ'
    )
    
    has_emergency_service = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label='Tylko ze służbą ratunkową'
    )


class ContactForm(forms.Form):
    """Formularz kontaktowy."""
    
    # Add reCAPTCHA field (only if keys are configured)
    if settings.RECAPTCHA_PUBLIC_KEY and settings.RECAPTCHA_PRIVATE_KEY:
        captcha = ReCaptchaField(
            widget=ReCaptchaV2Checkbox(
                attrs={
                    'data-theme': 'light',
                    'data-size': 'normal',
                }
            ),
            label='Weryfikacja'
        )
    
    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Twoje imię i nazwisko'
        }),
        label='Imię i nazwisko *'
    )
    
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'twoj@email.pl'
        }),
        label='Email *'
    )
    
    subject = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Temat wiadomości'
        }),
        label='Temat *'
    )
    
    message = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 5,
            'placeholder': 'Treść wiadomości...'
        }),
        label='Wiadomość *'
    )
    
    def clean_name(self):
        """Walidacja i sanityzacja imienia."""
        name = self.cleaned_data.get('name')
        if name:
            # Wykryj próby ataków
            if InputSanitizer.detect_xss_attempt(name) or InputSanitizer.detect_sql_injection_attempt(name):
                raise ValidationError('Imię zawiera niedozwolone znaki.')
            
            name = InputSanitizer.strip_all_html(name)
            InputSanitizer.validate_text_length(name, 100, "Imię i nazwisko")
        
        return name
    
    def clean_subject(self):
        """Walidacja i sanityzacja tematu."""
        subject = self.cleaned_data.get('subject')
        if subject:
            # Wykryj próby ataków
            if InputSanitizer.detect_xss_attempt(subject) or InputSanitizer.detect_sql_injection_attempt(subject):
                raise ValidationError('Temat zawiera niedozwolone znaki.')
            
            subject = InputSanitizer.strip_all_html(subject)
            InputSanitizer.validate_text_length(subject, 200, "Temat")
        
        return subject
    
    def clean_message(self):
        """Walidacja i sanityzacja wiadomości."""
        message = self.cleaned_data.get('message')
        if message:
            # Wykryj próby XSS
            if InputSanitizer.detect_xss_attempt(message):
                logger.warning(f"XSS attempt detected in contact form message")
                raise ValidationError('Wiadomość zawiera niedozwolone tagi lub kod.')
            
            # Wykryj próby SQL Injection
            if InputSanitizer.detect_sql_injection_attempt(message):
                logger.warning(f"SQL Injection attempt detected in contact form message")
                raise ValidationError('Wiadomość zawiera niedozwolone znaki.')
            
            # Sanityzuj HTML
            message = InputSanitizer.sanitize_html(
                message,
                allowed_tags=['p', 'br'],
                allowed_attributes={}
            )
            
            if len(message) < 20:
                raise ValidationError('Wiadomość musi mieć przynajmniej 20 znaków')
            
            InputSanitizer.validate_text_length(message, 2000, "Wiadomość")
        
        return message