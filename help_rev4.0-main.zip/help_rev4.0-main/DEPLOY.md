# Instrukcje Wdrożenia - Hyperreal Help

## Przygotowanie do Produkcji

### 1. Wymagania Systemowe
- Python 3.9+
- PostgreSQL 12+
- Redis 6+
- Nginx (opcjonalnie)
- Supervisor lub systemd (do zarządzania procesami)

### 2. Instalacja Zależności
```bash
pip install -r requirements.txt
```

### 3. Konfiguracja Zmiennych Środowiskowych
Skopiuj plik `.env.example` do `.env` i uzupełnij odpowiednie wartości:
```bash
cp .env.example .env
```

Ważne zmienne do skonfigurowania:
- `SECRET_KEY` - unikalny klucz bezpieczeństwa Django
- `ALLOWED_HOSTS` - domeny, na których będzie działać aplikacja
- `DB_*` - dane dostępowe do bazy PostgreSQL
- `EMAIL_*` - konfiguracja SMTP do wysyłania emaili
- `REDIS_URL` - URL do serwera Redis

### 4. Przygotowanie Bazy Danych
```bash
# Utworzenie migracji
python manage.py makemigrations

# Zastosowanie migracji
python manage.py migrate

# Utworzenie superużytkownika
python manage.py createsuperuser

# Zebranie plików statycznych
python manage.py collectstatic --noinput
```

### 5. Uruchomienie z Ustawieniami Produkcyjnymi
```bash
# Używając Gunicorn
gunicorn --env DJANGO_SETTINGS_MODULE=hyperreal_help.production_settings hyperreal_help.wsgi:application

# Lub używając manage.py
DJANGO_SETTINGS_MODULE=hyperreal_help.production_settings python manage.py runserver
```

### 6. Konfiguracja Nginx (Opcjonalnie)
Przykładowa konfiguracja Nginx:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    location /static/ {
        alias /path/to/your/project/staticfiles/;
    }
    
    location /media/ {
        alias /path/to/your/project/media/;
    }
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 7. Bezpieczeństwo
- Upewnij się, że `DEBUG = False` w produkcji
- Skonfiguruj HTTPS i odpowiednie nagłówki bezpieczeństwa
- Regularnie aktualizuj zależności
- Monitoruj logi aplikacji

### 8. Backup
Regularnie twórz kopie zapasowe:
- Bazy danych PostgreSQL
- Plików media (zdjęcia placówek)
- Plików konfiguracyjnych

### 9. Monitorowanie
- Skonfiguruj monitoring aplikacji
- Sprawdzaj logi w katalogu `logs/`
- Monitoruj wykorzystanie zasobów

## Struktura Projektu po Czyszczeniu
```
hyperreal_new_help/
├── authentication/          # Aplikacja uwierzytelniania
├── hyperreal_help/         # Główne ustawienia Django
│   ├── settings.py         # Ustawienia deweloperskie
│   └── production_settings.py  # Ustawienia produkcyjne
├── medical_facilities/     # Główna aplikacja
├── media/                  # Pliki przesłane przez użytkowników
├── static/                 # Pliki statyczne
├── staticfiles/           # Zebrane pliki statyczne
├── templates/             # Szablony HTML
├── .env.example           # Przykład zmiennych środowiskowych
├── .gitignore            # Pliki ignorowane przez Git
├── DEPLOY.md             # Ten plik
├── README.md             # Dokumentacja projektu
├── requirements.txt      # Zależności Python
└── manage.py            # Skrypt zarządzania Django
```

## Wsparcie
W przypadku problemów z wdrożeniem, sprawdź:
1. Logi aplikacji w katalogu `logs/`
2. Logi serwera WWW
3. Status usług (PostgreSQL, Redis)
4. Konfigurację zmiennych środowiskowych