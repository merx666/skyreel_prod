# Production Setup Guide - Hyperreal Help

## Przygotowanie do Wdrożenia Produkcyjnego

Ten dokument opisuje kroki niezbędne do bezpiecznego wdrożenia aplikacji Hyperreal Help na środowisko produkcyjne.

## 1. Zmienne Środowiskowe

Utwórz plik `.env` w głównym katalogu projektu (obok `manage.py`):

```bash
# Django Core Settings
SECRET_KEY=your-very-long-random-secret-key-min-50-characters-here
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com

# Database (PostgreSQL recommended for production)
DATABASE_URL=postgresql://user:password@localhost:5432/hyperreal_help

# Legacy Database (MySQL)
LEGACY_DB_NAME=legacy_hyperreal
LEGACY_DB_USER=db_user
LEGACY_DB_PASSWORD=strong_password_here
LEGACY_DB_HOST=localhost
LEGACY_DB_PORT=3306

# Redis Configuration
REDIS_URL=redis://127.0.0.1:6379/0
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_DB=0

# Security Settings (PRODUCTION)
SECURE_SSL_REDIRECT=True
SESSION_COOKIE_SECURE=True
CSRF_COOKIE_SECURE=True
SECURE_HSTS_SECONDS=31536000

# reCAPTCHA (Get keys from: https://www.google.com/recaptcha/admin)
RECAPTCHA_PUBLIC_KEY=your-recaptcha-site-key
RECAPTCHA_PRIVATE_KEY=your-recaptcha-secret-key

# Email Settings (for alerts and notifications)
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password

# Site URL (for email links)
SITE_URL=https://yourdomain.com

# Hyperreal One Integration (future)
HYPERREAL_ONE_API_URL=
HYPERREAL_ONE_API_KEY=
HYPERREAL_ONE_ENABLED=False
```

## 2. Generowanie SECRET_KEY

Wygeneruj bezpieczny SECRET_KEY:

```python
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

## 3. Instalacja Zależności

```bash
# Utwórz virtual environment
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# lub
venv\Scripts\activate  # Windows

# Zainstaluj zależności
pip install -r requirements.txt
```

## 4. Konfiguracja Bazy Danych

### PostgreSQL (Zalecane dla produkcji)

```bash
# Zainstaluj PostgreSQL
sudo apt-get install postgresql postgresql-contrib  # Ubuntu/Debian
# lub
brew install postgresql  # macOS

# Utwórz bazę danych
sudo -u postgres psql
CREATE DATABASE hyperreal_help;
CREATE USER hyperreal_user WITH PASSWORD 'strong_password';
GRANT ALL PRIVILEGES ON DATABASE hyperreal_help TO hyperreal_user;
\q

# Dodaj do requirements.txt
echo "psycopg2-binary>=2.9.0" >> requirements.txt
pip install psycopg2-binary
```

## 5. Konfiguracja Redis

```bash
# Zainstaluj Redis
sudo apt-get install redis-server  # Ubuntu/Debian
# lub
brew install redis  # macOS

# Uruchom Redis
sudo systemctl start redis  # Linux
# lub
brew services start redis  # macOS

# Sprawdź czy działa
redis-cli ping  # Powinno zwrócić: PONG
```

## 6. Migracje Bazy Danych

```bash
python manage.py makemigrations
python manage.py migrate
```

## 7. Utworzenie Superusera

```bash
python manage.py createsuperuser
```

## 8. Zbieranie Plików Statycznych

```bash
python manage.py collectstatic --noinput
```

## 9. Sprawdzenie Konfiguracji

```bash
# Sprawdź konfigurację deployment
python manage.py check --deploy

# Powinno pokazać ostrzeżenia tylko jeśli coś jest źle skonfigurowane
```

## 10. Konfiguracja Serwera WWW

### Nginx + Gunicorn (Zalecane)

#### Instalacja Gunicorn

```bash
pip install gunicorn
```

#### Konfiguracja Gunicorn

Utwórz plik `gunicorn_config.py`:

```python
bind = "127.0.0.1:8000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
errorlog = "/var/log/hyperreal_help/gunicorn_error.log"
accesslog = "/var/log/hyperreal_help/gunicorn_access.log"
loglevel = "info"
```

#### Konfiguracja Nginx

Utwórz plik `/etc/nginx/sites-available/hyperreal_help`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Static files
    location /static/ {
        alias /path/to/hyperreal_new_help/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # Media files
    location /media/ {
        alias /path/to/hyperreal_new_help/media/;
        expires 7d;
    }
    
    # Proxy to Gunicorn
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_redirect off;
    }
    
    # Rate limiting
    limit_req_zone $binary_remote_addr zone=general:10m rate=10r/s;
    limit_req zone=general burst=20 nodelay;
}
```

#### Aktywacja konfiguracji

```bash
sudo ln -s /etc/nginx/sites-available/hyperreal_help /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 11. SSL/TLS (Let's Encrypt)

```bash
# Zainstaluj Certbot
sudo apt-get install certbot python3-certbot-nginx

# Uzyskaj certyfikat
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Automatyczne odnawianie
sudo certbot renew --dry-run
```

## 12. Systemd Service

Utwórz plik `/etc/systemd/system/hyperreal_help.service`:

```ini
[Unit]
Description=Hyperreal Help Gunicorn Service
After=network.target

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/path/to/hyperreal_new_help
Environment="PATH=/path/to/hyperreal_new_help/venv/bin"
ExecStart=/path/to/hyperreal_new_help/venv/bin/gunicorn \
    --config /path/to/hyperreal_new_help/gunicorn_config.py \
    hyperreal_help.wsgi:application
ExecReload=/bin/kill -s HUP $MAINPID
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

Aktywuj service:

```bash
sudo systemctl daemon-reload
sudo systemctl start hyperreal_help
sudo systemctl enable hyperreal_help
sudo systemctl status hyperreal_help
```

## 13. Monitoring i Logi

### Rotacja Logów

Utwórz plik `/etc/logrotate.d/hyperreal_help`:

```
/var/log/hyperreal_help/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        systemctl reload hyperreal_help > /dev/null 2>&1 || true
    endscript
}
```

### Monitoring

Sprawdzaj regularnie:
- Dashboard bezpieczeństwa: `/admin/security-dashboard/`
- Logi audytu: `/admin/medical_facilities/auditlog/`
- Zdarzenia bezpieczeństwa: `/admin/medical_facilities/securityevent/`
- Logi systemowe: `/var/log/hyperreal_help/`

## 14. Backup

### Backup Bazy Danych

```bash
# PostgreSQL
pg_dump -U hyperreal_user hyperreal_help > backup_$(date +%Y%m%d).sql

# Automatyczny backup (cron)
0 2 * * * pg_dump -U hyperreal_user hyperreal_help > /backups/hyperreal_$(date +\%Y\%m\%d).sql
```

### Backup Plików

```bash
# Media files
tar -czf media_backup_$(date +%Y%m%d).tar.gz media/

# Całość
tar -czf full_backup_$(date +%Y%m%d).tar.gz \
    --exclude='venv' \
    --exclude='*.pyc' \
    --exclude='__pycache__' \
    /path/to/hyperreal_new_help/
```

## 15. Security Checklist

- [ ] DEBUG=False w .env
- [ ] SECRET_KEY jest długi i losowy (min 50 znaków)
- [ ] ALLOWED_HOSTS zawiera tylko Twoje domeny
- [ ] SSL/TLS skonfigurowane (HTTPS)
- [ ] SECURE_SSL_REDIRECT=True
- [ ] SECURE_HSTS_SECONDS=31536000
- [ ] SESSION_COOKIE_SECURE=True
- [ ] CSRF_COOKIE_SECURE=True
- [ ] Redis działa i jest zabezpieczony
- [ ] PostgreSQL używa silnych haseł
- [ ] Firewall skonfigurowany (tylko porty 80, 443, 22)
- [ ] reCAPTCHA skonfigurowane
- [ ] Email alerts działają
- [ ] Backup automatyczny skonfigurowany
- [ ] Logi są rotowane
- [ ] Monitoring działa

## 16. Performance Optimization

### Database Indexing

Wszystkie ważne indeksy są już utworzone w modelach (AuditLog, SecurityEvent).

### Caching

Redis jest już skonfigurowany dla:
- Rate limiting
- Session storage
- General caching

### Static Files

Użyj CDN dla plików statycznych (opcjonalnie):
```python
# settings.py
STATIC_URL = 'https://cdn.yourdomain.com/static/'
```

## 17. Troubleshooting

### Sprawdź logi

```bash
# Gunicorn logs
tail -f /var/log/hyperreal_help/gunicorn_error.log

# Nginx logs
tail -f /var/log/nginx/error.log

# Django logs
tail -f /path/to/hyperreal_new_help/logs/django.log
tail -f /path/to/hyperreal_new_help/logs/security.log

# Systemd logs
journalctl -u hyperreal_help -f
```

### Restart Services

```bash
sudo systemctl restart hyperreal_help
sudo systemctl restart nginx
sudo systemctl restart redis
```

## 18. Updates

```bash
# Pull latest code
git pull origin main

# Install dependencies
pip install -r requirements.txt

# Run migrations
python manage.py migrate

# Collect static files
python manage.py collectstatic --noinput

# Restart service
sudo systemctl restart hyperreal_help
```

## Support

Jeśli masz problemy:
1. Sprawdź logi (punkt 17)
2. Sprawdź Dashboard Bezpieczeństwa
3. Sprawdź Security Events
4. Sprawdź Audit Logs

---

**Gratulacje!** Twoja aplikacja Hyperreal Help jest teraz bezpiecznie wdrożona na produkcji! 🎉
