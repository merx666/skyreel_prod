from django.urls import path
from . import views

app_name = 'authentication'

urlpatterns = [
    # Podstawowe funkcje uwierzytelniania
    path('rejestracja/', views.register, name='register'),
    path('logowanie/', views.user_login, name='login'),
    path('wylogowanie/', views.user_logout, name='logout'),
    
    # Profil użytkownika
    path('profil/', views.profile, name='profile'),
    path('profil/edytuj/', views.edit_profile, name='edit_profile'),
    path('profil/zmien-haslo/', views.change_password, name='change_password'),
    path('profil/usun-konto/', views.delete_account, name='delete_account'),
    
    # Resetowanie hasła
    path('resetuj-haslo/', views.password_reset_request, name='password_reset'),
    path('resetuj-haslo/<str:token>/', views.password_reset_confirm, name='password_reset_confirm'),
    
    # API endpoints
    path('api/sprawdz-nazwe/', views.check_username, name='check_username'),
    path('api/sprawdz-email/', views.check_email, name='check_email'),
    
    # Przyszła integracja z Hyperreal-One
    path('hyperreal-one/polacz/', views.hyperreal_one_connect, name='hyperreal_one_connect'),
    path('hyperreal-one/rozlacz/', views.hyperreal_one_disconnect, name='hyperreal_one_disconnect'),
]