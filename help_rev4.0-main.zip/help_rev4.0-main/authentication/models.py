from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
import uuid


class UserProfile(models.Model):
    """Rozszerzenie standardowego modelu User Django."""
    
    ACCOUNT_TYPE_CHOICES = [
        ('standard', 'Standardowe konto'),
        ('hyperreal_one', 'Konto Hyperreal-One'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    
    # Dodatkowe informacje o użytkowniku
    phone = models.CharField(max_length=20, blank=True, verbose_name="Telefon")
    birth_date = models.DateField(null=True, blank=True, verbose_name="Data urodzenia")
    city = models.CharField(max_length=100, blank=True, verbose_name="Miasto")
    
    # Preferencje użytkownika
    email_notifications = models.BooleanField(default=True, verbose_name="Powiadomienia email")
    newsletter_subscription = models.BooleanField(default=False, verbose_name="Subskrypcja newslettera")
    
    # Typ konta - przygotowanie pod integrację z Hyperreal-One
    account_type = models.CharField(
        max_length=20, 
        choices=ACCOUNT_TYPE_CHOICES, 
        default='standard',
        verbose_name="Typ konta"
    )
    
    # Dane dla integracji z Hyperreal-One API
    hyperreal_one_user_id = models.CharField(
        max_length=100, 
        blank=True, 
        null=True,
        unique=True,
        verbose_name="ID użytkownika Hyperreal-One"
    )
    hyperreal_one_access_token = models.TextField(
        blank=True,
        verbose_name="Token dostępu Hyperreal-One"
    )
    hyperreal_one_refresh_token = models.TextField(
        blank=True,
        verbose_name="Token odświeżania Hyperreal-One"
    )
    
    # Metadane
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Data utworzenia")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Data aktualizacji")
    last_login_ip = models.GenericIPAddressField(null=True, blank=True, verbose_name="Ostatnie IP logowania")
    
    # Weryfikacja konta
    email_verified = models.BooleanField(default=False, verbose_name="Email zweryfikowany")
    email_verification_token = models.UUIDField(default=uuid.uuid4, verbose_name="Token weryfikacji email")
    accepts_terms = models.BooleanField(default=False, verbose_name="Akceptacja regulaminu")
    
    class Meta:
        verbose_name = "Profil użytkownika"
        verbose_name_plural = "Profile użytkowników"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Profil {self.user.username}"
    
    def get_full_name(self):
        """Zwraca pełne imię i nazwisko użytkownika."""
        return self.user.get_full_name() or self.user.username
    
    def is_hyperreal_one_user(self):
        """Sprawdza czy użytkownik jest połączony z Hyperreal-One."""
        return self.account_type == 'hyperreal_one' and bool(self.hyperreal_one_user_id)
    
    def can_add_facilities(self):
        """Sprawdza czy użytkownik może dodawać placówki."""
        # Wszyscy zalogowani użytkownicy mogą dodawać placówki
        return True
    
    def can_rate_facilities(self):
        """Sprawdza czy użytkownik może oceniać placówki."""
        # Tylko zweryfikowani użytkownicy mogą oceniać
        return self.email_verified


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """Automatycznie tworzy profil użytkownika po utworzeniu konta."""
    if created:
        UserProfile.objects.create(user=instance)


@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """Automatycznie zapisuje profil użytkownika."""
    if hasattr(instance, 'profile'):
        instance.profile.save()


class LoginAttempt(models.Model):
    """Model do śledzenia prób logowania (bezpieczeństwo)."""
    
    STATUS_CHOICES = [
        ('success', 'Udane'),
        ('failed', 'Nieudane'),
        ('blocked', 'Zablokowane'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='login_attempts')
    ip_address = models.GenericIPAddressField(verbose_name="Adres IP")
    user_agent = models.TextField(blank=True, verbose_name="User Agent")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, verbose_name="Status")
    attempted_username = models.CharField(max_length=150, blank=True, verbose_name="Próba loginu")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Czas próby")
    
    class Meta:
        verbose_name = "Próba logowania"
        verbose_name_plural = "Próby logowania"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['ip_address', 'timestamp']),
            models.Index(fields=['user', 'timestamp']),
        ]
    
    def __str__(self):
        return f"{self.status} - {self.ip_address} - {self.timestamp}"


class PasswordResetToken(models.Model):
    """Model do zarządzania tokenami resetowania hasła."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='password_reset_tokens')
    token = models.UUIDField(default=uuid.uuid4, unique=True, verbose_name="Token")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Data utworzenia")
    used_at = models.DateTimeField(null=True, blank=True, verbose_name="Data użycia")
    expires_at = models.DateTimeField(verbose_name="Data wygaśnięcia")
    is_used = models.BooleanField(default=False, verbose_name="Użyty")
    
    class Meta:
        verbose_name = "Token resetowania hasła"
        verbose_name_plural = "Tokeny resetowania haseł"
        ordering = ['-created_at']
    
    def is_valid(self):
        """Sprawdza czy token jest nadal ważny."""
        from django.utils import timezone
        return not self.is_used and self.expires_at > timezone.now()
    
    def mark_as_used(self):
        """Oznacza token jako użyty."""
        from django.utils import timezone
        self.is_used = True
        self.used_at = timezone.now()
        self.save()
    
    def __str__(self):
        return f"Token resetowania dla {self.user.username}"
