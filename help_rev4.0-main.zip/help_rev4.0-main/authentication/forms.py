from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, PasswordResetForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from .models import UserProfile
import re


class CustomUserCreationForm(UserCreationForm):
    """Rozszerzony formularz rejestracji użytkownika."""
    
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'twoj@email.pl'
        }),
        label='Email *'
    )
    
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Imię'
        }),
        label='Imię *'
    )
    
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Nazwisko'
        }),
        label='Nazwisko *'
    )
    
    terms_accepted = forms.BooleanField(
        required=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        label='Akceptuję regulamin i politykę prywatności *'
    )
    
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nazwa użytkownika'
            }),
        }
        labels = {
            'username': 'Nazwa użytkownika *',
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Hasło'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Potwierdź hasło'
        })
        self.fields['password1'].label = 'Hasło *'
        self.fields['password2'].label = 'Potwierdź hasło *'
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if email and User.objects.filter(email=email).exists():
            raise ValidationError('Użytkownik z tym adresem email już istnieje.')
        return email
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if username:
            # Sprawdź czy nazwa użytkownika zawiera tylko dozwolone znaki
            if not re.match(r'^[a-zA-Z0-9_.-]+$', username):
                raise ValidationError('Nazwa użytkownika może zawierać tylko litery, cyfry, kropki, myślniki i podkreślenia.')
            if len(username) < 3:
                raise ValidationError('Nazwa użytkownika musi mieć przynajmniej 3 znaki.')
        return username
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        
        if commit:
            user.save()
            # Utwórz profil użytkownika
            UserProfile.objects.create(
                user=user,
                email_verified=False,
                terms_accepted=True
            )
        return user


class CustomAuthenticationForm(AuthenticationForm):
    """Niestandardowy formularz logowania."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Nazwa użytkownika lub email'
        })
        self.fields['password'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Hasło'
        })
        self.fields['username'].label = 'Nazwa użytkownika lub email'
        self.fields['password'].label = 'Hasło'
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if username and '@' in username:
            # Jeśli podano email, znajdź odpowiednią nazwę użytkownika
            try:
                user = User.objects.get(email=username)
                return user.username
            except User.DoesNotExist:
                pass
        return username


class UserProfileForm(forms.ModelForm):
    """Formularz edycji profilu użytkownika."""
    
    class Meta:
        model = UserProfile
        fields = ['phone', 'birth_date', 'city', 'email_notifications']
        widgets = {
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '+48 123 456 789'
            }),
            'birth_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'city': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Warszawa'
            }),
            'email_notifications': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
        }
        labels = {
            'phone': 'Telefon',
            'birth_date': 'Data urodzenia',
            'city': 'Miasto',
            'email_notifications': 'Otrzymuj powiadomienia email',
        }
    
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if phone:
            # Usuń wszystkie znaki oprócz cyfr i znaku +
            cleaned_phone = re.sub(r'[^\d+]', '', phone)
            if not re.match(r'^\+?\d{9,15}$', cleaned_phone):
                raise ValidationError('Nieprawidłowy format numeru telefonu')
        return phone


class UserUpdateForm(forms.ModelForm):
    """Formularz aktualizacji danych użytkownika."""
    
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Imię'
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nazwisko'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'twoj@email.pl'
            }),
        }
        labels = {
            'first_name': 'Imię',
            'last_name': 'Nazwisko',
            'email': 'Email',
        }
    
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if email and self.user:
            # Sprawdź czy email nie jest już używany przez innego użytkownika
            if User.objects.filter(email=email).exclude(pk=self.user.pk).exists():
                raise ValidationError('Ten adres email jest już używany przez innego użytkownika.')
        return email


class CustomPasswordResetForm(PasswordResetForm):
    """Niestandardowy formularz resetowania hasła."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['email'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Twój adres email'
        })
        self.fields['email'].label = 'Adres email'


class ChangePasswordForm(forms.Form):
    """Formularz zmiany hasła."""
    
    old_password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Aktualne hasło'
        }),
        label='Aktualne hasło *'
    )
    
    new_password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Nowe hasło'
        }),
        label='Nowe hasło *'
    )
    
    new_password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Potwierdź nowe hasło'
        }),
        label='Potwierdź nowe hasło *'
    )
    
    def __init__(self, user, *args, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)
    
    def clean_old_password(self):
        old_password = self.cleaned_data.get('old_password')
        if not self.user.check_password(old_password):
            raise ValidationError('Nieprawidłowe aktualne hasło.')
        return old_password
    
    def clean_new_password2(self):
        password1 = self.cleaned_data.get('new_password1')
        password2 = self.cleaned_data.get('new_password2')
        
        if password1 and password2:
            if password1 != password2:
                raise ValidationError('Nowe hasła nie są identyczne.')
            
            # Sprawdź siłę hasła
            if len(password1) < 8:
                raise ValidationError('Hasło musi mieć przynajmniej 8 znaków.')
            
            if not re.search(r'[A-Z]', password1):
                raise ValidationError('Hasło musi zawierać przynajmniej jedną wielką literę.')
            
            if not re.search(r'[a-z]', password1):
                raise ValidationError('Hasło musi zawierać przynajmniej jedną małą literę.')
            
            if not re.search(r'\d', password1):
                raise ValidationError('Hasło musi zawierać przynajmniej jedną cyfrę.')
        
        return password2
    
    def save(self):
        password = self.cleaned_data['new_password1']
        self.user.set_password(password)
        self.user.save()
        return self.user


class DeleteAccountForm(forms.Form):
    """Formularz usuwania konta."""
    
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Potwierdź hasłem'
        }),
        label='Potwierdź hasłem *'
    )
    
    confirm_deletion = forms.BooleanField(
        required=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        label='Potwierdzam, że chcę trwale usunąć swoje konto *'
    )
    
    def __init__(self, user, *args, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)
    
    def clean_password(self):
        password = self.cleaned_data.get('password')
        if not self.user.check_password(password):
            raise ValidationError('Nieprawidłowe hasło.')
        return password