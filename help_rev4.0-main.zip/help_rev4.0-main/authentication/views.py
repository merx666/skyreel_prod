from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.urls import reverse
from django.db import transaction
from django.db.models import Count, Q
from .models import UserProfile, LoginAttempt, PasswordResetToken
from .forms import (
    CustomUserCreationForm, CustomAuthenticationForm, UserProfileForm,
    UserUpdateForm, CustomPasswordResetForm, ChangePasswordForm, DeleteAccountForm
)
import uuid
import hashlib
from datetime import timedelta


def register(request):
    """Rejestracja nowego użytkownika."""
    if request.user.is_authenticated:
        return redirect('medical_facilities:home')
    
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                user = form.save(commit=False)
                user.is_active = True  # Można zmienić na False jeśli wymagana weryfikacja email
                user.save()
                
                # Utwórz profil użytkownika
                UserProfile.objects.create(
                    user=user,
                    accepts_terms=form.cleaned_data.get('accepts_terms', True),
                    email_verified=False
                )
                
                # Zaloguj użytkownika automatycznie
                login(request, user)
                
                messages.success(
                    request,
                    f'Witaj {user.username}! Twoje konto zostało utworzone pomyślnie.'
                )
                
                # Przekieruj do strony głównej lub profilu
                next_url = request.GET.get('next', 'medical_facilities:home')
                return redirect(next_url)
    else:
        form = CustomUserCreationForm()
    
    context = {
        'form': form,
        'title': 'Rejestracja'
    }
    return render(request, 'authentication/register.html', context)


def user_login(request):
    """Logowanie użytkownika."""
    if request.user.is_authenticated:
        return redirect('medical_facilities:home')
    
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        
        # Sprawdź liczbę prób logowania
        ip_address = get_client_ip(request)
        username = request.POST.get('username', '')
        
        recent_attempts = LoginAttempt.objects.filter(
            ip_address=ip_address,
            timestamp__gte=timezone.now() - timedelta(minutes=15),
            status='failed'
        ).count()
        
        if recent_attempts >= 5:
            messages.error(
                request,
                'Zbyt wiele nieudanych prób logowania. Spróbuj ponownie za 15 minut.'
            )
            return render(request, 'authentication/login.html', {'form': form})
        
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            
            if user is not None:
                # Zapisz udaną próbę logowania
                user_agent = request.META.get('HTTP_USER_AGENT', '')
                LoginAttempt.objects.create(
                    user=user,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    status='success',
                    attempted_username=username
                )
                
                login(request, user)
                messages.success(request, f'Witaj ponownie, {user.username}!')
                
                # Przekieruj do żądanej strony lub strony głównej
                next_url = request.GET.get('next', 'medical_facilities:home')
                return redirect(next_url)
            else:
                # Zapisz nieudaną próbę logowania
                user_agent = request.META.get('HTTP_USER_AGENT', '')
                LoginAttempt.objects.create(
                    attempted_username=username,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    status='failed'
                )
        else:
            # Zapisz nieudaną próbę logowania dla nieprawidłowego formularza
            user_agent = request.META.get('HTTP_USER_AGENT', '')
            LoginAttempt.objects.create(
                attempted_username='',
                ip_address=ip_address,
                user_agent=user_agent,
                status='failed'
            )
    else:
        form = CustomAuthenticationForm()
    
    context = {
        'form': form,
        'title': 'Logowanie'
    }
    return render(request, 'authentication/login.html', context)


@login_required
def user_logout(request):
    """Wylogowanie użytkownika."""
    logout(request)
    messages.success(request, 'Zostałeś pomyślnie wylogowany.')
    return redirect('medical_facilities:home')


@login_required
def profile(request):
    """Profil użytkownika."""
    try:
        user_profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        user_profile = UserProfile.objects.create(user=request.user)
    
    # Oblicz statystyki użytkownika
    approved_ratings_count = request.user.facilityrating_set.filter(status='approved').count()
    approved_facilities_count = request.user.created_facilities.filter(status='approved').count()
    
    context = {
        'user_profile': user_profile,
        'title': 'Mój profil',
        'approved_ratings_count': approved_ratings_count,
        'approved_facilities_count': approved_facilities_count
    }
    return render(request, 'authentication/profile.html', context)


@login_required
def edit_profile(request):
    """Edycja profilu użytkownika."""
    try:
        user_profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        user_profile = UserProfile.objects.create(user=request.user)
    
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = UserProfileForm(request.POST, instance=user_profile)
        
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Profil został zaktualizowany pomyślnie.')
            return redirect('authentication:profile')
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = UserProfileForm(instance=user_profile)
    
    context = {
        'user_form': user_form,
        'profile_form': profile_form,
        'title': 'Edytuj profil'
    }
    return render(request, 'authentication/edit_profile.html', context)


@login_required
def change_password(request):
    """Zmiana hasła użytkownika."""
    if request.method == 'POST':
        form = ChangePasswordForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Zachowaj sesję po zmianie hasła
            messages.success(request, 'Hasło zostało zmienione pomyślnie.')
            return redirect('authentication:profile')
    else:
        form = ChangePasswordForm(user=request.user)
    
    context = {
        'form': form,
        'title': 'Zmień hasło'
    }
    return render(request, 'authentication/change_password.html', context)


def password_reset_request(request):
    """Żądanie resetowania hasła."""
    if request.user.is_authenticated:
        return redirect('medical_facilities:home')
    
    if request.method == 'POST':
        form = CustomPasswordResetForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            try:
                user = User.objects.get(email=email, is_active=True)
                
                # Utwórz token resetowania hasła
                token = str(uuid.uuid4())
                PasswordResetToken.objects.create(
                    user=user,
                    token=token,
                    expires_at=timezone.now() + timedelta(hours=24)
                )
                
                # Wyślij email z linkiem resetowania
                reset_url = request.build_absolute_uri(
                    reverse('authentication:password_reset_confirm', kwargs={'token': token})
                )
                
                subject = 'Resetowanie hasła - Hyperreal Help'
                message = render_to_string('authentication/password_reset_email.html', {
                    'user': user,
                    'reset_url': reset_url,
                    'site_name': 'Hyperreal Help'
                })
                
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [email],
                    fail_silently=False,
                )
                
                messages.success(
                    request,
                    'Link do resetowania hasła został wysłany na Twój adres email.'
                )
                return redirect('authentication:login')
                
            except User.DoesNotExist:
                # Nie ujawniaj czy email istnieje w systemie
                messages.success(
                    request,
                    'Jeśli podany adres email istnieje w naszym systemie, '
                    'link do resetowania hasła zostanie wysłany.'
                )
                return redirect('authentication:login')
    else:
        form = CustomPasswordResetForm()
    
    context = {
        'form': form,
        'title': 'Resetowanie hasła'
    }
    return render(request, 'authentication/password_reset.html', context)


def password_reset_confirm(request, token):
    """Potwierdzenie resetowania hasła."""
    try:
        reset_token = PasswordResetToken.objects.get(
            token=token,
            used=False,
            expires_at__gt=timezone.now()
        )
    except PasswordResetToken.DoesNotExist:
        messages.error(request, 'Link resetowania hasła jest nieprawidłowy lub wygasł.')
        return redirect('authentication:login')
    
    if request.method == 'POST':
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        
        if password1 and password2 and password1 == password2:
            if len(password1) >= 8:
                user = reset_token.user
                user.set_password(password1)
                user.save()
                
                # Oznacz token jako użyty
                reset_token.used = True
                reset_token.save()
                
                messages.success(
                    request,
                    'Hasło zostało zmienione pomyślnie. Możesz się teraz zalogować.'
                )
                return redirect('authentication:login')
            else:
                messages.error(request, 'Hasło musi mieć co najmniej 8 znaków.')
        else:
            messages.error(request, 'Hasła nie są identyczne.')
    
    context = {
        'token': token,
        'title': 'Ustaw nowe hasło'
    }
    return render(request, 'authentication/password_reset_confirm.html', context)


@login_required
def delete_account(request):
    """Usuwanie konta użytkownika."""
    if request.method == 'POST':
        form = DeleteAccountForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = request.user
            logout(request)
            user.delete()
            messages.success(
                request,
                'Twoje konto zostało usunięte. Dziękujemy za korzystanie z naszych usług.'
            )
            return redirect('medical_facilities:home')
    else:
        form = DeleteAccountForm(user=request.user)
    
    context = {
        'form': form,
        'title': 'Usuń konto'
    }
    return render(request, 'authentication/delete_account.html', context)


@require_http_methods(["GET"])
def check_username(request):
    """API endpoint do sprawdzania dostępności nazwy użytkownika."""
    username = request.GET.get('username', '').strip()
    
    if len(username) < 3:
        return JsonResponse({
            'available': False,
            'message': 'Nazwa użytkownika musi mieć co najmniej 3 znaki.'
        })
    
    if User.objects.filter(username=username).exists():
        return JsonResponse({
            'available': False,
            'message': 'Ta nazwa użytkownika jest już zajęta.'
        })
    
    return JsonResponse({
        'available': True,
        'message': 'Nazwa użytkownika jest dostępna.'
    })


@require_http_methods(["GET"])
def check_email(request):
    """API endpoint do sprawdzania dostępności adresu email."""
    email = request.GET.get('email', '').strip()
    
    if not email:
        return JsonResponse({
            'available': False,
            'message': 'Podaj adres email.'
        })
    
    if User.objects.filter(email=email).exists():
        return JsonResponse({
            'available': False,
            'message': 'Ten adres email jest już zarejestrowany.'
        })
    
    return JsonResponse({
        'available': True,
        'message': 'Adres email jest dostępny.'
    })


def get_client_ip(request):
    """Pobierz adres IP klienta."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


# Przygotowanie pod przyszłą integrację z Hyperreal-One API
@login_required
def hyperreal_one_connect(request):
    """Połączenie z systemem Hyperreal-One (przyszła funkcjonalność)."""
    # Ta funkcja będzie rozwinięta w przyszłości
    # gdy będzie dostępne API Hyperreal-One
    
    context = {
        'title': 'Połączenie z Hyperreal-One',
        'message': 'Ta funkcjonalność będzie dostępna wkrótce.'
    }
    return render(request, 'authentication/hyperreal_one_connect.html', context)


@login_required
def hyperreal_one_disconnect(request):
    """Rozłączenie z systemem Hyperreal-One (przyszła funkcjonalność)."""
    # Ta funkcja będzie rozwinięta w przyszłości
    
    if request.method == 'POST':
        try:
            user_profile = request.user.userprofile
            user_profile.hyperreal_one_user_id = None
            user_profile.hyperreal_one_access_token = None
            user_profile.hyperreal_one_refresh_token = None
            user_profile.hyperreal_one_connected = False
            user_profile.save()
            
            messages.success(request, 'Rozłączono z systemem Hyperreal-One.')
        except UserProfile.DoesNotExist:
            messages.error(request, 'Błąd podczas rozłączania.')
    
    return redirect('authentication:profile')
