from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from django.utils.html import format_html
from django.urls import reverse
from .models import UserProfile, LoginAttempt, PasswordResetToken


class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile użytkownika'
    fields = (
        'phone', 'birth_date', 'city',
        'email_notifications', 'newsletter_subscription',
        'email_verified', 'hyperreal_one_user_id', 'hyperreal_one_access_token'
    )
    readonly_fields = ('hyperreal_one_user_id', 'hyperreal_one_access_token')


class CustomUserAdmin(UserAdmin):
    inlines = (UserProfileInline,)
    list_display = (
        'username', 'email', 'first_name', 'last_name', 'is_staff',
        'is_active', 'date_joined', 'last_login', 'email_verified'
    )
    list_filter = (
        'is_staff', 'is_superuser', 'is_active', 'date_joined',
        'profile__email_verified'
    )
    
    def email_verified(self, obj):
        try:
            return obj.userprofile.email_verified
        except UserProfile.DoesNotExist:
            return False
    email_verified.boolean = True
    email_verified.short_description = 'Email zweryfikowany'
    
    def get_inline_instances(self, request, obj=None):
        if not obj:
            return list()
        return super().get_inline_instances(request, obj)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = (
        'user', 'phone', 'city',
        'email_verified', 'email_notifications', 'created_at'
    )
    list_filter = (
        'email_verified', 'email_notifications',
        'newsletter_subscription', 'created_at'
    )
    search_fields = ('user__username', 'user__email', 'phone', 'city')
    readonly_fields = ('created_at', 'updated_at', 'hyperreal_one_user_id')
    
    fieldsets = (
        ('Informacje podstawowe', {
            'fields': ('user', 'phone', 'birth_date', 'city')
        }),
        ('Preferencje powiadomień', {
            'fields': ('email_notifications', 'newsletter_subscription')
        }),
        ('Weryfikacja', {
            'fields': ('email_verified',)
        }),
        ('Integracja Hyperreal-One', {
            'fields': ('hyperreal_one_user_id', 'hyperreal_one_access_token'),
            'classes': ('collapse',)
        }),
        ('Metadane', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')


@admin.register(LoginAttempt)
class LoginAttemptAdmin(admin.ModelAdmin):
    list_display = (
        'attempted_username', 'ip_address', 'status', 'timestamp', 'user_agent_short'
    )
    list_filter = ('status', 'timestamp')
    search_fields = ('attempted_username', 'ip_address')
    readonly_fields = ('timestamp',)
    ordering = ('-timestamp',)
    
    fieldsets = (
        ('Informacje o próbie logowania', {
            'fields': ('attempted_username', 'ip_address', 'status', 'timestamp')
        }),
        ('Szczegóły techniczne', {
            'fields': ('user_agent',),
            'classes': ('collapse',)
        })
    )
    
    def user_agent_short(self, obj):
        if obj.user_agent:
            return obj.user_agent[:50] + '...' if len(obj.user_agent) > 50 else obj.user_agent
        return '-'
    user_agent_short.short_description = 'User Agent'
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False


@admin.register(PasswordResetToken)
class PasswordResetTokenAdmin(admin.ModelAdmin):
    list_display = (
        'user', 'token_short', 'created_at', 'expires_at', 'is_used', 'is_expired'
    )
    list_filter = ('is_used', 'created_at', 'expires_at')
    search_fields = ('user__username', 'user__email')
    readonly_fields = ('token', 'created_at', 'is_expired')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Informacje o tokenie', {
            'fields': ('user', 'token', 'created_at', 'expires_at', 'is_used')
        }),
        ('Status', {
            'fields': ('is_expired',)
        })
    )
    
    def token_short(self, obj):
        return f"{obj.token[:8]}...{obj.token[-8:]}"
    token_short.short_description = 'Token'
    
    def is_expired(self, obj):
        return obj.is_expired()
    is_expired.boolean = True
    is_expired.short_description = 'Wygasł'
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False


# Wyrejestruj domyślny UserAdmin i zarejestruj nasz CustomUserAdmin
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
