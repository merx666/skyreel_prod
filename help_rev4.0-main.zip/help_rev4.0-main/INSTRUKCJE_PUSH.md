# Instrukcje wrzucenia projektu na GitHub

## Repozytorium: https://github.com/merx666/help_rev4

## Opcja 1: Automatyczny skrypt

```bash
cd hyperreal_new_help
./PUSH_TO_GITHUB.sh
```

## Opcja 2: Reczne komendy

```bash
cd hyperreal_new_help

# 1. Dodaj remote (jesli jeszcze nie istnieje)
git remote add origin https://github.com/merx666/help_rev4.git

# 2. Dodaj wszystkie pliki
git add .

# 3. Zrob commit
git commit -m "Initial commit - projekt z baza danych i plikami produkcyjnymi"

# 4. Ustaw galaz na main
git branch -M main

# 5. Wypchnij na GitHub
git push -u origin main
```

## Uwierzytelnienie GitHub

Podczas push zostaniesz poproszony o:
- Username: merx666
- Password: Twoj Personal Access Token (NIE haslo!)

### Jak uzyskac Personal Access Token:

1. Idz na: https://github.com/settings/tokens
2. Kliknij "Generate new token" -> "Generate new token (classic)"
3. Nadaj nazwe: "help_rev4_push"
4. Zaznacz scope: `repo` (full control of private repositories)
5. Kliknij "Generate token"
6. SKOPIUJ TOKEN (nie bedzie widoczny ponownie!)
7. Uzyj tego tokena jako hasla podczas git push

## Alternatywnie: SSH

Jesli masz skonfigurowany SSH:

```bash
# Zmien remote na SSH
git remote set-url origin git@github.com:merx666/help_rev4.git

# Push
git push -u origin main
```

## Sprawdzenie po push

Po udanym push sprawdz:
- https://github.com/merx666/help_rev4
- Upewnij sie ze repozytorium jest PRYWATNE
- Sprawdz czy wszystkie pliki sa na miejscu

## Uwagi

- Repozytorium MUSI byc PRYWATNE (zawiera dane produkcyjne!)
- Baza danych db.sqlite3 JEST w repo (zakomentowane w .gitignore)
- Pliki media/ i staticfiles/ SA w repo
- Plik .env NIE jest w repo (jest w .gitignore)
