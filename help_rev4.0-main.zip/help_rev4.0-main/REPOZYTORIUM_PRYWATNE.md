# Repozytorium PRYWATNE z danymi produkcyjnymi

## WAZNE: To jest repozytorium PRYWATNE!

To repozytorium zawiera:
- Bazę danych SQLite z danymi produkcyjnymi
- Pliki media przesłane przez użytkowników
- Zebrane pliki statyczne
- Plik `.env` z konfiguracją (ale BEZ haseł produkcyjnych!)

## Co jest w .gitignore:

### Ignorowane (NIE w repo):
- `venv/` - środowisko wirtualne (każdy tworzy swoje)
- `node_modules/` - zależności Node.js
- `__pycache__/`, `*.pyc` - cache Pythona
- `.DS_Store` - pliki systemowe
- `logs/*.log` - logi (generowane na bieżąco)
- `staryhelp_baza/` - stare backupy (można usunąć)

### ZAKOMENTOWANE (BEDA w repo):
- `db.sqlite3` - baza danych produkcyjna
- `media/` - pliki użytkowników
- `staticfiles/` - zebrane pliki statyczne

## Wdrozenie na produkcje:

### 1. Sklonuj repozytorium:
```bash
git clone https://github.com/TWOJA_NAZWA/NAZWA_REPO.git
cd NAZWA_REPO
```

### 2. Utwórz środowisko wirtualne:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# lub: venv\Scripts\activate  # Windows
```

### 3. Zainstaluj zależności:
```bash
pip install -r requirements.txt
```

### 4. Skonfiguruj zmienne środowiskowe:
```bash
cp .env.example .env
nano .env
```

Ustaw produkcyjne wartości:
```env
DEBUG=False
SECRET_KEY=WYGENERUJ_NOWY_DŁUGI_KLUCZ
ALLOWED_HOSTS=twoja-domena.pl,www.twoja-domena.pl
DATABASE_URL=sqlite:///db.sqlite3  # lub PostgreSQL
```

### 5. Baza danych jest już w repo!
```bash
# Sprawdź czy baza istnieje
ls -la db.sqlite3

# Jeśli potrzebujesz wykonać nowe migracje:
python manage.py migrate

# Jeśli potrzebujesz utworzyć nowego superusera:
python manage.py createsuperuser
```

### 6. Pliki statyczne są już zebrane!
```bash
# Sprawdź
ls -la staticfiles/

# Jeśli potrzebujesz przebudować:
python manage.py collectstatic --noinput
```

### 7. Uruchom serwer:
```bash
# Development:
python manage.py runserver

# Production (z Gunicorn):
gunicorn hyperreal_help.wsgi:application --bind 0.0.0.0:8000
```

## Co zawiera repozytorium:

### Kod aplikacji:
- `authentication/` - uwierzytelnianie
- `medical_facilities/` - główna aplikacja
- `hyperreal_help/` - ustawienia Django
- `templates/` - szablony HTML
- `static/` - pliki statyczne źródłowe

### Dane produkcyjne:
- `db.sqlite3` - baza danych z placówkami, użytkownikami, ocenami
- `media/` - zdjęcia placówek przesłane przez użytkowników
- `staticfiles/` - zebrane pliki statyczne (CSS, JS, obrazy)

### Konfiguracja:
- `.env.example` - szablon konfiguracji
- `requirements.txt` - zależności Python
- Dokumentacja (README, SECURITY_CONFIG, etc.)

### Testy:
- `medical_facilities/tests/` - testy jednostkowe i integracyjne

## Bezpieczenstwo:

### Plik .env - WAŻNE!
Plik `.env` w repo powinien zawierać tylko **bezpieczne wartości deweloperskie**:
```env
DEBUG=True
SECRET_KEY=dev-key-change-in-production
ALLOWED_HOSTS=localhost,127.0.0.1
```

### Na produkcji:
Utwórz nowy `.env` z **prawdziwymi wartościami produkcyjnymi**:
```env
DEBUG=False
SECRET_KEY=SUPER_DŁUGI_LOSOWY_KLUCZ_PRODUKCYJNY
ALLOWED_HOSTS=twoja-domena.pl
DATABASE_URL=postgresql://user:pass@host/db  # jeśli używasz PostgreSQL
EMAIL_HOST_PASSWORD=prawdziwe_hasło_email
```

## Aktualizacja danych:

### Commitowanie zmian w bazie:
```bash
git add db.sqlite3
git commit -m "Aktualizacja bazy danych"
git push origin main
```

### Commitowanie nowych plików media:
```bash
git add media/
git commit -m "Dodanie nowych zdjęć placówek"
git push origin main
```

### Commitowanie zmian w kodzie:
```bash
git add .
git commit -m "Opis zmian"
git push origin main
```

## Uwagi:

1. **Repozytorium MUSI być PRYWATNE** - zawiera dane użytkowników!
2. **Nie udostępniaj publicznie** - dane osobowe, oceny, zdjęcia
3. **Backup bazy danych** - regularnie rób backupy poza Git
4. **Migracja na PostgreSQL** - rozważ dla produkcji (SQLite ma ograniczenia)
5. **Pliki .env** - nigdy nie commituj z prawdziwymi hasłami produkcyjnymi

## Checklist przed wdrozeniem:

- [ ] Repozytorium ustawione jako PRYWATNE na GitHub
- [ ] Nowy SECRET_KEY wygenerowany dla produkcji
- [ ] DEBUG=False w produkcyjnym .env
- [ ] ALLOWED_HOSTS ustawione na właściwą domenę
- [ ] Hasła email/bazy danych zmienione na produkcyjne
- [ ] SSL/HTTPS skonfigurowane
- [ ] Backup bazy danych wykonany
- [ ] Testy przeszły pomyślnie
- [ ] Logi monitorowane

## Gotowe!

Repozytorium zawiera wszystko co potrzebne do wdrożenia, włącznie z bazą danych i plikami użytkowników.
