import re
import ast
import json
import os
import sys
import django

# Setup Django
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hyperreal_help.settings')
django.setup()

from medical_facilities.models import MedicalFacility

# --- Part 1: Core Parsing Engine (Verified) ---

def parse_php_serialized(s):
    """
    A simple parser for PHP serialized strings.
    Handles basic arrays (a:N:{...}) and strings (s:N:"...";).
    """
    if not s or not s.startswith('a:'):
        return None

    data = {}
    content_match = re.match(r'a:\d+:\{(.*)\}', s)
    if not content_match:
        return None
    
    content = content_match.group(1)
    
    pairs = re.findall(r'(s:\d+:".*?";(?:s:\d+:".*?"|i:\d+;|N;))', content)
    
    for pair in pairs:
        parts = pair.split(';', 2)
        if len(parts) < 2:
            continue

        key_match = re.match(r's:\d+:"(.*?)"', parts[0])
        if not key_match:
            continue
        key = key_match.group(1)

        value_part = parts[1] + ';'
        if value_part.startswith('s:'):
            value_match = re.match(r's:\d+:"(.*?)"', value_part)
            value = value_match.group(1) if value_match else None
        elif value_part.startswith('i:'):
            value_match = re.match(r'i:(\d+);', value_part)
            value = int(value_match.group(1)) if value_match else None
        elif value_part == 'N;':
            value = None
        else:
            value = None

        if key:
            data[key] = value
            
    return data

def parse_sql_dump(filepath):
    """
    Parses a Drupal 7 SQL dump to extract nodes and related data.
    """
    nodes = {}
    taxonomy_terms = {}
    field_data = {
        'field_adres': {}, 'field_wojewodztwo': {}, 'field_telefon_stacjonarny': {},
        'field_email': {}, 'field_ilosc_miejsc': {}, 'field_rodzaje_uzaleznien': {},
        'field_dlugosc_programu': {}, 'field_rodzaj_terapii': {}, 'field_typ_placowki': {},
        'field_rodzaj_leczenia': {}, 'field_psychoterapia': {}, 'field_poradnictwo': {},
        'field_grupa_wiekowa_i_plec': {}, 'field_dzialania_prawne': {},
        'field_inne_dzialania': {}, 'field_lokalizacja': {}, 'field_opis_placowki': {}
    }

    insert_regex = re.compile(r"INSERT INTO `(.*?)` VALUES")

    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
        
        # Split by INSERT INTO statements
        insert_statements = re.split(r"INSERT INTO `", content)
        
        for statement in insert_statements[1:]:  # Skip first empty split
            # Extract table name - statement starts with "tablename` VALUES"
            table_match = re.match(r"([^`]+)`\s+VALUES", statement)
            if not table_match:
                continue

            table_name = table_match.group(1)
            
            # Extract values part (everything after VALUES until semicolon)
            values_match = re.search(r"VALUES\s+(.*?);", statement, re.DOTALL)
            if not values_match:
                continue

            values_str = values_match.group(1).strip()
            
            # Wrap in brackets to make it a list of tuples
            if values_str.startswith('('):
                values_str = '[' + values_str + ']'

            if table_name not in ['node', 'taxonomy_term_data'] and not table_name.startswith('field_data_'):
                continue
            
            try:
                values_tuples = ast.literal_eval(values_str)
            except (ValueError, SyntaxError) as e:
                continue

            if table_name == 'node':
                for val in values_tuples:
                    if len(val) < 10:
                        continue
                    # Unpack with defaults for missing values
                    nid = val[0] if len(val) > 0 else None
                    title = val[4] if len(val) > 4 else None
                    status = val[9] if len(val) > 9 else 0
                    type_val = val[2] if len(val) > 2 else None
                    
                    if type_val == 'osrodek' and status >= 1:  # status >= 1 means published
                        nodes[nid] = {'title': title, 'type': type_val}

            elif table_name == 'taxonomy_term_data':
                for val in values_tuples:
                    tid, _, name, _, _, _ = val[:6]
                    taxonomy_terms[tid] = name

            elif table_name.startswith('field_data_'):
                field_name = table_name.replace('field_data_', '', 1)
                if field_name not in field_data:
                    continue

                for val in values_tuples:
                    if len(val) < 4:
                        continue
                    entity_id = val[3]
                    if entity_id not in field_data[field_name]:
                        field_data[field_name][entity_id] = []
                    
                    if 'target_id' in str(val) or 'tid' in str(val):
                        if len(val) > 0:
                        field_data[field_name][entity_id].append(val[-1])
                    elif field_name == 'field_adres':
                        if len(val) > 8:
                        address_serialized = val[8]
                        address_data = parse_php_serialized(address_serialized)
                        field_data[field_name][entity_id].append(address_data)
                    elif field_name == 'field_lokalizacja':
                        if len(val) > 10:
                        lat, lon = val[9], val[10]
                        field_data[field_name][entity_id].append({'lat': lat, 'lon': lon})
                    elif field_name == 'field_opis_placowki':
                        # field_opis_placowki_value is at index 7
                        if len(val) > 7:
                            description = val[7]
                            if description:
                                field_data[field_name][entity_id].append(description)
                    else:
                        if len(val) > 8:
                        field_data[field_name][entity_id].append(val[8])

    return {"nodes": nodes, "taxonomy_terms": taxonomy_terms, "field_data": field_data}

# --- Part 2: Data Assembly Logic ---

def assemble_json(nodes, taxonomy_terms, field_data):
    """
    Assembles the final JSON from the parsed data.
    """
    facilities = []
    for nid, node_data in nodes.items():
        facility = {
            "id": nid,
            "title": node_data['title'],
            "address": None,
            "coordinates": None,
            "details": {}
        }

        # Helper to get single value or None
        def get_single_value(field_name, entity_id):
            values = field_data.get(field_name, {}).get(entity_id, [])
            return values[0] if values else None

        # Helper to get multiple values
        def get_multiple_values(field_name, entity_id):
            return field_data.get(field_name, {}).get(entity_id, [])

        # Process address and coordinates
        address_data = get_single_value('field_adres', nid)
        if address_data:
            facility['address'] = f"{address_data.get('thoroughfare', '')}, {address_data.get('locality', '')}, {address_data.get('postal_code', '')}"

        coords = get_single_value('field_lokalizacja', nid)
        if coords:
            facility['coordinates'] = coords
            
        # Process other fields
        facility['details']['wojewodztwo'] = taxonomy_terms.get(get_single_value('field_wojewodztwo', nid))
        facility['details']['telefon'] = get_single_value('field_telefon_stacjonarny', nid)
        facility['details']['email'] = get_single_value('field_email', nid)
        facility['details']['ilosc_miejsc'] = get_single_value('field_ilosc_miejsc', nid)
        
        # Process taxonomy term reference fields
        taxonomy_fields = {
            "rodzaje_uzaleznien": "field_rodzaje_uzaleznien",
            "dlugosc_programu": "field_dlugosc_programu",
            "rodzaj_terapii": "field_rodzaj_terapii",
            "typ_placowki": "field_typ_placowki",
            "rodzaj_leczenia": "field_rodzaj_leczenia",
            "psychoterapia": "field_psychoterapia",
            "poradnictwo": "field_poradnictwo",
            "grupa_wiekowa_i_plec": "field_grupa_wiekowa_i_plec",
            "dzialania_prawne": "field_dzialania_prawne",
            "inne_dzialania": "field_inne_dzialania",
        }
        
        for key, field_name in taxonomy_fields.items():
            term_ids = get_multiple_values(field_name, nid)
            facility['details'][key] = [taxonomy_terms.get(tid) for tid in term_ids if tid in taxonomy_terms]
        
        # Process description
        description = get_single_value('field_opis_placowki', nid)
        if description:
            facility['description'] = description
        else:
            facility['description'] = None

        facilities.append(facility)
        
    return facilities

# --- Part 3: Import to Django Database ---

def import_descriptions_to_django(facilities_json):
    """
    Importuje opisy placówek do bazy Django.
    Mapuje stare węzły na istniejące placówki po nazwie.
    """
    imported = 0
    updated = 0
    not_found = 0
    no_description = 0
    
    print(f"Przetwarzanie {len(facilities_json)} placówek...")
    
    for facility_data in facilities_json:
        old_title = facility_data['title']
        description = facility_data.get('description')
        
        if not description:
            no_description += 1
            continue
        
        # Znajdź placówkę po nazwie
        try:
            # Spróbuj dokładne dopasowanie
            facility = MedicalFacility.objects.get(name=old_title)
            if facility.description != description:
                facility.description = description
                facility.save(update_fields=['description'])
                updated += 1
                if updated <= 10:  # Print first 10
                    print(f"✓ Zaktualizowano opis: {old_title[:50]}...")
            else:
                imported += 1  # Already has this description
        except MedicalFacility.DoesNotExist:
            # Spróbuj częściowe dopasowanie
            facilities = MedicalFacility.objects.filter(name__icontains=old_title[:30])
            if facilities.count() == 1:
                facility = facilities.first()
                if facility.description != description:
                    facility.description = description
                    facility.save(update_fields=['description'])
                    updated += 1
                    if updated <= 10:
                        print(f"✓ Zaktualizowano opis (częściowe dopasowanie): {old_title[:50]}... -> {facility.name[:50]}...")
                else:
                    imported += 1
            elif facilities.count() > 1:
                # Jeśli wiele, użyj pierwszego najlepszego dopasowania
                facility = facilities.first()
                if facility.description != description:
                    facility.description = description
                    facility.save(update_fields=['description'])
                    updated += 1
                    if updated <= 10:
                        print(f"⚠ Zaktualizowano opis (wiele dopasowań, użyto pierwszego): {old_title[:50]}... -> {facility.name[:50]}...")
                else:
                    imported += 1
            else:
                not_found += 1
                if not_found <= 10:
                    print(f"✗ Nie znaleziono placówki: {old_title[:50]}...")
        except MedicalFacility.MultipleObjectsReturned:
            # Jeśli wiele placówek, użyj pierwszej
            facility = MedicalFacility.objects.filter(name=old_title).first()
            if facility.description != description:
                facility.description = description
                facility.save(update_fields=['description'])
                updated += 1
                if updated <= 10:
                    print(f"⚠ Zaktualizowano opis (wiele placówek, użyto pierwszej): {old_title[:50]}...")
            else:
                imported += 1
    
    print(f"\n=== Podsumowanie ===")
    print(f"Zaktualizowano: {updated}")
    print(f"Już miało opis: {imported}")
    print(f"Bez opisu w źródle: {no_description}")
    print(f"Nie znaleziono: {not_found}")
    print(f"Razem przetworzono: {len(facilities_json)}")

# --- Part 4: Main Execution Block ---

if __name__ == '__main__':
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    sql_dump_file = os.path.join(script_dir, 'pomoc.sql')
    try:
        print("=== Parsowanie pliku SQL ===")
        # Step 1: Parse the SQL dump
        parsed_data = parse_sql_dump(sql_dump_file)
        print(f"Znaleziono {len(parsed_data['nodes'])} placówek")
        
        # Step 2: Assemble the final JSON
        print("\n=== Tworzenie struktury danych ===")
        facilities_json = assemble_json(
            parsed_data["nodes"],
            parsed_data["taxonomy_terms"],
            parsed_data["field_data"]
        )
        
        # Step 3: Import descriptions to Django
        print("\n=== Importowanie opisów do bazy Django ===")
        import_descriptions_to_django(facilities_json)
        
        print("\n✓ Migracja zakończona pomyślnie!")

    except FileNotFoundError:
        print(f"Error: The file '{sql_dump_file}' was not found.")
    except Exception as e:
        import traceback
        print(f"An error occurred: {e}")
        traceback.print_exc()