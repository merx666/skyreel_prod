#!/bin/bash

# Skrypt do wrzucenia projektu na GitHub
# Repozytorium: https://github.com/merx666/help_rev4

echo "==================================="
echo "Push projektu na GitHub"
echo "==================================="
echo ""

# 1. Sprawdź czy remote już istnieje
echo "1. Sprawdzanie remote..."
if git remote | grep -q origin; then
    echo "Remote 'origin' juz istnieje"
    git remote -v
else
    echo "Dodawanie remote 'origin'..."
    git remote add origin https://github.com/merx666/help_rev4.git
fi

echo ""
echo "2. Dodawanie wszystkich plikow..."
git add .

echo ""
echo "3. Tworzenie commita..."
git commit -m "Initial commit - projekt z baza danych i plikami produkcyjnymi"

echo ""
echo "4. Ustawianie glownej galezi na 'main'..."
git branch -M main

echo ""
echo "5. Pushowanie na GitHub..."
echo "UWAGA: Zostaniesz poproszony o dane logowania do GitHub"
git push -u origin main

echo ""
echo "==================================="
echo "Gotowe!"
echo "Projekt dostepny pod: https://github.com/merx666/help_rev4"
echo "==================================="
