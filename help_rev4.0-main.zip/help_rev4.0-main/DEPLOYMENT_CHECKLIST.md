# Deployment Checklist - Hyperreal Help

## Pre-Deployment Checklist

### 1. Code Quality
- [ ] Wszystkie testy przechodzą: `python manage.py test`
- [ ] Brak błędów w `python manage.py check --deploy`
- [ ] Code review wykonany
- [ ] Dokumentacja zaktualizowana

### 2. Environment Configuration
- [ ] Plik `.env` utworzony z produkcyjnymi wartościami
- [ ] `SECRET_KEY` wygenerowany (min 50 znaków, losowy)
- [ ] `DEBUG=False`
- [ ] `ALLOWED_HOSTS` zawiera tylko produkcyjne domeny
- [ ] `DATABASE_URL` skonfigurowany (PostgreSQL)
- [ ] `REDIS_URL` skonfigurowany

### 3. Security Settings
- [ ] `SECURE_SSL_REDIRECT=True`
- [ ] `SESSION_COOKIE_SECURE=True`
- [ ] `CSRF_COOKIE_SECURE=True`
- [ ] `SECURE_HSTS_SECONDS=31536000`
- [ ] `RECAPTCHA_PUBLIC_KEY` i `RECAPTCHA_PRIVATE_KEY` skonfigurowane
- [ ] Email settings skonfigurowane (dla alertów)

### 4. Database
- [ ] PostgreSQL zainstalowany i uruchomiony
- [ ] Baza danych utworzona
- [ ] User bazy danych utworzony z odpowiednimi uprawnieniami
- [ ] Migracje wykonane: `python manage.py migrate`
- [ ] Superuser utworzony: `python manage.py createsuperuser`

### 5. Redis
- [ ] Redis zainstalowany i uruchomiony
- [ ] Redis dostępny pod `REDIS_URL`
- [ ] Test połączenia: `redis-cli ping` → PONG

### 6. Static Files
- [ ] `STATIC_ROOT` skonfigurowany
- [ ] `python manage.py collectstatic --noinput` wykonany
- [ ] Pliki statyczne dostępne przez Nginx/Apache

### 7. Web Server
- [ ] Nginx/Apache zainstalowany i skonfigurowany
- [ ] SSL/TLS certyfikat zainstalowany (Let's Encrypt)
- [ ] HTTPS wymuszony (redirect z HTTP)
- [ ] Gunicorn/uWSGI zainstalowany
- [ ] Systemd service utworzony i aktywny

### 8. Firewall
- [ ] Firewall skonfigurowany (ufw/iptables)
- [ ] Tylko porty 80, 443, 22 otwarte
- [ ] SSH zabezpieczony (klucze, nie hasła)

### 9. Logging
- [ ] Katalog `/var/log/hyperreal_help/` utworzony
- [ ] Uprawnienia do zapisu logów
- [ ] Logrotate skonfigurowany
- [ ] Logi testowane

### 10. Backup
- [ ] Automatyczny backup bazy danych skonfigurowany (cron)
- [ ] Backup plików media skonfigurowany
- [ ] Test restore z backupu wykonany
- [ ] Backup przechowywany poza serwerem

### 11. Monitoring
- [ ] Dashboard bezpieczeństwa dostępny
- [ ] Email alerts działają
- [ ] Logi są monitorowane
- [ ] Uptime monitoring skonfigurowany (opcjonalnie)

### 12. Performance
- [ ] Redis cache działa
- [ ] Database indexes utworzone (automatycznie przez migracje)
- [ ] Static files serwowane przez Nginx (nie Django)
- [ ] Gzip compression włączony w Nginx

## Post-Deployment Checklist

### 1. Functional Testing
- [ ] Strona główna ładuje się poprawnie
- [ ] Panel admin dostępny i działa
- [ ] Dashboard bezpieczeństwa działa
- [ ] Logowanie/wylogowanie działa
- [ ] Dodawanie placówki działa (z CAPTCHA)
- [ ] Dodawanie oceny działa (z CAPTCHA)
- [ ] Wyszukiwanie działa
- [ ] Mapa działa
- [ ] Eksport CSV działa

### 2. Security Testing
- [ ] HTTPS wymuszony (test: http://domain.com → https://domain.com)
- [ ] Security headers obecne (test: securityheaders.com)
- [ ] HSTS header obecny
- [ ] CSP header obecny
- [ ] Rate limiting działa (test: 11 żądań w minutę)
- [ ] CAPTCHA działa na formularzach
- [ ] XSS detection działa (test: `<script>alert('xss')</script>`)
- [ ] SQL Injection detection działa (test: `' OR '1'='1`)
- [ ] CSRF protection działa

### 3. Performance Testing
- [ ] Strona ładuje się < 3 sekundy
- [ ] Redis cache działa (sprawdź logi)
- [ ] Database queries optymalne (Django Debug Toolbar w dev)
- [ ] Static files cache'owane (sprawdź headers)

### 4. Monitoring Setup
- [ ] Sprawdź Dashboard Bezpieczeństwa
- [ ] Sprawdź Audit Logs
- [ ] Sprawdź Security Events
- [ ] Test email alert (spróbuj 3 razy XSS)

### 5. Documentation
- [ ] README.md zaktualizowany
- [ ] SECURITY_CONFIG.md dostępny
- [ ] PRODUCTION_SETUP.md dostępny
- [ ] Deployment notes zapisane

## Emergency Rollback Plan

Jeśli coś pójdzie nie tak:

### 1. Szybki Rollback
```bash
# Przywróć poprzednią wersję kodu
git checkout previous-stable-tag

# Przywróć bazę danych z backupu
psql -U user -d hyperreal_help < backup.sql

# Restart services
sudo systemctl restart hyperreal_help
sudo systemctl restart nginx
```

### 2. Kontakt
- [ ] Lista kontaktów do zespołu technicznego
- [ ] Procedura eskalacji problemów
- [ ] Dostęp do logów i monitoringu

## Maintenance Schedule

### Codziennie
- [ ] Sprawdź Dashboard Bezpieczeństwa
- [ ] Sprawdź Security Events (nierozwiązane)
- [ ] Sprawdź logi błędów

### Co tydzień
- [ ] Sprawdź Audit Logs
- [ ] Sprawdź Top IP addresses
- [ ] Sprawdź statystyki rate limiting
- [ ] Backup verification

### Co miesiąc
- [ ] Update dependencies (security patches)
- [ ] Review Security Events (wszystkie)
- [ ] Database optimization
- [ ] Log cleanup (stare logi)

### Co kwartał
- [ ] Full security audit
- [ ] Performance review
- [ ] Backup restore test
- [ ] Disaster recovery drill

## Support Contacts

- **Technical Lead**: [email]
- **DevOps**: [email]
- **Security**: [email]
- **On-Call**: [phone]

## Useful Commands

```bash
# Check service status
sudo systemctl status hyperreal_help
sudo systemctl status nginx
sudo systemctl status redis

# View logs
tail -f /var/log/hyperreal_help/gunicorn_error.log
tail -f /var/log/nginx/error.log
journalctl -u hyperreal_help -f

# Restart services
sudo systemctl restart hyperreal_help
sudo systemctl restart nginx

# Django management
python manage.py check --deploy
python manage.py migrate
python manage.py collectstatic --noinput
python manage.py createsuperuser

# Database backup
pg_dump -U user hyperreal_help > backup_$(date +%Y%m%d).sql

# Redis check
redis-cli ping
redis-cli info stats
```

---

**Last Updated**: [Date]
**Deployed By**: [Name]
**Deployment Date**: [Date]
**Version**: [Version/Tag]
