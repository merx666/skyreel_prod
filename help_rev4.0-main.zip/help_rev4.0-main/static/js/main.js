// Hyperreal Help - Main JavaScript
// Modern interactive features with responsive design

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing app...');
    initializeApp();
});

// Also initialize if DOM is already loaded
if (document.readyState !== 'loading') {
    console.log('DOM already loaded, initializing app immediately...');
    initializeApp();
}

// Smooth animations and transitions
function initializeAnimations() {
    console.log('Initializing animations...');
    
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe all elements with animation classes
    document.querySelectorAll('.slide-up, .card, .glass-card, .facility-card').forEach(el => {
        observer.observe(el);
    });
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Main initialization function
function initializeApp() {
    console.log('initializeApp called');
    initializeAnimations();
    initializeSearch();
    initializeFormValidation();
    initializeTooltips();
    initializeModals();
    initializeRating();
    initializeGeolocation();
    initializeImageUpload();
    initializeLazyLoading();
    initializeResponsiveFeatures();
}

// Enhanced search functionality
function initializeSearch() {
    console.log('Initializing search...');
    const searchInput = document.querySelector('#search-input');
    const searchResults = document.querySelector('#search-results');
    
    if (!searchInput) {
        console.log('Search input not found');
        return;
    }
    
    let searchTimeout;
    
    searchInput.addEventListener('input', function() {
        const query = this.value.trim();
        
        clearTimeout(searchTimeout);
        
        if (query.length < 2) {
            if (searchResults) {
                searchResults.style.display = 'none';
            }
            return;
        }
        
        searchTimeout = setTimeout(() => {
            performSearch(query);
        }, 300);
    });
    
    // Hide results when clicking outside
    document.addEventListener('click', function(e) {
        if (searchResults && !searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
    
    function performSearch(query) {
        console.log('Performing search for:', query);
        
        fetch(`/api/placowki/szukaj/?q=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                displaySearchResults(data.results || []);
            })
            .catch(error => {
                console.error('Search error:', error);
            });
    }
    
    function displaySearchResults(results) {
        if (!searchResults) return;
        
        if (results.length === 0) {
            searchResults.innerHTML = '<div class="p-3 text-muted">Brak wyników</div>';
        } else {
            const html = results.map(facility => `
                <div class="search-result-item p-3 border-bottom" data-id="${facility.id}">
                    <div class="fw-bold">${facility.name}</div>
                    <div class="text-muted small">${facility.city}, ${facility.voivodeship}</div>
                    <div class="text-muted small">${facility.facility_type}</div>
                </div>
            `).join('');
            searchResults.innerHTML = html;
            
            // Add click handlers
            searchResults.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', function() {
                    const facilityId = this.dataset.id;
                    window.location.href = `/placowka/${facilityId}/`;
                });
            });
        }
        
        searchResults.style.display = 'block';
    }
}

// Form validation
function initializeFormValidation() {
    console.log('Initializing form validation...');
    
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
        });
    });
    
    function validateForm(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
        
        inputs.forEach(input => {
            if (!validateField(input)) {
                isValid = false;
            }
        });
        
        return isValid;
    }
    
    function validateField(field) {
        const value = field.value.trim();
        const isRequired = field.hasAttribute('required');
        let isValid = true;
        
        // Remove existing error classes
        field.classList.remove('is-invalid');
        const errorDiv = field.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
        
        // Required field validation
        if (isRequired && !value) {
            isValid = false;
            showFieldError(field, 'To pole jest wymagane');
        }
        
        // Email validation
        if (field.type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                isValid = false;
                showFieldError(field, 'Wprowadź poprawny adres email');
            }
        }
        
        // Phone validation
        if (field.type === 'tel' && value) {
            const phoneRegex = /^[\d\s\-\+\(\)]+$/;
            if (!phoneRegex.test(value)) {
                isValid = false;
                showFieldError(field, 'Wprowadź poprawny numer telefonu');
            }
        }
        
        return isValid;
    }
    
    function showFieldError(field, message) {
        field.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        errorDiv.textContent = message;
        field.parentNode.appendChild(errorDiv);
    }
}

// Initialize tooltips
function initializeTooltips() {
    console.log('Initializing tooltips...');
    
    // Simple tooltip implementation
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
    
    function showTooltip(e) {
        const text = e.target.getAttribute('data-tooltip');
        const tooltip = document.createElement('div');
        tooltip.className = 'custom-tooltip';
        tooltip.textContent = text;
        document.body.appendChild(tooltip);
        
        const rect = e.target.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
        tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
        
        e.target._tooltip = tooltip;
    }
    
    function hideTooltip(e) {
        if (e.target._tooltip) {
            e.target._tooltip.remove();
            delete e.target._tooltip;
        }
    }
}

// Initialize modals
function initializeModals() {
    console.log('Initializing modals...');
    
    // Simple modal implementation
    const modalTriggers = document.querySelectorAll('[data-modal]');
    
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', function(e) {
            e.preventDefault();
            const modalId = this.getAttribute('data-modal');
            const modal = document.querySelector(modalId);
            if (modal) {
                showModal(modal);
            }
        });
    });
    
    // Close modal handlers
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-close') || e.target.classList.contains('modal-backdrop')) {
            const modal = e.target.closest('.modal');
            if (modal) {
                hideModal(modal);
            }
        }
    });
    
    function showModal(modal) {
        modal.style.display = 'block';
        document.body.classList.add('modal-open');
        setTimeout(() => modal.classList.add('show'), 10);
    }
    
    function hideModal(modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.classList.remove('modal-open');
        }, 300);
    }
}

// Rating system
function initializeRating() {
    console.log('Initializing rating system...');
    
    const ratingContainers = document.querySelectorAll('.rating-input');
    
    ratingContainers.forEach(container => {
        const stars = container.querySelectorAll('.star');
        const input = container.querySelector('input[type="hidden"]');
        
        stars.forEach((star, index) => {
            star.addEventListener('click', function() {
                const rating = index + 1;
                if (input) {
                    input.value = rating;
                }
                updateStarDisplay(stars, rating);
            });
            
            star.addEventListener('mouseenter', function() {
                updateStarDisplay(stars, index + 1);
            });
        });
        
        container.addEventListener('mouseleave', function() {
            const currentRating = input ? input.value : 0;
            updateStarDisplay(stars, currentRating);
        });
    });
    
    function updateStarDisplay(stars, rating) {
        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
    }
}

// Geolocation functionality
function initializeGeolocation() {
    console.log('Initializing geolocation...');
    
    const locationBtn = document.querySelector('#get-location-btn');
    
    if (locationBtn) {
        locationBtn.addEventListener('click', function() {
            if ('geolocation' in navigator) {
                this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Pobieranie lokalizacji...';
                this.disabled = true;
                
                navigator.geolocation.getCurrentPosition(
                    position => {
                        const { latitude, longitude } = position.coords;
                        window.location.href = `/placowki/?lat=${latitude}&lng=${longitude}`;
                    },
                    error => {
                        console.error('Geolocation error:', error);
                        this.innerHTML = '<i class="fas fa-map-marker-alt me-2"></i>Znajdź w pobliżu';
                        this.disabled = false;
                        alert('Nie udało się pobrać lokalizacji. Sprawdź ustawienia przeglądarki.');
                    }
                );
            } else {
                alert('Twoja przeglądarka nie obsługuje geolokalizacji.');
            }
        });
    }
}

// Image upload functionality
function initializeImageUpload() {
    console.log('Initializing image upload...');
    
    const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
    
    imageInputs.forEach(input => {
        input.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                // Validate file size (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('Plik jest za duży. Maksymalny rozmiar to 5MB.');
                    this.value = '';
                    return;
                }
                
                // Show preview if preview container exists
                const previewContainer = document.querySelector(`#${this.id}-preview`);
                if (previewContainer) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewContainer.innerHTML = `<img src="${e.target.result}" class="img-thumbnail" style="max-width: 200px;">`;
                    };
                    reader.readAsDataURL(file);
                }
            }
        });
    });
}

// Lazy loading for images
function initializeLazyLoading() {
    console.log('Initializing lazy loading...');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    observer.unobserve(img);
                }
            });
        });
        
        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
}

// Responsive features
function initializeResponsiveFeatures() {
    console.log('Initializing responsive features...');
    
    // Mobile menu improvements
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        // Close mobile menu when clicking on a link
        navbarCollapse.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 992) {
                    navbarCollapse.classList.remove('show');
                }
            });
        });
    }
    
    // Responsive table handling
    const tables = document.querySelectorAll('table');
    tables.forEach(table => {
        if (!table.closest('.table-responsive')) {
            const wrapper = document.createElement('div');
            wrapper.className = 'table-responsive';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        }
    });
    
    // Touch-friendly improvements for mobile
    if ('ontouchstart' in window) {
        document.body.classList.add('touch-device');
        
        // Improve hover effects on touch devices
        document.querySelectorAll('.btn, .card, .facility-card').forEach(element => {
            element.addEventListener('touchstart', function() {
                this.classList.add('touch-active');
            });
            
            element.addEventListener('touchend', function() {
                setTimeout(() => {
                    this.classList.remove('touch-active');
                }, 300);
            });
        });
    }
    
    // Viewport height fix for mobile browsers
    function setViewportHeight() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
    
    setViewportHeight();
    window.addEventListener('resize', setViewportHeight);
    window.addEventListener('orientationchange', setViewportHeight);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export functions for global access if needed
window.HyperealHelp = {
    initializeApp,
    initializeAnimations,
    initializeSearch,
    initializeFormValidation,
    initializeTooltips,
    initializeModals,
    initializeRating,
    initializeGeolocation,
    initializeImageUpload,
    initializeLazyLoading,
    initializeResponsiveFeatures,
    debounce,
    throttle
};

console.log('Hyperreal Help JavaScript loaded successfully');