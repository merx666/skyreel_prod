# Security Configuration - Task 1 Implementation

## Overview
This document describes the security configurations implemented in Task 1 of the admin-panel-security specification.

## Implemented Components

### 1. HTTP Security Headers

The following security headers have been configured in `settings.py`:

- **X-Content-Type-Options**: `nosniff` - Prevents MIME type sniffing
- **X-Frame-Options**: `DENY` - Prevents clickjacking attacks
- **X-XSS-Protection**: Enabled via `SECURE_BROWSER_XSS_FILTER`
- **Strict-Transport-Security (HSTS)**: Configurable via environment variable
- **Referrer-Policy**: `strict-origin-when-cross-origin`

### 2. Content Security Policy (CSP)

CSP has been implemented using `django-csp` middleware with the following policies:

```python
CSP_DEFAULT_SRC = ("'self'",)
CSP_SCRIPT_SRC = ("'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdn.jsdelivr.net", "https://code.jquery.com")
CSP_STYLE_SRC = ("'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com")
CSP_FONT_SRC = ("'self'", "https://fonts.gstatic.com", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com", "data:")
CSP_IMG_SRC = ("'self'", "data:", "https:", "http:")
CSP_FRAME_ANCESTORS = ("'none'",)
CSP_BASE_URI = ("'self'",)
CSP_FORM_ACTION = ("'self'",)
```

**Note**: `unsafe-inline` and `unsafe-eval` are currently allowed for compatibility with Bootstrap and jQuery. These should be removed in future iterations by using nonces or hashes.

### 3. Redis Cache Configuration

Redis has been configured as the default cache backend for rate limiting:

```python
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': REDIS_URL,
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'SOCKET_CONNECT_TIMEOUT': 5,
            'SOCKET_TIMEOUT': 5,
            'RETRY_ON_TIMEOUT': True,
        },
    }
}
```

**Environment Variable**: `REDIS_URL` (default: `redis://127.0.0.1:6379/0`)

### 4. Audit Logging Middleware

A custom middleware (`AuditLogMiddleware`) has been created to log all important actions:

**Location**: `medical_facilities/audit_middleware.py`

**Features**:
- Logs all POST, PUT, PATCH, DELETE requests
- Logs all admin panel actions
- Logs HTTP errors (4xx, 5xx)
- Logs exceptions
- Captures user, IP address, user agent, and request details
- Writes to security log file

**Log Files**:
- `logs/security.log` - Security-related events
- `logs/django.log` - General application logs

### 5. Rate Limiting Configuration

Rate limiting has been configured using `django-ratelimit`:

```python
RATELIMIT_ENABLE = True
RATELIMIT_USE_CACHE = 'default'
RATELIMIT_VIEW = 'medical_facilities.views.rate_limit_exceeded'
```

Rate limits will be applied to specific views in subsequent tasks.

### 6. Session and Cookie Security

Enhanced session and cookie security:

```python
SESSION_COOKIE_SECURE = True  # In production with HTTPS
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'

CSRF_COOKIE_SECURE = True  # In production with HTTPS
CSRF_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = 'Lax'
```

### 7. Error Handlers

Custom error handlers for security-related errors:

- **Rate Limit Exceeded (429)**: `medical_facilities.views.rate_limit_exceeded`
- **CSRF Failure (403)**: `medical_facilities.views.csrf_failure`

Templates:
- `templates/errors/rate_limit.html`
- `templates/errors/csrf_failure.html`

### 8. Logging Configuration

Comprehensive logging system with rotating file handlers:

**Loggers**:
- `django` - General Django logs
- `django.security` - Security-specific logs
- `security` - Custom security logs
- `django.request` - Request errors

**Log Rotation**:
- Maximum file size: 10 MB
- Backup count: 10 files
- Total storage per log: ~100 MB

## Environment Variables

The following environment variables should be configured:

### Required for Production:
```bash
SECRET_KEY=your-secret-key-here
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
REDIS_URL=redis://127.0.0.1:6379/0
```

### Security Settings (Production):
```bash
SECURE_SSL_REDIRECT=True
SESSION_COOKIE_SECURE=True
CSRF_COOKIE_SECURE=True
SECURE_HSTS_SECONDS=31536000
```

### Development Settings:
```bash
SECRET_KEY=django-insecure-dev-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
REDIS_URL=redis://127.0.0.1:6379/0
SECURE_SSL_REDIRECT=False
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_SECURE=False
SECURE_HSTS_SECONDS=0
```

## Dependencies Added

The following packages have been added to `requirements.txt`:

- `django-redis>=5.4.0` - Redis cache backend
- `django-csp>=3.8` - Content Security Policy middleware
- `python-decouple>=3.8` - Environment variable management

## Middleware Stack Order

The middleware stack has been configured in the following order:

1. `SecurityMiddleware` - Django security features
2. `SessionMiddleware` - Session management
3. `CommonMiddleware` - Common utilities
4. `CsrfViewMiddleware` - CSRF protection
5. `AuthenticationMiddleware` - User authentication
6. `MessageMiddleware` - Flash messages
7. `XFrameOptionsMiddleware` - Clickjacking protection
8. `CSPMiddleware` - Content Security Policy
9. `AuditLogMiddleware` - Audit logging (custom)
10. `PageVisitMiddleware` - Page visit tracking (existing)

## Testing

To verify the configuration:

```bash
# Check Django configuration
./venv/bin/python manage.py check

# Check deployment readiness (in production)
./venv/bin/python manage.py check --deploy

# Test Redis connection
./venv/bin/python manage.py shell
>>> from django.core.cache import cache
>>> cache.set('test', 'value', 60)
>>> cache.get('test')
'value'
```

## Database Models

### AuditLog Model

The `AuditLog` model tracks all user and administrator actions in the system:

**Fields**:
- `timestamp` - When the action occurred
- `user` - User who performed the action (nullable for anonymous)
- `ip_address` - IP address of the request
- `action` - Type of action (CREATE, UPDATE, DELETE, APPROVE, etc.)
- `model_name` - Name of the affected model
- `object_id` - ID of the affected object
- `object_repr` - String representation of the object
- `changes` - JSON field with before/after changes
- `request_path` - HTTP request path
- `request_method` - HTTP method (GET, POST, etc.)
- `user_agent` - Browser user agent
- `status_code` - HTTP response status code
- `severity` - Log severity (INFO, WARNING, ERROR, CRITICAL)
- `notes` - Additional notes

**Admin Features**:
- Read-only (logs cannot be manually created)
- CSV export functionality
- Advanced filtering by action, severity, timestamp
- Search by user, IP, path
- Only superusers can delete logs

### SecurityEvent Model

The `SecurityEvent` model tracks security incidents requiring attention:

**Fields**:
- `timestamp` - When the event occurred
- `event_type` - Type of security event (BRUTE_FORCE, XSS_DETECTED, etc.)
- `ip_address` - IP address of the attacker
- `user` - Associated user (if authenticated)
- `description` - Detailed description of the event
- `request_data` - JSON with request details
- `severity` - Threat level (LOW, MEDIUM, HIGH, CRITICAL)
- `resolved` - Whether the event has been resolved
- `resolved_at` - When it was resolved
- `resolved_by` - Admin who resolved it
- `resolution_notes` - Notes about the resolution
- `action_taken` - Actions taken (e.g., "IP blocked")
- `related_audit_logs` - Many-to-many with AuditLog

**Admin Features**:
- Automatic creation (cannot be manually added)
- Mark as resolved/unresolved actions
- CSV export functionality
- Visual indicators for severity and status
- Time since event display

## Next Steps

The following will be implemented in subsequent tasks:

1. ~~**Task 2**: Create AuditLog and SecurityEvent models~~ ✓ **COMPLETED**
2. **Task 3**: Implement input validation and sanitization
3. **Task 4**: Apply rate limiting decorators to views
4. **Task 5**: Implement CAPTCHA protection
5. **Task 6**: Enhance admin panel with bulk actions

## Notes

- Redis must be running for rate limiting to work. Install with: `brew install redis` (macOS) or `apt-get install redis-server` (Ubuntu)
- Start Redis: `redis-server` or `brew services start redis`
- The logs directory is created automatically on first run
- Log files are excluded from git via `.gitignore`
- All security settings can be toggled via environment variables for development/production

## Security Checklist

- [x] HTTP security headers configured
- [x] Content Security Policy implemented
- [x] Redis cache configured for rate limiting
- [x] Audit logging middleware created
- [x] Session and cookie security enhanced
- [x] Error handlers for security errors
- [x] Logging system with rotation
- [x] Environment variable management
- [x] Dependencies installed and tested
- [x] AuditLog model created and registered
- [x] SecurityEvent model created and registered
- [x] Database migrations applied
- [x] Admin panels configured with export functionality
- [ ] Rate limiting applied to views (Task 4)
- [ ] CAPTCHA integration (Task 5)


## Input Validation and Sanitization (Task 3)

### InputSanitizer Class

The `InputSanitizer` class in `medical_facilities/security_utils.py` provides comprehensive input validation and sanitization:

**HTML Sanitization**:
- `sanitize_html()` - Removes dangerous HTML tags, keeps only safe ones (p, br, strong, em, ul, ol, li, a)
- `strip_all_html()` - Removes all HTML tags
- Uses `bleach` library for robust HTML cleaning

**Field Validators**:
- `validate_phone()` - Validates and normalizes phone numbers (9-15 digits, optional +)
- `validate_postal_code()` - Validates Polish postal codes (XX-XXX format)
- `validate_coordinates()` - Validates latitude (-90 to 90) and longitude (-180 to 180)
- `validate_url()` - Validates HTTP/HTTPS URLs
- `validate_email()` - Validates email addresses
- `validate_text_length()` - Enforces maximum text length
- `validate_no_special_chars_in_numeric()` - Ensures numeric fields contain only numbers

**Attack Detection**:
- `detect_xss_attempt()` - Detects XSS patterns (script tags, javascript:, event handlers, etc.)
- `detect_sql_injection_attempt()` - Detects SQL injection patterns (UNION SELECT, OR 1=1, etc.)

**SQL Safety**:
- `sanitize_sql_like()` - Escapes special characters for LIKE queries (%, _, \)
- `sanitize_filename()` - Removes dangerous characters from filenames

### Form Security Enhancements

All forms have been updated with security validators:

**MedicalFacilityForm**:
- Name: XSS/SQL injection detection, HTML stripping, length validation
- Description: XSS detection, HTML sanitization (safe tags only), length validation
- City/Address: Attack detection, HTML stripping, length validation
- Phone: Format validation using InputSanitizer
- Email: Email format validation
- Website: URL validation
- Postal Code: Polish format validation (XX-XXX)
- Opening Hours: HTML stripping, length validation

**FacilityRatingForm**:
- Comment: XSS/SQL injection detection, HTML sanitization, length validation (10-1000 chars)

**ContactForm**:
- Name: Attack detection, HTML stripping, length validation
- Subject: Attack detection, HTML stripping, length validation
- Message: XSS/SQL injection detection, HTML sanitization, length validation (20-2000 chars)

**FacilitySearchForm**:
- Query: SQL injection detection, XSS detection, HTML stripping, SQL LIKE sanitization

### Security Event Creation

The `create_security_event_from_attack()` function automatically creates SecurityEvent records when attacks are detected:
- Logs attack type, IP address, user, request details
- Sets appropriate severity level
- Records action taken
- Enables tracking and analysis of attack patterns

### Validation Rules Summary

| Field Type | Max Length | Special Rules |
|------------|-----------|---------------|
| Facility Name | 200 chars | No HTML, XSS/SQL detection |
| Description | 2000 chars | Safe HTML only |
| City/Address | 100/200 chars | No HTML |
| Phone | - | 9-15 digits, optional + |
| Postal Code | - | XX-XXX format |
| Email | - | Valid email format |
| URL | - | HTTP/HTTPS only |
| Comment | 1000 chars | Safe HTML only, min 10 chars |
| Contact Message | 2000 chars | Safe HTML only, min 20 chars |
| Search Query | 200 chars | SQL LIKE sanitized |

### Attack Pattern Detection

**XSS Patterns Detected**:
- `<script>` tags
- `javascript:` protocol
- Event handlers (onerror, onload, onclick, onmouseover)
- `<iframe>`, `<embed>`, `<object>` tags
- `eval()`, `expression()` functions
- `vbscript:` protocol

**SQL Injection Patterns Detected**:
- Boolean-based: `OR 1=1`, `AND 1=1`
- Union-based: `UNION SELECT`
- Comment-based: `--`, `/* */`
- String-based: `' OR '1'='1`
- Command injection: `; DROP`, `; DELETE`, `; UPDATE`

All detected attacks are logged to the security log and can trigger SecurityEvent creation for tracking.


## Rate Limiting Configuration (Task 4)

### Rate Limits Applied

All views have been protected with rate limiting using `django-ratelimit`:

**Public Endpoints (GET requests)**:
- Home page: 60 requests/minute per IP
- Facility list: 60 requests/minute per IP
- Facility detail: 60 requests/minute per IP
- Statistics: 60 requests/minute per IP
- Map view: 60 requests/minute per IP
- About/Privacy pages: No limit (static content)

**Form Submissions (POST requests)**:
- Add facility: 10 requests/minute per IP (requirement: 10/min)
- Add rating: 20 requests/minute per IP (requirement: 20/min)
- Contact form: 5 requests/minute per IP

**API Endpoints**:
- Facility search API: 100 requests/minute per IP (requirement: 100/min)
- Facility coordinates API: 100 requests/minute per IP
- Map data API: 100 requests/minute per IP

### Rate Limit Enforcement

**Blocking Behavior**:
- Form submissions (POST): `block=True` - Returns 429 error when limit exceeded
- Public pages (GET): `block=False` - Logs but doesn't block (better UX)
- API endpoints: `block=True` - Returns 429 error to prevent abuse

**Rate Limit Key**: All limits use `key='ip'` to track by IP address

### Rate Limit Exceeded Handler

The `rate_limit_exceeded()` function provides comprehensive handling:

1. **Logging**: Creates AuditLog entry with:
   - Action: RATE_LIMIT_EXCEEDED
   - Severity: WARNING
   - IP address, user, path, method, user agent

2. **Abuse Detection**: Tracks violations per IP:
   - Counts violations in last hour
   - If ≥5 violations: Creates SecurityEvent
   - Event type: RATE_LIMIT_ABUSE
   - Severity: MEDIUM

3. **User-Friendly Response**:
   - Renders `errors/rate_limit.html` template
   - HTTP 429 (Too Many Requests) status
   - Clear message about retry timing

### Implementation Details

**Function-Based Views**:
```python
@ratelimit(key='ip', rate='10/m', method='POST', block=True)
def add_facility(request):
    # View logic
```

**Class-Based Views**:
```python
@method_decorator(ratelimit(key='ip', rate='60/m', method='GET', block=False), name='dispatch')
class FacilityListView(ListView):
    # View logic
```

**Multiple Limits** (different methods):
```python
@ratelimit(key='ip', rate='5/m', method='POST', block=True)
@ratelimit(key='ip', rate='60/m', method='GET', block=False)
def contact(request):
    # View logic
```

### Redis Requirement

Rate limiting requires Redis to be running:
```bash
# Install Redis (macOS)
brew install redis

# Start Redis
redis-server

# Or start as service
brew services start redis
```

Configuration in `settings.py`:
```python
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/0',
    }
}

RATELIMIT_ENABLE = True
RATELIMIT_USE_CACHE = 'default'
RATELIMIT_VIEW = 'medical_facilities.views.rate_limit_exceeded'
```

### Testing Rate Limits

To test rate limiting:

1. **Manual Testing**:
   ```bash
   # Send multiple requests quickly
   for i in {1..15}; do curl http://localhost:8000/dodaj-placowke/ -X POST; done
   ```

2. **Check Logs**:
   ```bash
   tail -f logs/security.log | grep RATE_LIMIT
   ```

3. **Check Admin Panel**:
   - Navigate to Admin → Audit Logs
   - Filter by Action: "RATE_LIMIT_EXCEEDED"
   - Check Security Events for abuse patterns

### Rate Limit Summary Table

| Endpoint | Method | Rate Limit | Block | Purpose |
|----------|--------|-----------|-------|---------|
| Home | GET | 60/min | No | Public browsing |
| Facility List | GET | 60/min | No | Public browsing |
| Facility Detail | GET | 60/min | No | Public browsing |
| Add Facility | POST | 10/min | Yes | Prevent spam |
| Add Rating | POST | 20/min | Yes | Prevent spam |
| Contact Form | POST | 5/min | Yes | Prevent spam |
| Search API | GET | 100/min | Yes | API protection |
| Coordinates API | GET | 100/min | Yes | API protection |
| Map Data API | GET | 100/min | Yes | API protection |
| Statistics | GET | 60/min | No | Public browsing |
| Map View | GET | 60/min | No | Public browsing |

All rate limits are per IP address and reset every minute.


## CAPTCHA Integration (Task 5)

### Implementation

Google reCAPTCHA v2 (checkbox) has been integrated into all public forms to prevent bot submissions.

**Protected Forms**:
- Add Facility Form (`MedicalFacilityForm`)
- Add Rating Form (`FacilityRatingForm`)
- Contact Form (`ContactForm`)

### Configuration

**Settings** (`settings.py`):
```python
INSTALLED_APPS = [
    # ...
    'django_recaptcha',
    # ...
]

RECAPTCHA_PUBLIC_KEY = config('RECAPTCHA_PUBLIC_KEY', default='')
RECAPTCHA_PRIVATE_KEY = config('RECAPTCHA_PRIVATE_KEY', default='')
RECAPTCHA_REQUIRED_SCORE = 0.5  # For v3 only
RECAPTCHA_DOMAIN = 'www.google.com'
```

**Environment Variables** (`.env`):
```bash
RECAPTCHA_PUBLIC_KEY=your-recaptcha-site-key
RECAPTCHA_PRIVATE_KEY=your-recaptcha-secret-key
```

### Getting reCAPTCHA Keys

1. Visit: https://www.google.com/recaptcha/admin
2. Register a new site
3. Choose reCAPTCHA v2 → "I'm not a robot" Checkbox
4. Add your domains (localhost for development)
5. Copy Site Key (public) and Secret Key (private)
6. Add to `.env` file

### Form Implementation

CAPTCHA field is conditionally added only if keys are configured:

```python
class MedicalFacilityForm(forms.ModelForm):
    if settings.RECAPTCHA_PUBLIC_KEY and settings.RECAPTCHA_PRIVATE_KEY:
        captcha = ReCaptchaField(
            widget=ReCaptchaV2Checkbox(
                attrs={
                    'data-theme': 'light',
                    'data-size': 'normal',
                }
            ),
            label='Weryfikacja'
        )
```

This approach allows:
- Development without CAPTCHA (if keys not set)
- Production with CAPTCHA (when keys configured)
- No errors if keys are missing

### Testing

**Development (without keys)**:
- Forms work normally without CAPTCHA
- No verification required
- Useful for local testing

**Production (with keys)**:
- CAPTCHA checkbox appears on forms
- Users must verify before submission
- Bots are blocked

**Manual Testing**:
1. Set RECAPTCHA keys in `.env`
2. Restart Django server
3. Visit form pages (add facility, add rating, contact)
4. Verify CAPTCHA checkbox appears
5. Try submitting without checking → Should fail
6. Check checkbox and submit → Should succeed

### reCAPTCHA v2 vs v3

**Current Implementation: v2 (Checkbox)**
- Pros: Clear user interaction, no false positives
- Cons: Extra step for users

**Alternative: v3 (Invisible)**
- Pros: No user interaction, seamless
- Cons: May block legitimate users with low scores
- To enable: Change `ReCaptchaV2Checkbox` to `ReCaptchaV3`

### Security Benefits

1. **Bot Prevention**: Blocks automated form submissions
2. **Spam Reduction**: Reduces spam facilities and ratings
3. **DDoS Mitigation**: Adds extra layer against automated attacks
4. **Combined with Rate Limiting**: Double protection (CAPTCHA + rate limits)

### Troubleshooting

**CAPTCHA not showing**:
- Check if keys are set in `.env`
- Verify `django_recaptcha` is in `INSTALLED_APPS`
- Check browser console for JavaScript errors
- Ensure domain is registered in reCAPTCHA admin

**CAPTCHA validation failing**:
- Verify SECRET_KEY is correct
- Check server can reach www.google.com
- Ensure no firewall blocking reCAPTCHA API

**Development without CAPTCHA**:
- Simply don't set RECAPTCHA keys
- Forms will work without verification
- Useful for local development

### Dependencies

Added to `requirements.txt`:
```
django-recaptcha>=4.0.0
```

Install with:
```bash
pip install django-recaptcha
```


## Admin Panel Enhancements (Task 6)

### Enhanced Admin Actions

**MedicalFacilityAdmin Actions**:
1. **Approve Facilities** - Bulk approval with audit logging
2. **Reject Facilities** - Bulk rejection with audit logging
3. **Export to CSV** - Export facilities with all details
4. **Mark for Review** - Reset status to pending for re-verification
5. **Export Statistics (JSON)** - Export facility statistics in JSON format

**FacilityRatingAdmin Actions**:
1. **Approve Ratings** - Bulk approval with audit logging
2. **Reject Ratings** - Bulk rejection with audit logging
3. **Export to CSV** - Export ratings with all details

### Audit Logging Integration

All bulk actions now create AuditLog entries:
- Action type: APPROVE or REJECT
- User who performed the action
- IP address
- Timestamp
- Object details
- Bulk operation note

This provides full traceability of all moderation actions.

### CSV Export Features

**Facility Export Includes**:
- ID, Name, City, Voivodeship
- Status, Contact info (phone, email)
- NFZ acceptance, Emergency service
- Average rating, Ratings count
- Creation date

**Rating Export Includes**:
- ID, Facility name, User
- All rating scores (overall, staff, facilities, treatment)
- Comment (truncated to 100 chars)
- Status, Creation date

**Export Features**:
- UTF-8 BOM for proper Excel compatibility
- Timestamped filenames
- Polish column headers
- Proper date formatting

### JSON Statistics Export

Exports detailed statistics in JSON format:
```json
{
  "facilities": [
    {
      "id": 1,
      "name": "Facility Name",
      "city": "Warsaw",
      "status": "approved",
      "average_rating": 4.5,
      "ratings_count": 10,
      "accepts_nfz": true,
      "has_emergency": false,
      "created_at": "2024-01-01T12:00:00"
    }
  ],
  "count": 1
}
```

### Advanced Filtering

Existing filters enhanced:
- Status (pending, approved, rejected)
- NFZ acceptance
- Emergency service availability
- Voivodeship
- Facility types
- Creation date (with date hierarchy)

### Search Capabilities

**Facility Search**:
- Name, City, Street address, Description

**Rating Search**:
- Facility name, Username, Comment

### List Display Enhancements

**Facility List Shows**:
- Name, City, Voivodeship
- Status (with color coding)
- NFZ, Emergency service (icons)
- Average rating, Ratings count
- Creation date

**Rating List Shows**:
- Facility, User, Overall rating
- Status, Creation date

### Usage

**Bulk Approval**:
1. Navigate to Facilities or Ratings in admin
2. Select items to approve
3. Choose "Approve" action from dropdown
4. Click "Go"
5. Confirmation message shows count
6. All actions logged to AuditLog

**CSV Export**:
1. Select items to export
2. Choose "Export to CSV" action
3. Click "Go"
4. File downloads automatically
5. Open in Excel or LibreOffice

**Statistics Export**:
1. Select facilities
2. Choose "Export statistics (JSON)"
3. Click "Go"
4. JSON file downloads
5. Use for analysis or reporting

### Performance Considerations

- Bulk operations use `update()` for efficiency
- CSV export streams data (no memory issues)
- Audit logging is non-blocking (errors don't stop operations)
- Select_related/prefetch_related for optimized queries

### Security

- All actions require admin authentication
- Audit logging tracks who did what
- IP addresses recorded for accountability
- Status changes are permanent (no accidental reversals)
