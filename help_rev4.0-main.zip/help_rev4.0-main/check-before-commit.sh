#!/bin/bash

echo "Sprawdzanie projektu przed commitem na GitHub..."
echo ""

# Kolory
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

ERRORS=0

# 1. Sprawdź czy .env nie istnieje
echo "1. Sprawdzanie pliku .env..."
if [ -f .env ]; then
    echo -e "${RED}BLAD: Plik .env istnieje! Usun go przed commitem!${NC}"
    echo "   Uruchom: rm .env"
    ERRORS=$((ERRORS + 1))
else
    echo -e "${GREEN}OK: Plik .env nie istnieje${NC}"
fi

# 2. Sprawdź czy db.sqlite3 nie istnieje
echo "2. Sprawdzanie bazy danych..."
if [ -f db.sqlite3 ]; then
    echo -e "${YELLOW}UWAGA: Plik db.sqlite3 istnieje (powinien byc w .gitignore)${NC}"
else
    echo -e "${GREEN}OK: Baza danych nie istnieje w repozytorium${NC}"
fi

# 3. Sprawdź czy venv nie istnieje
echo "3. Sprawdzanie środowiska wirtualnego..."
if [ -d venv ]; then
    echo -e "${YELLOW}UWAGA: Folder venv/ istnieje (powinien byc w .gitignore)${NC}"
else
    echo -e "${GREEN}OK: Folder venv/ nie istnieje w repozytorium${NC}"
fi

# 4. Sprawdź czy node_modules nie istnieje
echo "4. Sprawdzanie node_modules..."
if [ -d node_modules ]; then
    echo -e "${YELLOW}UWAGA: Folder node_modules/ istnieje (powinien byc w .gitignore)${NC}"
else
    echo -e "${GREEN}OK: Folder node_modules/ nie istnieje w repozytorium${NC}"
fi

# 5. Sprawdź czy .env.example istnieje
echo "5. Sprawdzanie .env.example..."
if [ -f .env.example ]; then
    echo -e "${GREEN}OK: Plik .env.example istnieje${NC}"
else
    echo -e "${RED}BLAD: Brak pliku .env.example!${NC}"
    ERRORS=$((ERRORS + 1))
fi

# 6. Sprawdź czy requirements.txt istnieje
echo "6. Sprawdzanie requirements.txt..."
if [ -f requirements.txt ]; then
    echo -e "${GREEN}OK: Plik requirements.txt istnieje${NC}"
else
    echo -e "${RED}BLAD: Brak pliku requirements.txt!${NC}"
    ERRORS=$((ERRORS + 1))
fi

# 7. Sprawdź czy README.md istnieje
echo "7. Sprawdzanie README.md..."
if [ -f README.md ]; then
    echo -e "${GREEN}OK: Plik README.md istnieje${NC}"
else
    echo -e "${YELLOW}UWAGA: Brak pliku README.md${NC}"
fi

# 8. Sprawdź czy są pliki .DS_Store
echo "8. Sprawdzanie plików .DS_Store..."
DS_STORE_COUNT=$(find . -name ".DS_Store" 2>/dev/null | wc -l)
if [ $DS_STORE_COUNT -gt 0 ]; then
    echo -e "${YELLOW}UWAGA: Znaleziono $DS_STORE_COUNT plikow .DS_Store${NC}"
    echo "   Uruchom: find . -name '.DS_Store' -delete"
else
    echo -e "${GREEN}OK: Brak plikow .DS_Store${NC}"
fi

# 9. Sprawdź czy są pliki __pycache__
echo "9. Sprawdzanie folderów __pycache__..."
PYCACHE_COUNT=$(find . -type d -name "__pycache__" 2>/dev/null | wc -l)
if [ $PYCACHE_COUNT -gt 0 ]; then
    echo -e "${YELLOW}UWAGA: Znaleziono $PYCACHE_COUNT folderow __pycache__${NC}"
    echo "   Uruchom: find . -type d -name '__pycache__' -exec rm -rf {} +"
else
    echo -e "${GREEN}OK: Brak folderow __pycache__${NC}"
fi

# 10. Sprawdź czy są pliki .log
echo "10. Sprawdzanie plików .log..."
LOG_COUNT=$(find . -name "*.log" 2>/dev/null | wc -l)
if [ $LOG_COUNT -gt 0 ]; then
    echo -e "${YELLOW}UWAGA: Znaleziono $LOG_COUNT plikow .log${NC}"
    echo "   Uruchom: find . -name '*.log' -delete"
else
    echo -e "${GREEN}OK: Brak plikow .log${NC}"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}Projekt jest gotowy do commitu na GitHub!${NC}"
    echo ""
    echo "Nastepne kroki:"
    echo "  git add ."
    echo "  git commit -m 'Przygotowanie projektu do GitHub'"
    echo "  git push origin main"
    exit 0
else
    echo -e "${RED}Znaleziono $ERRORS bledow krytycznych!${NC}"
    echo "Napraw bledy przed commitem."
    exit 1
fi
