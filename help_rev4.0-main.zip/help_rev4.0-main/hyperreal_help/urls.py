"""
URL configuration for hyperreal_help project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from medical_facilities.sitemaps import StaticViewSitemap, MedicalFacilitySitemap
from medical_facilities.robots_view import robots_txt
from medical_facilities.admin_views import statistics_view
from medical_facilities.views import security_dashboard

sitemaps = {
    'static': StaticViewSitemap,
    'facilities': MedicalFacilitySitemap,
}

urlpatterns = [
    path('admin/statistics/', statistics_view, name='admin_statistics'),
    path('admin/security-dashboard/', security_dashboard, name='admin_security_dashboard'),
    path('admin/', admin.site.urls),
    path('sitemap.xml', sitemap, {'sitemaps': sitemaps}, name='django.contrib.sitemaps.views.sitemap'),
    path('robots.txt', robots_txt, name='robots_txt'),
    path('', include('medical_facilities.urls')),
    path('', include('authentication.urls')),  # Włączone - standardowe logowanie Django
]

# Obsługa plików statycznych i mediów w trybie deweloperskim
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
