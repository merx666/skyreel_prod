# Moduł: __init__.py — fallback instalujący PyMySQL jako MySQLdb, gdy mysqlclient nie działa
# ... existing code ...
try:
    import pymysql  # fallback jeśli mysqlclient nie działa
    pymysql.install_as_MySQLdb()
except Exception:
    pass
# ... existing code ...