from django.contrib.staticfiles.storage import staticfiles_storage
from django.urls import reverse
from jinja2 import Environment
from django.contrib.messages import get_messages
from django.contrib.auth.models import AnonymousUser
from django.middleware.csrf import get_token
from datetime import datetime
from django.template.context_processors import csrf


def url_wrapper(viewname, *args, **kwargs):
    """
    Wrapper for Django's reverse function to handle Jinja2 syntax.
    """
    # Handle args parameter from Jinja2
    if 'args' in kwargs:
        args = kwargs.pop('args')
    return reverse(viewname, args=args, kwargs=kwargs)


def environment(**options):
    """
    Jinja2 environment configuration for Django integration.
    """
    env = Environment(**options)
    
    # Add Django functions to Jinja2 global namespace
    env.globals.update({
        'static': staticfiles_storage.url,
        'url_for': url_wrapper,
        'url': url_wrapper,  # Add Django url function for {% url %} tag compatibility
        'get_messages': get_messages,
        'now': datetime.now,
        'str': str,  # Add str function for template compatibility
    })
    
    # Add custom filters
    env.filters.update({
        'currency': lambda value: f"{value:.2f} zł" if value else "0.00 zł",
        'truncate_words': lambda value, length=50: (value[:length] + '...') if len(value) > length else value,
        'str': str,  # Add str filter for template compatibility
        'string': str,  # Add string filter for template compatibility
    })
    
    # Add custom tests
    env.tests.update({
        'authenticated': lambda user: user.is_authenticated if hasattr(user, 'is_authenticated') else False,
        'anonymous': lambda user: isinstance(user, AnonymousUser) or not user.is_authenticated,
    })
    
    return env